# Firmware ESP32-S3 (adquisición)

Estado: **escrito y revisado, pero no compilado ni probado con la placa.** Lo único probado es el formato
de paquetes (`protocolo.h` compilado con g++ y leído desde Python, ver `pruebas/test_paquetes.py`).
Espera errores de compilación o de ajuste en la primera subida y pégalos para corregirlos.

## Preparar el Arduino IDE
1. Gestor de placas: instala **esp32 de Espressif** (versión 3.x).
2. Placa: **ESP32S3 Dev Module**. Si usas el USB nativo de la placa, activa **USB CDC On Boot: Enabled**.
   Si usas el puerto con conversor UART, déjalo desactivado (la velocidad es 921600 en `config.h`).
3. Gestor de librerías: instala **SparkFun MAX3010x Pulse and Proximity Sensor Library**.
4. Abre `biodiseno_esp32/biodiseno_esp32.ino`. Edita `secretos.h` (Wi-Fi, URL y clave del servidor).

## Solo con el ECG (sin MAX30101 ni microSD)
En `config.h` ya vienen `USAR_PPG 0`, `SALIDA_SD 0` y `SALIDA_WIFI 0`. En ese modo un temporizador de 200 Hz hace de reloj
y rojo e IR salen en 0. Cuando conectes el MAX30101 pon `USAR_PPG 1`, y `SALIDA_SD 1` cuando tengas la tarjeta.

## Cómo probar, en este orden
1. **Solo señal.** En `config.h` pon `SALIDA_WIFI 0` y sube. Abre el visor (cierra antes el Monitor Serie del IDE,
   porque dos programas no pueden usar el mismo puerto):
   `python -m herramientas.ver_senal --puerto COM5 --guardar prueba.bin`
2. Mira el ECG y el PPG crudos. Si el ECG se ve plano o saturado, revisa electrodos y alimentación del AD8232.
   Si el PPG casi no se ve o se corta arriba, cambia `LED_AMPLITUD`.
3. Mueve los deslizadores de filtros hasta que la FFT y la señal se vean limpias.
4. Cuando la señal esté bien, `SALIDA_WIFI 1` y prueba el envío al servidor.
   Si el ECG se ensucia solo cuando transmite por Wi-Fi, es ruido de alimentación o del ADC: dímelo.

## LED de estado
Rojo: electrodo suelto o el PPG no manda datos. Verde: el servidor recibió el último paquete. Azul: sin Wi-Fi.
Si los colores salen al revés, pon `LED_ACTIVO_ALTO 0` (LED de ánodo común).

## Qué hace cada salida
- **microSD:** archivo `/sXXXXXXXX.bin` con las muestras (14 bytes cada una), el mismo formato que lee `servidor.procesar`.
- **USB:** paquetes completos (con cabecera y CRC) para `ver_senal.py`.
- **Wi-Fi:** un POST por segundo con el paquete en el cuerpo y los encabezados `X-API-Key`, `X-Paciente`, `X-Sesion`, `X-Seq`.
  Si un envío falla, ese paquete NO se reintenta (queda solo en la SD); el servidor ve el hueco en `seq`.

## Pendientes conocidos
- HTTPS usa `setInsecure()` (no verifica el certificado). Está bien para probar; para el uso real hay que poner el certificado del servidor.
- No hay reintento de paquetes ni reenvío de lo guardado en la SD.
- La memoria de espera es de 40 s (`N_PAQUETES`). Si la red tarda más, se pierden paquetes viejos y sube `descartados`.
