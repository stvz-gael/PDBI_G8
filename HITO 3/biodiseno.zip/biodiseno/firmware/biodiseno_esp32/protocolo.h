// Formato de los paquetes (igual en la microSD, el USB y el Wi-Fi). Ver CONTRATO.md.
// Todo little-endian, empaquetado, sin relleno. Sin dependencias de Arduino.
#pragma once
#include <stdint.h>
#include <stddef.h>

#define PROTO_VERSION 1
#define FLAG_ELECTRODO_SUELTO 0x01   // en algun momento del paquete LO+ o LO- estuvo en alto
#define FLAG_LO_POS           0x04   // LO+ estuvo en alto (electrodo LA/+ sin contacto)
#define FLAG_LO_NEG           0x08   // LO- estuvo en alto (electrodo RA/- sin contacto)
#define FLAG_HUECO_PPG        0x02   // hubo un salto de tiempo > 1,6 periodos entre muestras

// Una muestra de x[n]: 14 bytes (igual que DTYPE_X en procesamiento/cargador.py)
struct __attribute__((packed)) Muestra {
  uint32_t t_us;    // microsegundos desde el arranque (da la vuelta a los ~71 min)
  uint16_t ecg;     // cuentas del ADC, 0 a 4095
  uint32_t red;     // cuentas del MAX30101, 18 bits
  uint32_t ir;      // cuentas del MAX30101, 18 bits
};

// Cabecera de 32 bytes que precede a n muestras
struct __attribute__((packed)) Cabecera {
  char     magic[4];    // "BIO1"
  uint8_t  version;     // PROTO_VERSION
  uint8_t  flags;       // FLAG_*
  uint16_t n;           // numero de muestras que siguen
  uint32_t paciente;
  uint32_t sesion;      // aleatorio en cada arranque
  uint32_t seq;         // 0, 1, 2... dentro de la sesion (detecta paquetes perdidos)
  uint32_t t0_us;       // t_us de la primera muestra
  uint32_t epoch_s;     // hora UTC (s desde 1970) de la primera muestra; 0 si aun no hay hora
  uint16_t crc;         // CRC-16/CCITT-FALSE de las n muestras
  uint16_t reservado;
};

static_assert(sizeof(Muestra) == 14, "Muestra debe medir 14 bytes");
static_assert(sizeof(Cabecera) == 32, "Cabecera debe medir 32 bytes");

// CRC-16/CCITT-FALSE: poly 0x1021, init 0xFFFF (la entrada "123456789" da 0x29B1)
inline uint16_t crc16_ccitt(const uint8_t *d, size_t n) {
  uint16_t crc = 0xFFFF;
  for (size_t i = 0; i < n; i++) {
    crc ^= (uint16_t)d[i] << 8;
    for (int b = 0; b < 8; b++) crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021) : (uint16_t)(crc << 1);
  }
  return crc;
}