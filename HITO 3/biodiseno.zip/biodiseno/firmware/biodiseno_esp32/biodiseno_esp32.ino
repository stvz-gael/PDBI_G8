/*
  BIODISEÑO: adquisicion en la ESP32-S3
  ECG (AD8232 -> ADC) + PPG rojo e IR (MAX30101, I2C) a 200 Hz
  -> paquetes de 1 s -> microSD, USB (ver_senal.py) y Wi-Fi (servidor)

  Como se mantiene el tiempo alineado:
  el MAX30101 es el "reloj": cada vez que termina una muestra levanta INT. La interrupcion
  guarda la hora (esp_timer, microsegundos) y despierta la tarea de muestreo, que lee el ADC
  del ECG de inmediato y luego la muestra del PPG por I2C. Asi ECG y PPG de una misma fila
  quedan separados por menos de ~1 ms (el PAT necesita 5 ms o mejor).

  Librerias (Gestor de librerias de Arduino): "SparkFun MAX3010x Pulse and Proximity Sensor Library"
  Placa: ESP32S3 Dev Module (nucleo esp32 de Espressif 3.x). Ver README en esta carpeta.
*/
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <time.h>
#include <sys/time.h>
#include <esp_timer.h>
#include "config.h"
#include "protocolo.h"
#if USAR_PPG
#include "MAX30105.h"      // la libreria de SparkFun; sirve para el MAX30101
#endif

#define PERIODO_US (1000000 / FS_HZ)
#define USAR_INT   (USAR_PPG && (PIN_INT >= 0))     // 1: el INT del MAX30101 es el reloj. 0: lo es un temporizador de 200 Hz


struct Paquete {
  Cabecera h;
  Muestra  m[PAQUETE_MUESTRAS];
} __attribute__((packed));

// Pines opcionales: con -1 no se tocan.
// (Va DESPUES de la struct: el Arduino IDE declara las funciones antes de la primera funcion del archivo)
static inline int leerPin(int pin) { return pin >= 0 ? digitalRead(pin) : 0; }

#if USAR_PPG
static MAX30105 sensor;
#endif
static TaskHandle_t hMuestreo = nullptr;
static QueueHandle_t qLibres = nullptr, qListos = nullptr;

static volatile int64_t  g_tIsr = 0;              // hora de la ultima interrupcion del MAX30101
static volatile int64_t  g_offsetEpochUs = 0;     // (hora UTC en us) - (esp_timer en us); 0 si no hay hora
static volatile bool     g_electrodoSuelto = false;
static volatile uint8_t  g_loFlags = 0;       // FLAG_LO_POS | FLAG_LO_NEG
static volatile bool     g_ppgError = false;
static volatile uint32_t g_muestras = 0, g_paqDescartados = 0, g_okMs = 0;
static volatile bool     g_redOk = false;

static uint32_t g_sesion = 0, g_seq = 0;
static Paquete *pa = nullptr;                     // paquete que se esta llenando
static uint16_t nPa = 0;
static uint8_t  flagsPa = 0;
static int64_t  t64Primera = 0;

// ------------------------------------------------------------------ LED de estado
static void ponerLed(bool r, bool g, bool b) {
  if (PIN_LED_R < 0) return;                      // sin LED RGB
  digitalWrite(PIN_LED_R, (r == (bool)LED_ACTIVO_ALTO) ? HIGH : LOW);
  digitalWrite(PIN_LED_G, (g == (bool)LED_ACTIVO_ALTO) ? HIGH : LOW);
  digitalWrite(PIN_LED_B, (b == (bool)LED_ACTIVO_ALTO) ? HIGH : LOW);
}

// ------------------------------------------------------------------ ECG
static uint16_t leerEcg() {
  uint32_t s = 0;
  for (int i = 0; i < 4; i++) s += analogRead(PIN_ECG);   // promedio de 4 lecturas reduce ruido del ADC
  return (uint16_t)(s >> 2);
}

// ------------------------------------------------------------------ Paquetes
static void nuevoPaquete() {
  if (xQueueReceive(qLibres, &pa, 0) != pdTRUE) {
    // no hay libres (la salida va atrasada): se descarta el paquete listo mas viejo
    if (xQueueReceive(qListos, &pa, 0) != pdTRUE) { pa = nullptr; return; }
    g_paqDescartados++;
  }
  nPa = 0;
  flagsPa = 0;
}

static void cerrarPaquete() {
  Cabecera &h = pa->h;
  memcpy(h.magic, "BIO1", 4);
  h.version = PROTO_VERSION;
  h.flags = flagsPa;
  h.n = nPa;
  h.paciente = PACIENTE_ID;
  h.sesion = g_sesion;
  h.seq = g_seq++;
  h.t0_us = (uint32_t)t64Primera;
  int64_t off = g_offsetEpochUs;
  h.epoch_s = off ? (uint32_t)((t64Primera + off) / 1000000LL) : 0;
  h.crc = 0;
  h.reservado = 0;
  Paquete *listo = pa;
  pa = nullptr;
  xQueueSend(qListos, &listo, 0);
  nuevoPaquete();
}

static void agregar(int64_t t64, uint16_t ecg, uint32_t red, uint32_t ir, bool suelto) {
  if (!pa) { nuevoPaquete(); if (!pa) return; }
  if (nPa == 0) t64Primera = t64;
  Muestra &m = pa->m[nPa++];
  m.t_us = (uint32_t)t64;
  m.ecg = ecg;
  m.red = red;
  m.ir = ir;
  if (suelto) flagsPa |= FLAG_ELECTRODO_SUELTO;
  flagsPa |= g_loFlags;
  g_muestras++;
  if (nPa >= PAQUETE_MUESTRAS) cerrarPaquete();
}

// ------------------------------------------------------------------ Tarea de muestreo (nucleo 1, prioridad alta)
#if USAR_INT
static void IRAM_ATTR isrMax() {
  g_tIsr = esp_timer_get_time();
  BaseType_t despertar = pdFALSE;
  vTaskNotifyGiveFromISR(hMuestreo, &despertar);
  if (despertar) portYIELD_FROM_ISR();
}
#endif

// Modo solo ECG: un temporizador de 200 Hz hace el papel del MAX30101
static void cbTemporizador(void *) {
  g_tIsr = esp_timer_get_time();
  xTaskNotifyGive(hMuestreo);
}

static void tareaMuestreo(void *) {
  int64_t tUltima = 0;
  uint32_t redUlt = 0, irUlt = 0;
  int sinDatos = 0;
  for (;;) {
    uint32_t avisos = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(50));   // si el INT falla, se sondea igual
    uint16_t ecg = leerEcg();                                        // lo primero: lo mas cerca posible de la muestra PPG
    bool suelto = leerPin(PIN_LO_POS) || leerPin(PIN_LO_NEG);
    g_electrodoSuelto = suelto;
    g_loFlags = (leerPin(PIN_LO_POS) ? FLAG_LO_POS : 0) | (leerPin(PIN_LO_NEG) ? FLAG_LO_NEG : 0);
    int64_t tRef = avisos ? g_tIsr : esp_timer_get_time();

#if USAR_INT
    sensor.getINT1();                 // lee y limpia el registro de interrupcion
    sensor.check();                   // trae del FIFO del sensor lo que haya
    int disp = sensor.available();
    g_ppgError = (disp == 0 && avisos == 0);   // 50 ms sin datos: el sensor no responde
    for (int k = 0; k < disp; k++) {
      // si llegaron varias juntas, se reparten hacia atras en el tiempo
      int64_t t = tRef - (int64_t)(disp - 1 - k) * PERIODO_US;
      uint32_t red = sensor.getFIFORed();
      uint32_t ir = sensor.getFIFOIR();
      sensor.nextSample();
      if (tUltima && (t - tUltima) > (PERIODO_US * 16 / 10)) flagsPa |= FLAG_HUECO_PPG;
      tUltima = t;
      agregar(t, ecg, red, ir, suelto);
    }
#elif USAR_PPG
    // Sin INT: el temporizador de 200 Hz marca cada fila. Se toma la muestra mas vieja del FIFO del sensor.
    // Si el sensor se atrasa o adelanta un poco, se descartan o se repiten muestras (el reloj del sensor no es exacto).
    if (avisos) {
      sensor.check();
      int disp = sensor.available();
      while (disp > 3) { sensor.nextSample(); disp--; }          // atraso acumulado: se tiran las mas viejas
      if (disp > 0) {
        redUlt = sensor.getFIFORed();
        irUlt = sensor.getFIFOIR();
        sensor.nextSample();
        sinDatos = 0;
      } else if (sinDatos < 1000) {
        sinDatos++;
      }
      g_ppgError = (sinDatos > 20);                               // 100 ms sin muestras nuevas: el sensor no responde
      if (tUltima && (tRef - tUltima) > (PERIODO_US * 16 / 10)) flagsPa |= FLAG_HUECO_PPG;
      tUltima = tRef;
      agregar(tRef, ecg, redUlt, irUlt, suelto);
    }
#else
    if (avisos) {
      if (tUltima && (tRef - tUltima) > (PERIODO_US * 16 / 10)) flagsPa |= FLAG_HUECO_PPG;
      tUltima = tRef;
      agregar(tRef, ecg, 0, 0, suelto);          // sin PPG: rojo = IR = 0
    }
#endif
  }
}

// ------------------------------------------------------------------ Salidas (nucleo 0, prioridad baja)
static WiFiClientSecure clienteSeguro;
static WiFiClient clientePlano;
static HTTPClient http;
static uint32_t ultimoIntentoWifi = 0;
static bool horaLista = false;

static void mantenerWifi() {
#if SALIDA_WIFI
  if (WiFi.status() != WL_CONNECTED) {
    horaLista = false;
    if (millis() - ultimoIntentoWifi > 8000) {
      ultimoIntentoWifi = millis();
      WiFi.disconnect();
      WiFi.begin(WIFI_SSID, WIFI_PASS);
    }
    return;
  }
  if (!horaLista) {
    configTime(0, 0, "pool.ntp.org", "time.google.com");
    time_t ahora = time(nullptr);
    if (ahora > 1700000000) {
      struct timeval tv;
      gettimeofday(&tv, nullptr);
      g_offsetEpochUs = (int64_t)tv.tv_sec * 1000000LL + tv.tv_usec - esp_timer_get_time();
      horaLista = true;
    }
  }
#endif
}

static bool enviarWifi(Paquete *p, size_t largo) {
#if SALIDA_WIFI
  if (WiFi.status() != WL_CONNECTED) return false;
  bool https = String(URL_SERVIDOR).startsWith("https");
  bool ok;
  if (https) { clienteSeguro.setInsecure(); ok = http.begin(clienteSeguro, URL_SERVIDOR); }   // PRUEBAS: no verifica el certificado
  else ok = http.begin(clientePlano, URL_SERVIDOR);
  if (!ok) return false;
  http.setReuse(true);
  http.setTimeout(4000);
  http.addHeader("Content-Type", "application/octet-stream");
  http.addHeader("X-API-Key", API_KEY);
  http.addHeader("X-Paciente", String((uint32_t)PACIENTE_ID));
  http.addHeader("X-Sesion", String(g_sesion));
  http.addHeader("X-Seq", String(p->h.seq));
  int codigo = http.POST((uint8_t *)p, largo);
  http.end();
  return codigo >= 200 && codigo < 300;
#else
  return false;
#endif
}

static void tareaSalida(void *) {
  File archivo;
  bool sdOk = false;
#if SALIDA_SD
  static SPIClass spiSD(FSPI);
  spiSD.begin(PIN_SD_CLK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
  if (SD.begin(PIN_SD_CS, spiSD, 20000000)) {
    char nombre[32];
    snprintf(nombre, sizeof(nombre), "/s%08x.bin", g_sesion);
    archivo = SD.open(nombre, FILE_APPEND);
    sdOk = (bool)archivo;
  }
  Serial.printf("#SD %s\n", sdOk ? "ok" : "NO disponible");
#endif
  uint32_t tEstado = 0;
  bool redOk = false;
  for (;;) {
    Paquete *p = nullptr;
    if (xQueueReceive(qListos, &p, pdMS_TO_TICKS(500)) != pdTRUE) { mantenerWifi(); continue; }
    uint16_t n = p->h.n;
    size_t bytesMuestras = (size_t)n * sizeof(Muestra);
    size_t largo = sizeof(Cabecera) + bytesMuestras;
    p->h.crc = crc16_ccitt((const uint8_t *)p->m, bytesMuestras);

#if SALIDA_SD
    if (sdOk) { archivo.write((const uint8_t *)p->m, bytesMuestras); archivo.flush(); }   // solo muestras: es el .bin del contrato
#endif
#if SALIDA_SERIAL
    Serial.write((const uint8_t *)p, largo);
#endif
    mantenerWifi();
    redOk = enviarWifi(p, largo);
    if (redOk) g_okMs = millis();
    g_redOk = redOk;
    xQueueSend(qLibres, &p, 0);

    if (millis() - tEstado > 5000) {
      tEstado = millis();
      Serial.printf("#seq=%u muestras=%u red=%d wifi=%d descartados=%u LO+=%d LO-=%d ppgErr=%d\n",
                    (unsigned)g_seq, (unsigned)g_muestras, (int)redOk, (int)(WiFi.status() == WL_CONNECTED),
                    (unsigned)g_paqDescartados, (int)leerPin(PIN_LO_POS), (int)leerPin(PIN_LO_NEG), (int)g_ppgError);
    }
  }
}

// ------------------------------------------------------------------ setup / loop
void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(500);
  if (PIN_LED_R >= 0) { pinMode(PIN_LED_R, OUTPUT); pinMode(PIN_LED_G, OUTPUT); pinMode(PIN_LED_B, OUTPUT); }
  // Prueba del LED al encender: rojo, verde, azul (medio segundo cada uno). Si no se enciende ninguno, es el cableado del LED;
  // si los colores salen cambiados o encendidos al reves, pon LED_ACTIVO_ALTO 0 en config.h
  ponerLed(true, false, false); delay(500);
  ponerLed(false, true, false); delay(500);
  ponerLed(false, false, true); delay(500);
  ponerLed(false, false, false);

  if (PIN_SDN >= 0) { pinMode(PIN_SDN, OUTPUT); digitalWrite(PIN_SDN, HIGH); }   // enciende el AD8232
  if (PIN_LO_POS >= 0) pinMode(PIN_LO_POS, INPUT);
  if (PIN_LO_NEG >= 0) pinMode(PIN_LO_NEG, INPUT);
  analogReadResolution(12);
  analogSetPinAttenuation(PIN_ECG, ADC_11db);    // rango ~0 a 3,1 V: el AD8232 se centra en ~1,5 V

#if USAR_PPG
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(400000);
  while (!sensor.begin(Wire, I2C_SPEED_FAST)) {
    Serial.println("#MAX30101 no responde (revisa SDA, SCL y 3V3)");
    ponerLed(true, false, false); delay(400); ponerLed(false, false, false); delay(400);
  }
  // setup(brillo, promedio, modo LED, muestras/s, ancho de pulso us, rango ADC)
  // modo 2 = rojo + IR; ancho 411 us = 18 bits
  sensor.setup(LED_AMPLITUD, 1, 2, FS_HZ, 411, PPG_RANGO_ADC);
  sensor.clearFIFO();
#if USAR_INT
  sensor.enableDATARDY();                        // INT en bajo cada vez que hay una muestra nueva
  sensor.getINT1();
#endif

#endif

  g_sesion = esp_random();
  qLibres = xQueueCreate(N_PAQUETES, sizeof(Paquete *));
  qListos = xQueueCreate(N_PAQUETES, sizeof(Paquete *));
  for (int i = 0; i < N_PAQUETES; i++) {
    Paquete *p = (Paquete *)heap_caps_malloc(sizeof(Paquete), MALLOC_CAP_8BIT);
    if (!p) { Serial.println("#sin memoria para paquetes"); break; }
    xQueueSend(qLibres, &p, 0);
  }
  nuevoPaquete();

#if SALIDA_WIFI
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);                          // sin ahorro de energia: menos latencia y menos jitter
  WiFi.begin(WIFI_SSID, WIFI_PASS);
#endif

#if CONFIG_FREERTOS_UNICORE                      // ESP32-C3: un solo nucleo
  xTaskCreate(tareaSalida, "salida", 12288, nullptr, 1, nullptr);
  xTaskCreate(tareaMuestreo, "muestreo", 6144, nullptr, configMAX_PRIORITIES - 2, &hMuestreo);
#else
  xTaskCreatePinnedToCore(tareaSalida, "salida", 12288, nullptr, 1, nullptr, 0);
  xTaskCreatePinnedToCore(tareaMuestreo, "muestreo", 6144, nullptr, configMAX_PRIORITIES - 2, &hMuestreo, 1);
#endif
#if USAR_INT
  pinMode(PIN_INT, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_INT), isrMax, FALLING);
#else
  esp_timer_create_args_t ta = {};
  ta.callback = cbTemporizador;
  ta.name = "fs200";
  esp_timer_handle_t temporizador;
  esp_timer_create(&ta, &temporizador);
  esp_timer_start_periodic(temporizador, PERIODO_US);
#endif
  Serial.printf("#listo sesion=%08x\n", (unsigned)g_sesion);
}

void loop() {
  // Rojo = electrodo suelto o PPG sin datos | Verde = el servidor recibio el ultimo paquete | Azul = sin Wi-Fi
  bool r = g_electrodoSuelto || g_ppgError;
  bool g = (millis() - g_okMs) < 2000 && g_okMs != 0;
  bool b = SALIDA_WIFI && WiFi.status() != WL_CONNECTED;
  ponerLed(r, g, b);
  delay(100);
}
