// Claves y direccion del servidor. NO subas este archivo a GitHub (esta en .gitignore).
#pragma once
#define WIFI_SSID     "TU_WIFI"
#define WIFI_PASS     "TU_CLAVE"
#define URL_SERVIDOR  "https://REGION-PROYECTO.cloudfunctions.net/recibirBloque"   // la que te de tu companera
#define API_KEY       "CAMBIAME"
