// Configuracion del firmware. Pines segun el esquematico.
#pragma once

// ---- Placa: 1 = XIAO ESP32-C3 (prototipo actual), 0 = ESP32-S3 del esquematico ----
#define PLACA_XIAO_C3  1

// ---- Pines ----
// Pon -1 en un pin que no tengas conectado: el firmware lo ignora.
#if PLACA_XIAO_C3
  // XIAO ESP32-C3: D1 = GPIO3, D4 = GPIO6 (SDA), D5 = GPIO7 (SCL)
  #define PIN_ECG      3    // AD8232 OUTPUT -> D1
  #define PIN_SDA      6    // MAX30101 SDA -> D4
  #define PIN_SCL      7    // MAX30101 SCL -> D5
  #define PIN_SDN      -1   // AD8232 SDN (no hace falta conectarlo)
  #define PIN_LO_POS   4    // AD8232 LO+ -> D2 (GPIO4). Si NO lo cableas, pon -1
  #define PIN_LO_NEG   5    // AD8232 LO- -> D3 (GPIO5). Si NO lo cableas, pon -1
  #define PIN_INT      -1   // MAX30101 INT (sin usar: el temporizador de 200 Hz hace de reloj)
  #define PIN_LED_R    -1
  #define PIN_LED_G    -1
  #define PIN_LED_B    -1
  #define PIN_SD_MOSI  -1
  #define PIN_SD_CLK   -1
  #define PIN_SD_MISO  -1
  #define PIN_SD_CS    -1
#else
  #define PIN_ECG      7    // AD8232 OUTPUT (ADC1_CH6)
  #define PIN_SDN      4    // AD8232 SDN (HIGH = encendido)
  #define PIN_LO_POS   5    // AD8232 LO+
  #define PIN_LO_NEG   6    // AD8232 LO-
  #define PIN_SDA      8    // MAX30101
  #define PIN_SCL      9
  #define PIN_INT      18   // MAX30101 INT (activo en bajo)
  #define PIN_SD_MOSI  11
  #define PIN_SD_CLK   12
  #define PIN_SD_MISO  13
  #define PIN_SD_CS    14
  #define PIN_LED_R    39
  #define PIN_LED_G    42
  #define PIN_LED_B    41
#endif
#define LED_ACTIVO_ALTO 1  // pon 0 si tu LED RGB es de anodo comun (se enciende con LOW)

// ---- Muestreo ----
#define FS_HZ             200   // ECG y PPG (debe ser 200: ver CONTRATO.md)
#define PAQUETE_MUESTRAS  20    // 0,1 s por paquete: el visor USB se mueve suave. Con Wi-Fi/Firebase usa 200 (1 s por paquete)
#define N_PAQUETES        200   // 200 paquetes de 0,1 s = 20 s de espera (si usas PAQUETE_MUESTRAS 200, baja a 40)
#define LED_AMPLITUD      0x3C  // corriente de los LED del MAX30101 (0x3F ~ 12,6 mA). Ajusta si el PPG satura o es muy debil

// ---- Que hardware tienes conectado ----
#define PPG_RANGO_ADC  4096     // rango del ADC del MAX30101 (2048, 4096, 8192 o 16384)
#define USAR_PPG       1        // 1 = MAX30101 conectado. 0 = solo ECG (rojo e IR salen en 0)

// ---- Salidas (1 = activa) ----
#define SALIDA_SD      0        // guarda las muestras (.bin de 14 bytes por muestra)
#define SALIDA_SERIAL  1        // manda los paquetes por USB a herramientas/ver_senal.py
#define SALIDA_WIFI    0        // manda los paquetes al servidor por HTTP(S)
#define SERIAL_BAUD    921600   // solo importa si usas el puerto UART; el USB nativo ignora la velocidad

#define PACIENTE_ID    1

#include "secretos.h"           // WIFI_SSID, WIFI_PASS, URL_SERVIDOR, API_KEY