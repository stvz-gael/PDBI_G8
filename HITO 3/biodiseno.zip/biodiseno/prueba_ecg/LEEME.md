# Probar con un ECG guardado
Pon aqui tu archivo CSV (1 columna con el ECG, o 2 columnas: tiempo_s, ecg) y corre desde la carpeta del proyecto:

    python -m herramientas.puente_firebase --archivo prueba_ecg/ecg_ejemplo.csv --seco
    python -m herramientas.puente_firebase --archivo prueba_ecg/mi_ecg.csv --fs 250     # si solo tiene 1 columna, dime su fs

`ecg_ejemplo.csv` es sintetico: FC verdadera 70 lpm, FR 14 rpm. Si el programa da ~70, el calculo funciona.
Quita `--seco` para enviarlo a la app. Se reproduce en tiempo real (120 s de senal tardan 120 s).
