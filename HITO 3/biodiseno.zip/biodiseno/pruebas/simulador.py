"""Senales sinteticas CON VERDAD CONOCIDA, para probar el codigo sin sensores.
Como sabes la FC, FR y PAT reales, puedes medir el error de tu pipeline."""
import numpy as np


def simular(duracion_s=300, fs=200.0, fc=75.0, fr=15.0, pat=0.25,
            spo2=97.0, ruido=0.02, invertido=False, semilla=0, A=110.0, B=25.0, muesca=0.0, t_amp=0.30):
    rng = np.random.default_rng(semilla)
    t = np.arange(0, duracion_s, 1.0 / fs)
    # tiempos de R: RR medio con arritmia sinusal respiratoria (varia con la FR)
    t_r, tr = [], 0.5
    while tr < duracion_s - 1:
        t_r.append(tr)
        rr = 60.0 / fc + 0.04 * np.sin(2 * np.pi * (fr / 60.0) * tr) + rng.normal(0, 0.01)
        tr += rr
    t_r = np.array(t_r)

    def g(x, mu, s):
        return np.exp(-0.5 * ((x - mu) / s) ** 2)

    ecg = np.zeros_like(t)
    for k, tr in enumerate(t_r):
        mod = 1.0 + 0.10 * np.sin(2 * np.pi * (fr / 60.0) * tr)   # la R cambia con la respiracion
        ecg += mod * g(t, tr, 0.010) - 0.12 * g(t, tr - 0.03, 0.01) \
            + 0.15 * g(t, tr - 0.16, 0.025) + t_amp * g(t, tr + 0.25, 0.045)
    ecg += 0.1 * np.sin(2 * np.pi * 0.2 * t) + rng.normal(0, ruido, len(t))   # deriva + ruido

    # pulso PPG: sube rapido (pie en tr+pat), baja lento
    def pulso(x):
        y = np.zeros_like(x)
        m = x >= 0
        y[m] = (1 - np.exp(-x[m] / 0.05)) * np.exp(-x[m] / 0.18)
        y += muesca * np.exp(-0.5 * ((x - 0.30) / 0.05) ** 2)   # onda dicrota (segundo pico)
        return y

    pp = np.zeros_like(t)
    for tr in t_r:
        pp += (1.0 + 0.15 * np.sin(2 * np.pi * (fr / 60.0) * tr)) * pulso(t - (tr + pat))
    pp = pp / pp.max()
    # rojo e IR: mismo pulso, distinta razon AC/DC. R = (SpO2 - A)/(-B)
    R = (A - spo2) / B
    dc = 50000.0
    ac_ir = 0.02 * dc
    ac_red = R * 0.02 * dc
    sg = -1.0 if invertido else 1.0
    ir = dc + sg * ac_ir * pp + rng.normal(0, 0.0005 * dc, len(t))
    red = dc + sg * ac_red * pp + rng.normal(0, 0.0005 * dc, len(t))
    verdad = dict(FC=fc, FR=fr, PAT=pat, SpO2=spo2)
    return dict(t=t, fs=fs, ecg=ecg, ir=ir, red=red), verdad