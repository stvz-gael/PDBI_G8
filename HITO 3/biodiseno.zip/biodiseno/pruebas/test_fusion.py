"""La fusion debe ignorar una fuente que se equivoca."""
import numpy as np
from procesamiento.respiracion import fusionar
fr, n = fusionar({"edr": (15.2, 0.5), "rsa": (14.8, 0.4), "ppga": (27.0, 0.6), "ppgb": (np.nan, 0)})
print(round(fr, 2), n)
assert 14.5 < fr < 15.5 and n == 2
fr, n = fusionar({"edr": (15.0, 0.5), "rsa": (30.0, 0.2), "ppga": (np.nan, 0), "ppgb": (np.nan, 0)})
assert n == 1 and fr == 15.0          # sin acuerdo: gana la mas prominente
print("OK")
