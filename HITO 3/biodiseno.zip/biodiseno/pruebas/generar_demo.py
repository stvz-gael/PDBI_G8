"""Genera prueba_ecg/demo_ecg_ppg.pkt: 150 s de ECG + PPG sinteticos (FC 75, FR 15, SpO2 97) en paquetes BIO1.
Sirve para ver las dos graficas y FC, FR, SpO2 en el visor SIN la ESP32:
    python -m herramientas.generar_demo
    python -m herramientas.ver_senal --archivo prueba_ecg/demo_ecg_ppg.pkt
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from procesamiento.cargador import DTYPE_X, DTYPE_CAB, crc16_ccitt
from pruebas.simulador import simular

FS = 200


def main(ruta="prueba_ecg/demo_ecg_ppg.pkt", duracion=150):
    x, _ = simular(duracion_s=duracion, fs=FS, fc=75, fr=15, spo2=97, semilla=2)
    n = len(x["t"])
    a = np.zeros(n, dtype=DTYPE_X)
    a["t_us"] = (x["t"] * 1e6).astype(np.uint64) % 2**32
    e = x["ecg"]
    a["ecg"] = np.clip(2048 + 350 * (e - e.mean()) / e.std(), 0, 4095).astype(np.uint16)
    a["ir"], a["red"] = (2 * x["ir"]).astype(np.uint32), (2 * x["red"]).astype(np.uint32)   # x2: nivel DC sobre el umbral de dedo
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "wb") as f:
        for k in range(0, n - FS + 1, FS):
            m = a[k:k + FS]
            cuerpo = m.tobytes()
            c = np.zeros(1, dtype=DTYPE_CAB)
            c["magic"], c["version"], c["n"], c["seq"] = b"BIO1", 1, FS, k // FS
            c["t0_us"], c["crc"] = m["t_us"][0], crc16_ccitt(cuerpo)
            f.write(c.tobytes() + cuerpo)
    print(f"Listo: {ruta}")


if __name__ == "__main__":
    main()