"""Prueba con senales simuladas: correr con  python -m pruebas.test_sintetico
(desde la carpeta del proyecto)."""
import numpy as np
from pruebas.simulador import simular
from procesamiento.pipeline import procesar

d, v = simular(duracion_s=300, fc=75, fr=15, pat=0.25, spo2=97)
z = procesar(d["t"], d["ecg"], d["ir"], d["red"], d["fs"])
zz = z[z["valido"]]
print(f"ventanas validas: {len(zz)} de {len(z)}")
for col, real in [("FC", v["FC"]), ("FR", v["FR"]), ("PAT", v["PAT"]), ("SpO2", v["SpO2"])]:
    est = zz[col].median()
    print(f"{col:5s} real={real:7.3f}  estimado={est:7.3f}  error={est-real:+.3f}")
print("HRV_SDNN (ms):", round(zz["HRV_SDNN"].median(), 1))
assert abs(zz["FC"].median() - v["FC"]) < 1.5
assert abs(zz["FR"].median() - v["FR"]) < 2.0
assert abs(zz["PAT"].median() - v["PAT"]) < 0.03
assert abs(zz["SpO2"].median() - v["SpO2"]) < 2.0
print("OK")
