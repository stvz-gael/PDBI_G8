"""Comprueba el formato de paquetes de punta a punta:
   protocolo.h (C++, el del firmware) -> archivo -> leer_paquetes (Python).
   Tambien prueba cortes del flujo, texto mezclado, CRC malo y paquetes perdidos.
   Si no hay g++ se salta la parte de C++ y usa paquetes armados en Python."""
import os, shutil, subprocess, tempfile
import numpy as np
from procesamiento.cargador import (DTYPE_CAB, DTYPE_X, leer_paquetes, unir_paquetes,
                                    crc16_ccitt, x_desde_array)

assert crc16_ccitt(b"123456789") == 0x29B1
assert DTYPE_CAB.itemsize == 32 and DTYPE_X.itemsize == 14

carpeta = tempfile.mkdtemp()
ruta = os.path.join(carpeta, "c.pkt")
if shutil.which("g++"):
    exe = os.path.join(carpeta, "gen")
    fuente = os.path.join(os.path.dirname(__file__), "cpp", "generar.cpp")
    subprocess.run(["g++", "-std=c++17", "-Wall", "-o", exe, fuente], check=True)
    print(subprocess.run([exe, ruta], capture_output=True, text=True, check=True).stdout.strip())
    datos = open(ruta, "rb").read()
else:
    print("(sin g++: se arman los paquetes en Python)")
    partes = []
    t = 4294960000
    for seq in range(5):
        a = np.zeros(200, dtype=DTYPE_X)
        a["t_us"] = (t + np.arange(200) * 5000) % 2**32
        a["ecg"] = 1000 + seq * 10 + np.arange(200); a["red"] = 100000 + np.arange(200); a["ir"] = 200000 + seq
        t += 1_000_000
        c = np.zeros(1, dtype=DTYPE_CAB)
        c["magic"] = b"BIO1"; c["version"] = 1; c["n"] = 200; c["paciente"] = 7; c["sesion"] = 0xCAFEBABE
        c["seq"] = seq; c["flags"] = 1 if seq == 3 else 0; c["t0_us"] = a["t_us"][0]; c["crc"] = crc16_ccitt(a.tobytes())
        if seq != 2:
            partes.append(c.tobytes() + a.tobytes())
            if seq == 0:
                partes.append(b"#texto de depuracion con BIO sin el resto\n")
    datos = b"".join(partes)

# 1) archivo completo
paq, usados, malos = leer_paquetes(datos)
assert len(paq) == 4 and malos == 0, (len(paq), malos)
a, faltan = unir_paquetes(paq)
assert faltan == [2], faltan
assert len(a) == 800 and int(paq[0][0]["paciente"]) == 7 and int(paq[2][0]["flags"]) == 1
assert int(paq[1][1]["ecg"][0]) == 1010

# 2) el tiempo da la vuelta de 32 bits y queda continuo (dt = 5 ms dentro de cada paquete)
x = x_desde_array(a[:200], 200.0)
assert abs(np.diff(x["t"]).mean() - 0.005) < 1e-6

# 3) flujo recibido en trozos de 1000 bytes (como el puerto serie)
buf, hallados = b"", 0
for i in range(0, len(datos), 1000):
    buf += datos[i:i + 1000]
    p, usados, _ = leer_paquetes(buf)
    hallados += len(p)
    buf = buf[usados:]
assert hallados == 4, hallados

# 4) un byte danado: el paquete se rechaza por CRC y los demas siguen
mal = bytearray(datos); mal[100] ^= 0xFF
paq2, _, malos2 = leer_paquetes(bytes(mal))
assert len(paq2) == 3 and malos2 == 1, (len(paq2), malos2)
print("OK: 4 paquetes leidos, falta seq", faltan, "| CRC malo detectado | corte en trozos bien")
