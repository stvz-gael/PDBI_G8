"""Simula el archivo .bin de la ESP32 y comprueba que el cargador lo lee bien."""
import numpy as np, tempfile, os
from pruebas.simulador import simular
from procesamiento.cargador import DTYPE_X, leer_bin
from procesamiento.pipeline import procesar

d, v = simular(duracion_s=120)
n = len(d["t"])
a = np.zeros(n, dtype=DTYPE_X)
# empezar cerca del limite de 32 bits para probar que da la vuelta bien
a["t_us"] = ((d["t"] * 1e6).astype(np.uint64) + 4_294_000_000) % (2**32)
a["ecg"] = np.clip((d["ecg"] + 1.5) / 3.3 * 4095, 0, 4095)   # ADC de 12 bits
a["red"], a["ir"] = d["red"].astype(np.uint32), d["ir"].astype(np.uint32)
ruta = os.path.join(tempfile.mkdtemp(), "reg.bin")
a.tofile(ruta)
x = leer_bin(ruta, 200.0)
z = procesar(x["t"], x["ecg"], x["ir"], x["red"], x["fs"])
print("FC leida del .bin:", round(z[z.valido].FC.median(), 2), "(real 75)")
assert abs(z[z.valido].FC.median() - 75) < 1.5
print("OK")
