// Arma paquetes con el MISMO protocolo.h del firmware, para comprobar que Python los lee.
// Uso: generar salida.pkt    (5 paquetes de 200 muestras; falta el paquete con seq 2)
#include <cstdio>
#include <cstring>
#include <vector>
#include "../../firmware/biodiseno_esp32/protocolo.h"

struct Paquete { Cabecera h; Muestra m[200]; } __attribute__((packed));

int main(int argc, char **argv) {
  FILE *f = fopen(argv[1], "wb");
  uint32_t t = 4294960000u;                    // cerca del limite de 32 bits: prueba la vuelta
  for (uint32_t seq = 0; seq < 5; seq++) {
    Paquete p; memset(&p, 0, sizeof(p));
    memcpy(p.h.magic, "BIO1", 4); p.h.version = PROTO_VERSION; p.h.flags = (seq == 3) ? FLAG_ELECTRODO_SUELTO : 0;
    p.h.n = 200; p.h.paciente = 7; p.h.sesion = 0xCAFEBABE; p.h.seq = seq; p.h.t0_us = t; p.h.epoch_s = 1790000000u + seq;
    for (int i = 0; i < 200; i++) { p.m[i].t_us = t; p.m[i].ecg = (uint16_t)(1000 + seq * 10 + i); p.m[i].red = 100000 + i; p.m[i].ir = 200000 + seq; t += 5000; }
    p.h.crc = crc16_ccitt((const uint8_t *)p.m, 200 * sizeof(Muestra));
    if (seq == 2) continue;                    // simula un paquete perdido en la red
    fwrite(&p, 1, sizeof(Cabecera) + 200 * sizeof(Muestra), f);
    if (seq == 0) fputs("#texto de depuracion con BIO sin el resto\n", f);   // basura entre paquetes
  }
  fclose(f);
  printf("sizeof Muestra=%zu Cabecera=%zu\n", sizeof(Muestra), sizeof(Cabecera));
  return 0;
}
