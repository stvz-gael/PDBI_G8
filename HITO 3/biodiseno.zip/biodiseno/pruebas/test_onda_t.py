"""Onda T alta (como en bidmc06): el metodo por altura la cuenta como R, el de pendiente no.
  python -m pruebas.test_onda_t"""
import numpy as np
from pruebas.simulador import simular
from procesamiento.pipeline import procesar
from procesamiento import config as C

d, v = simular(180, ruido=0.03, t_amp=0.8)
for metodo in ("altura", "pendiente"):
    C.R_METODO = metodo
    z = procesar(d["t"], d["ecg"], d["ir"], d["red"], d["fs"])
    print(f"{metodo:10s} FC mediana = {z.FC.median():6.1f} (real 75) | ventanas validas {int(z.valido.sum())}/{len(z)}")
C.R_METODO = "pendiente"
z = procesar(d["t"], d["ecg"], d["ir"], d["red"], d["fs"])
assert abs(z.FC.median() - 75) < 2 and z.valido.all()
print("OK")
