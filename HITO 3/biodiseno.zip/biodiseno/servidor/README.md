# Servidor

`procesar.py` es lo único que debe invocar el servidor:

```python
from servidor.procesar import procesar_bin, a_registros
z = procesar_bin("reg.bin")      # DataFrame con las columnas del contrato
filas = a_registros(z)           # lista de dicts (NaN -> None), lista para JSON o una base de datos
```

Qué se sube al servidor: `procesamiento/`, `servidor/` y `requirements.txt`.
No se suben `pruebas/`, `validacion/`, `datos/` ni archivos `.bin`.

Dependencias de ejecución: numpy, scipy, pandas y neurokit2 (`requirements.txt`).
`wfdb` y `matplotlib` son solo para validar y no hacen falta aquí.

## Antes de elegir la plataforma
Firebase Hosting solo sirve páginas estáticas, no ejecuta Python. Si se usa Firebase, el procesamiento
tendría que correr en Cloud Functions (Python) o en Cloud Run, y Firestore o Cloud Storage guardarían los datos.
Hay que decidir con quien hizo el firmware cómo sube la ESP32 sus datos (ver "Pendientes del contrato" en `CONTRATO.md`).
