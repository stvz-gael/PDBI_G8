"""Punto de entrada del servidor: archivo x[n] (.bin de la ESP32) -> tabla z[n].

Desde la terminal:
    python -m servidor.procesar entrada.bin salida.csv            # columnas del contrato
    python -m servidor.procesar entrada.bin salida.json --completo # con columnas de diagnostico

Desde otro programa (API, Cloud Function, etc.):
    from servidor.procesar import procesar_bin, a_registros
    z = procesar_bin("reg.bin")
    filas = a_registros(z)          # lista de dicts lista para JSON o una base de datos
"""
import argparse
import json
import math
import os

import numpy as np
import pandas as pd

from procesamiento import config as C
from procesamiento.cargador import leer_bin, leer_paquetes, unir_paquetes, x_desde_array
from procesamiento.pipeline import procesar

# Columnas de z[n] que promete CONTRATO.md (el modelo de IA solo debe depender de estas)
COLUMNAS_Z = ["t_fin", "FC", "HRV_SDNN", "FR", "FR_n", "PAT", "dPAT", "SpO2", "PI",
              "Q_ECG", "Q_PPG", "Q_PAT", "valido", "valido_pat"]


def procesar_bin(ruta, fs=C.FS_DISPOSITIVO, completo=False):
    """Lee un .bin de la ESP32 y devuelve z[n] (una fila por ventana de 60 s, paso de 10 s).
    Si el archivo dura menos de una ventana, devuelve una tabla vacia con las columnas del contrato."""
    x = leer_bin(ruta, fs)
    z = procesar(x["t"], x["ecg"], x["ir"], x["red"], x["fs"])
    if len(z) == 0:
        return pd.DataFrame(columns=COLUMNAS_Z)
    return z if completo else z[COLUMNAS_Z]


def procesar_paquetes(datos, fs=C.FS_DISPOSITIVO, completo=False):
    """Bytes recibidos (uno o varios paquetes BIO1, de UNA sesion) -> (z[n], info).
    info = {paquetes, crc_malos, seq_faltantes}. Paquetes repetidos se ignoran y los perdidos se reportan."""
    paq, _, malos = leer_paquetes(datos)
    a, faltan = unir_paquetes(paq)
    info = dict(paquetes=len(paq), crc_malos=malos, seq_faltantes=faltan)
    if len(a) < 2:
        return pd.DataFrame(columns=COLUMNAS_Z), info
    x = x_desde_array(a, fs)
    z = procesar(x["t"], x["ecg"], x["ir"], x["red"], x["fs"])
    if len(z) == 0:
        return pd.DataFrame(columns=COLUMNAS_Z), info
    return (z if completo else z[COLUMNAS_Z]), info


def _limpio(v):
    """numpy -> tipos de Python; NaN -> None (el JSON estandar no tiene NaN)."""
    if isinstance(v, (np.bool_, bool)):
        return bool(v)
    if isinstance(v, (np.integer, int)):
        return int(v)
    f = float(v)
    return None if math.isnan(f) else f


def a_registros(z):
    """z[n] -> lista de dicts, una por ventana, con tipos que JSON y las bases de datos aceptan."""
    return [{k: _limpio(v) for k, v in fila.items()} for fila in z.to_dict("records")]


def main():
    ap = argparse.ArgumentParser(description="x[n] (.bin) -> z[n] (.csv o .json)")
    ap.add_argument("entrada", help="archivo .bin de la ESP32")
    ap.add_argument("salida", help="archivo de salida: .csv o .json")
    ap.add_argument("--fs", type=float, default=C.FS_DISPOSITIVO, help="frecuencia de muestreo (Hz)")
    ap.add_argument("--completo", action="store_true", help="incluir columnas de diagnostico")
    a = ap.parse_args()
    z = procesar_bin(a.entrada, a.fs, a.completo)
    if a.salida.lower().endswith(".json"):
        with open(a.salida, "w", encoding="utf-8") as f:
            json.dump(a_registros(z), f, ensure_ascii=False)
    else:
        z.to_csv(a.salida, index=False)
    print(f"{len(z)} ventanas -> {os.path.abspath(a.salida)}")


if __name__ == "__main__":
    main()
