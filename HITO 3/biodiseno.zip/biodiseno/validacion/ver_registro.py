"""Mira una senal con tus propios ojos: ECG con las R detectadas y PPG con el pie de onda.
  python -m validacion.ver_registro bidmc04
  python -m validacion.ver_registro bidmc09 --t0 120      (empieza en el segundo 120)
  python -m validacion.ver_registro bidmc03 --metodo altura   (o pendiente)
Tambien imprime si la polaridad del ECG esta invertida (R hacia abajo)."""
import sys
import numpy as np
import matplotlib.pyplot as plt
from procesamiento import config as C
from procesamiento.filtros import pasabanda
from procesamiento import ecg as E
from procesamiento import ppg as P


def calidad_r(ecg_f, fs):
    idx = E.detectar_r(ecg_f, fs)
    if len(idx) < 3:
        return idx, 0.0
    _, ok = E.rr_validos(idx / fs)
    return idx, float(np.mean(ok))


def analizar(d, t0=0.0, dur=15.0, salida=None):
    fs, t = d["fs"], d["t"]
    ecg_f = pasabanda(d["ecg"], fs, *C.ECG_BANDA, C.ORDEN_FILTRO)
    ir_f = pasabanda(d["ir"], fs, *C.PPG_BANDA, C.ORDEN_FILTRO)
    # Misma orientacion y deteccion que usa el pipeline
    ecg_f, idx, invertido = E.orientar(ecg_f, fs)
    _, ok = E.rr_validos(t[idx]) if len(idx) > 2 else (None, np.array([False]))
    print(f"Metodo de R: {C.R_METODO} | R detectadas: {len(idx)} | RR validos: {np.mean(ok):.2f}")
    print(f"ECG volteado por el programa: {invertido}")
    if len(idx) > 2:
        print(f"FC estimada: {60.0 / np.median(np.diff(t[idx])):.1f} lpm")
    pat = P.pat_por_latido(t, ir_f, t[idx], fs)
    print(f"PAT medido en {np.mean(~np.isnan(pat)):.0%} de los latidos"
          + (f", mediana {np.nanmedian(pat):.3f} s" if np.any(~np.isnan(pat)) else ""))

    m = (t >= t0) & (t < t0 + dur)
    fig, ax = plt.subplots(2, 1, figsize=(12, 6), sharex=True)
    ax[0].plot(t[m], ecg_f[m], lw=0.8)
    mr = (t[idx] >= t0) & (t[idx] < t0 + dur)
    ax[0].plot(t[idx][mr], ecg_f[idx][mr], "rv", label="R detectadas")
    ax[0].set_ylabel("ECG filtrado"); ax[0].legend()
    ax[1].plot(t[m], ir_f[m], lw=0.8, color="tab:green")
    for k in np.where(mr)[0]:
        if not np.isnan(pat[k]):
            ax[1].axvline(t[idx][k] + pat[k], color="purple", lw=0.8, ls="--")
    ax[1].set_ylabel("PPG filtrado"); ax[1].set_xlabel("tiempo (s)")
    ax[1].set_title("lineas moradas = pie de onda (PAT medido)", fontsize=9)
    plt.tight_layout()
    if salida:
        plt.savefig(salida, dpi=100)
    else:
        plt.show()


if __name__ == "__main__":
    from validacion.datasets import leer_bidmc
    reg = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") else "bidmc04"
    t0 = float(sys.argv[sys.argv.index("--t0") + 1]) if "--t0" in sys.argv else 0.0
    if "--metodo" in sys.argv:
        C.R_METODO = sys.argv[sys.argv.index("--metodo") + 1]   # "altura" o "pendiente"
    analizar(leer_bidmc(reg), t0)