"""Lectores de las bases publicas (BIDMC y MIMIC-III) para validar el procesamiento.
Entregan el mismo formato que procesamiento.cargador: dict(t, ecg, ir, red, fs)."""
import os
import time
import pickle
import numpy as np


def _norm(nombres):
    """BIDMC escribe 'II,' 'PLETH,' 'RESP,': quita comas, espacios y mayusculas."""
    return [n.strip().strip(",").strip().upper() for n in nombres]


DIR_CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "datos", "cache_bidmc")


def _con_cache(sufijo):
    """Guarda en disco lo que se baja de PhysioNet (una sola vez) y reintenta si el servidor falla
    (p. ej. 502 Bad Gateway). Asi las corridas de 53 registros no dependen de la red."""
    def deco(fn):
        def envuelta(nombre="bidmc01", *a, **k):
            ruta = os.path.join(DIR_CACHE, f"{nombre}_{sufijo}.pkl")
            if os.path.exists(ruta):
                try:
                    with open(ruta, "rb") as f:
                        return pickle.load(f)
                except Exception:
                    pass                      # cache danada: se vuelve a bajar
            for intento in range(5):
                try:
                    res = fn(nombre, *a, **k)
                    break
                except Exception:
                    if intento == 4:
                        raise
                    time.sleep(2 * (intento + 1))
            os.makedirs(DIR_CACHE, exist_ok=True)
            with open(ruta, "wb") as f:
                pickle.dump(res, f)
            return res
        envuelta.__doc__ = fn.__doc__
        return envuelta
    return deco


@_con_cache("sig")
def leer_bidmc(nombre="bidmc01", fs=None):
    """BIDMC (PhysioNet): ECG derivacion II y PPG (PLETH) a 125 Hz.
    No tiene PPG rojo, asi que red=None (SpO2 no se puede probar aqui)."""
    import wfdb
    r = wfdb.rdrecord(nombre, pn_dir="bidmc")
    nom = _norm(r.sig_name)
    for need in ("II", "PLETH"):
        if need not in nom:
            raise ValueError(f"Falta {need}. Senales del registro: {r.sig_name}")
    ecg = r.p_signal[:, nom.index("II")]
    ppg = r.p_signal[:, nom.index("PLETH")]
    t = np.arange(len(ecg)) / r.fs
    return dict(t=t, fs=float(r.fs), ecg=ecg, ir=ppg, red=None)


@_con_cache("num")
def leer_bidmc_numericos(nombre="bidmc01"):
    """Valores de referencia de BIDMC (HR, RESP, SpO2), 1 muestra por segundo."""
    import wfdb
    r = wfdb.rdrecord(nombre + "n", pn_dir="bidmc")
    nom = _norm(r.sig_name)
    return {n: r.p_signal[:, i] for i, n in enumerate(nom)}, r.fs


# ---------------------------------------------------------------- MIMIC-III (waveform)
MIMIC_BD = "mimic3wdb-matched/1.0"      # abierta (ODbL), ~2.4 TB: se lee por internet, no se baja


def mimic_buscar(n_max=10, min_s=600, bd=MIMIC_BD, max_registros=400, semilla=0):
    """Busca segmentos con ECG II + PLETH + ABP de al menos min_s segundos.
    Devuelve lista de (pn_dir, segmento, largo_s). Solo lee cabeceras (liviano)."""
    import wfdb
    import random
    import requests
    # RECORDS-waveforms: un registro maestro por linea, ej. p00/p000020/p000020-2183-04-28-17-47
    txt = requests.get(f"https://physionet.org/files/{bd}/RECORDS-waveforms", timeout=60).text
    recs = [l.strip() for l in txt.splitlines() if l.strip() and not l.strip().endswith("/")]
    random.Random(semilla).shuffle(recs)
    out = []
    for rec in recs[:max_registros]:
        carpeta, nombre = rec.rsplit("/", 1)[0], rec.rsplit("/", 1)[1]
        pn = f"{bd}/{carpeta}"
        try:
            h = wfdb.rdheader(nombre, pn_dir=pn)
        except Exception:
            continue
        if not hasattr(h, "seg_name"):
            continue
        for s, ln in zip(h.seg_name[1:], h.seg_len[1:]):
            if s == "~" or ln < min_s * 125:
                continue
            try:
                hs = wfdb.rdheader(s, pn_dir=pn)
            except Exception:
                continue
            if all(k in _norm(hs.sig_name) for k in ("II", "PLETH", "ABP")):
                out.append((pn, s, ln / hs.fs))
                break                      # un segmento por paciente
        if len(out) >= n_max:
            break
    return out


def leer_mimic(pn_dir, segmento, max_s=1800, max_nan=0.05):
    """Un segmento de MIMIC-III waveform: ECG II, PLETH y ABP a 125 Hz.
    Devuelve dict(t, fs, ecg, ir, red=None, abp). Rechaza si hay demasiados NaN."""
    import wfdb
    largo = wfdb.rdheader(segmento, pn_dir=pn_dir).sig_len
    r = wfdb.rdrecord(segmento, pn_dir=pn_dir, sampto=min(int(max_s * 125), largo))
    nom = _norm(r.sig_name)
    out = {}
    for clave, nombre in (("ecg", "II"), ("ir", "PLETH"), ("abp", "ABP")):
        if nombre not in nom:
            raise ValueError(f"Falta {nombre}. Senales: {r.sig_name}")
        y = r.p_signal[:, nom.index(nombre)].astype(float)
        mal = np.isnan(y)
        if mal.mean() > max_nan:
            raise ValueError(f"{nombre}: {mal.mean():.0%} NaN")
        if mal.any():
            y[mal] = np.interp(np.flatnonzero(mal), np.flatnonzero(~mal), y[~mal])
        out[clave] = y
    t = np.arange(len(out["ecg"])) / r.fs
    return dict(t=t, fs=float(r.fs), red=None, **out)


def unir_marcas(t_s, tol_s=1.0):
    """Une marcas de respiracion de varios anotadores: las que caen a menos de tol_s cuentan como UNA."""
    t_s = np.sort(np.asarray(t_s, float))
    grupos = []
    for x in t_s:
        if grupos and x - grupos[-1][-1] < tol_s:
            grupos[-1].append(x)
        else:
            grupos.append([x])
    return np.array([np.mean(g) for g in grupos]), len(t_s)


@_con_cache("resp")
def leer_bidmc_respiraciones(nombre="bidmc01"):
    """BIDMC trae respiraciones marcadas A MANO por dos anotadores (archivo bidmcXX.breath).
    Es mejor referencia que el RESP numerico, que lo calcula el monitor. Devuelve (t_resp en s, n_marcas)."""
    import wfdb
    a = wfdb.rdann(nombre, "breath", pn_dir="bidmc")
    fs = getattr(a, "fs", None) or 125.0
    return unir_marcas(np.asarray(a.sample, float) / fs)