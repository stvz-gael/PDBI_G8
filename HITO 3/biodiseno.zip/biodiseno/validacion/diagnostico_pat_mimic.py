"""Por que el PAT sale invalido en MIMIC? Cuenta, por paciente, por que se descarta cada latido.
  python -m validacion.diagnostico_pat_mimic                  tabla de todos los segmentos de datos/mimic_lista.txt
  python -m validacion.diagnostico_pat_mimic --ver 3851274_0004 --t0 300     dibuja ECG (R) y PPG (pie) de ese segmento
Columnas (todas en % de latidos): sin_pulso = la pendiente del PPG no es una subida real; borde = la subida
cae pegada al borde de la ventana de busqueda; fuera = PAT medido pero fuera de 0.08-0.60 s; ok = PAT valido.
PAT_ancho = mediana del PAT buscando en una ventana mas ancha (0 a 1 s): si cae fuera de 0.08-0.60 s,
hay un desfase fijo entre ECG y PPG (reloj, filtro o sitio de medida), no un fallo del metodo."""
import os
import sys
import numpy as np
import pandas as pd
from procesamiento import config as C
from procesamiento import ecg as E
from procesamiento import ppg as P
from procesamiento.filtros import pasabanda
from validacion.datasets import leer_mimic
from .evaluar_mimic import LISTA


def diagnosticar(d):
    fs, t = d["fs"], d["t"]
    ecg_f = pasabanda(d["ecg"], fs, *C.ECG_BANDA, C.ORDEN_FILTRO)
    ir_f = pasabanda(d["ir"], fs, *C.PPG_BANDA, C.ORDEN_FILTRO)
    inv = P.invertido(ir_f, fs) if C.PPG_INVERTIDO is None else bool(C.PPG_INVERTIDO)
    ir_f = -ir_f if inv else ir_f
    ecg_f, _, _ = E.orientar(ecg_f, fs)
    idx = E.detectar_r(ecg_f, fs, C.R_METODO if C.R_METODO != "auto" else "pendiente")
    t_r = t[idx]
    dd = np.gradient(ir_f, 1.0 / fs)
    pend_min = C.PAT_PEND_MIN_FRAC * np.percentile(dd, 99)
    cuenta = dict(sin_pulso=0, borde=0, fuera=0, ok=0, sin_ventana=0)
    ancho = []
    for tr in t_r:
        i0 = int(np.searchsorted(t, tr + C.PAT_BUSQUEDA_S[0]))
        i1 = int(np.searchsorted(t, tr + C.PAT_BUSQUEDA_S[1]))
        if i1 - i0 < 5 or i1 >= len(t):
            cuenta["sin_ventana"] += 1
            continue
        im = i0 + int(np.argmax(dd[i0:i1]))
        if dd[im] < pend_min:
            cuenta["sin_pulso"] += 1
        elif im >= i1 - 3:
            cuenta["borde"] += 1
        else:
            ib = max(int(np.searchsorted(t, tr)), im - int(0.3 * fs))
            base = np.min(ir_f[ib:im + 1])
            pat = t[im] - (ir_f[im] - base) / dd[im] - tr
            cuenta["ok" if C.PAT_VALIDO_S[0] <= pat <= C.PAT_VALIDO_S[1] else "fuera"] += 1
        # ventana ancha: instante de maxima pendiente entre 0 y 1 s despues de la R
        j0, j1 = int(np.searchsorted(t, tr)), int(np.searchsorted(t, tr + 1.0))
        if j1 - j0 > 5 and j1 < len(t):
            ancho.append(t[j0 + int(np.argmax(dd[j0:j1]))] - tr)
    n = max(len(t_r), 1)
    fila = {k: round(100 * v / n) for k, v in cuenta.items()}
    fila.update(latidos=len(t_r), ppg_inv=inv,
                PAT_ancho=round(float(np.median(ancho)), 3) if ancho else np.nan,
                IQR_ancho=round(float(np.subtract(*np.percentile(ancho, [75, 25]))), 3) if ancho else np.nan)
    return fila


def main():
    if "--ver" in sys.argv:
        from .ver_registro import analizar
        seg = sys.argv[sys.argv.index("--ver") + 1]
        t0 = float(sys.argv[sys.argv.index("--t0") + 1]) if "--t0" in sys.argv else 0.0
        for linea in open(LISTA):
            pn, s, _ = linea.strip().split("\t")
            if s == seg:
                analizar(leer_mimic(pn, s), t0)
                return
        print(f"{seg} no esta en {LISTA}")
        return
    filas = []
    for linea in open(LISTA):
        pn, s, _ = linea.strip().split("\t")
        try:
            f = diagnosticar(leer_mimic(pn, s))
            f["registro"] = s
            filas.append(f)
        except Exception as e:
            print(f"  {s}: omitido ({e})")
    pd.set_option("display.width", 200)
    print(pd.DataFrame(filas).set_index("registro").to_string())


if __name__ == "__main__":
    main()
