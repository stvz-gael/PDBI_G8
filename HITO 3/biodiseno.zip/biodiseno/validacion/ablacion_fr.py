"""Que fuentes conviene fusionar? Prueba las 15 combinaciones de las 4 fuentes.
Decide con los registros 1 a 26 (grupo A) y COMPRUEBA con 27 a 53 (grupo B):
si una combinacion gana en A pero no en B, era casualidad.
  python -m validacion.ablacion_fr            (53 registros, la 1.a vez tarda)
  python -m validacion.ablacion_fr --rapido   (10 registros)
  python -m validacion.ablacion_fr --monitor  referencia = RESP del monitor (la de antes)
Por defecto la referencia son las respiraciones marcadas a mano (BIDMC), que es mejor que el RESP del monitor.
Se omiten los registros donde los dos anotadores casi no coinciden (marcas/unicas < 1.5, p. ej. bidmc44)."""
import sys
import numpy as np
import pandas as pd
from ._comun import REGISTROS, z_de_registro, ref_en, fr_con_fuentes, subconjuntos


USAR_MONITOR = "--monitor" in sys.argv


def error_registro(reg, fuentes):
    z, num, fs_n = z_de_registro(reg)
    z = z[z["valido"]]
    if len(z) == 0 or "RESP" not in num:
        return np.nan
    if USAR_MONITOR:
        ref = ref_en(z, num, fs_n, "RESP")
    else:
        from validacion.datasets import leer_bidmc_respiraciones
        from .evaluar_fr_anotada import rr_anotada
        t_resp, n_marcas = leer_bidmc_respiraciones(reg)
        if n_marcas / max(len(t_resp), 1) < 1.5:
            return np.nan
        ref = rr_anotada(z["t_fin"].values, t_resp)
    return float(np.nanmean(np.abs(fr_con_fuentes(z, fuentes).values - ref)))


if __name__ == "__main__":
    regs = REGISTROS[:10] if "--rapido" in sys.argv else REGISTROS
    mitad = len(regs) // 2
    A, B = regs[:mitad], regs[mitad:]
    filas = []
    for fu in subconjuntos():
        eA = [error_registro(r, fu) for r in A]
        eB = [error_registro(r, fu) for r in B]
        filas.append({"fuentes": "+".join(fu),
                      "A_media": np.nanmean(eA), "A_mediana": np.nanmedian(eA),
                      "B_media": np.nanmean(eB), "B_mediana": np.nanmedian(eB)})
    df = pd.DataFrame(filas).sort_values("A_media").reset_index(drop=True)
    print(f"\nGrupo A = {len(A)} registros (decidir). Grupo B = {len(B)} registros (comprobar).")
    print("Referencia: " + ("RESP del monitor" if USAR_MONITOR else "respiraciones anotadas a mano"))
    print("Error absoluto medio de FR (rpm), ordenado por A_media:\n")
    print(df.round(2).to_string())
    mejor = df.iloc[0]
    print(f"\nMejor en A: {mejor['fuentes']}  (A={mejor['A_media']:.2f}, B={mejor['B_media']:.2f})")
    todas = df[df["fuentes"] == "+".join(["edr", "rsa", "ppga", "ppgb"])].iloc[0]
    print(f"Las 4 fuentes: A={todas['A_media']:.2f}, B={todas['B_media']:.2f}")