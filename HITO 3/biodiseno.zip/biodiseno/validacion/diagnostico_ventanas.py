"""Por que se descartan ventanas? Muestra, por registro, que criterio falla.
  python -m validacion.diagnostico_ventanas
Tambien prueba el PPG invertido y normal, por si la polaridad fuera el problema."""
import sys
import numpy as np
import pandas as pd
from procesamiento import config as C
from procesamiento.pipeline import procesar
from ._comun import REGISTROS, leer_bidmc, leer_bidmc_numericos, ref_en

regs = REGISTROS if "--todos" in sys.argv else REGISTROS[:10]
filas = []
for reg in regs:
    d = leer_bidmc(reg)
    num, fs_n = leer_bidmc_numericos(reg)
    fila = {"registro": reg}
    for inv in (None, True):
        C.PPG_INVERTIDO = inv
        z = procesar(d["t"], d["ecg"], d["ir"], None, d["fs"])
        etq = "forzado_inv" if inv else "auto"
        fila[f"Qppg_{etq}"] = z["Q_PPG"].median()
        if inv is None:
            fila["ventanas"] = len(z)
            fila["validas"] = int(z["valido"].sum())
            fila["falla_ECG"] = int((z["Q_ECG"] < C.Q_ECG_MIN).sum())
            fila["falla_PPG"] = int((z["Q_PPG"] < C.Q_PPG_MIN).sum())
            fila["validas_PAT"] = int(z["valido_pat"].sum())
            fila["falla_PAT"] = int((z["Q_PAT"] < C.Q_PAT_MIN).sum())
            fila["metodo_R"] = z.attrs.get("metodo_r", "")
            fila["falla_acuerdo"] = int((~z["acuerdo"]).sum())
            fila["Qecg_med"] = z["Q_ECG"].median()
            fila["ECG_inv"] = bool(z.attrs.get("ecg_invertido", False))
            fila["PPG_inv"] = bool(z.attrs.get("ppg_invertido", False))
            if "HR" in num and len(z):
                fila["FC_ref"] = np.nanmean(ref_en(z, num, fs_n, "HR"))
                fila["FC_est"] = z["FC"].median()
    C.PPG_INVERTIDO = None
    filas.append(fila)
pd.set_option("display.width", 220)
print(pd.DataFrame(filas).set_index("registro").round(2).to_string())
print("\nfalla_ECG / falla_PPG / falla_acuerdo = ventanas que no pasan (acuerdo = FC del ECG distinta del pulso del PPG). Qppg_auto (polaridad automatica) vs Qppg_forzado_inv (forzada al reves):")
print("PPG_inv / ECG_inv = True si el programa volteo esa senal.")