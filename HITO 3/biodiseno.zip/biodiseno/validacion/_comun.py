"""Funciones compartidas por los scripts de evaluacion con BIDMC."""
import os
import glob
import hashlib
import itertools
import numpy as np
import pandas as pd
from validacion.datasets import leer_bidmc, leer_bidmc_numericos
from procesamiento.pipeline import procesar
from procesamiento.respiracion import fusionar
from procesamiento import config as C

REGISTROS = [f"bidmc{i:02d}" for i in range(1, 54)]
FUENTES = ["edr", "rsa", "ppga", "ppgb"]
CACHE = os.path.join("datos", "cache_z")


def _huella():
    """Resumen de todos los .py de procesamiento/: si cambias el codigo, cambia la huella
    y la cache vieja deja de usarse sola (no hace falta borrar nada)."""
    h = hashlib.md5()
    aqui = os.path.dirname(os.path.abspath(__file__))
    for f in sorted(glob.glob(os.path.join(aqui, "..", "procesamiento", "*.py"))):
        with open(f, "rb") as fh:
            h.update(fh.read())
    return h.hexdigest()[:8]


REF_RESP_MIN = 4.0      # rpm: por debajo es dato faltante de BIDMC (ceros), no respiracion real


def ref_en(z, num, fs_n, col):
    """Promedio de la referencia (1 Hz) dentro de cada ventana de 60 s de z.
    Para RESP se descartan las muestras < 4 rpm (BIDMC rellena con 0 cuando falta el dato);
    si queda menos del 70 % de la ventana, la ventana no tiene referencia (NaN) y no se evalua."""
    v = num[col]
    out = []
    for tf in z["t_fin"]:
        x = np.asarray(v[int((tf - 60) * fs_n):int(tf * fs_n)], dtype=float)
        if col == "RESP":
            buenas = x[x >= REF_RESP_MIN]
            out.append(np.mean(buenas) if len(x) and len(buenas) >= 0.7 * len(x) else np.nan)
        else:
            out.append(np.nanmean(x) if len(x) else np.nan)
    return np.array(out)


def z_de_registro(reg, usar_cache=True):
    """Devuelve (z, numericos, fs_num). Guarda z en disco: la 2.a vez es instantanea.
    La cache se invalida sola si cambia el codigo de procesamiento/."""
    os.makedirs(CACHE, exist_ok=True)
    ruta = os.path.join(CACHE, f"{reg}_{_huella()}.pkl")
    num, fs_n = leer_bidmc_numericos(reg)
    if usar_cache and os.path.exists(ruta):
        return pd.read_pickle(ruta), num, fs_n
    d = leer_bidmc(reg)
    z = procesar(d["t"], d["ecg"], d["ir"], None, d["fs"])
    z.to_pickle(ruta)
    return z, num, fs_n


def fr_con_fuentes(z, fuentes, suave_n=None):
    """Recalcula la FR final usando solo 'fuentes' (lista de nombres)."""
    suave_n = suave_n or C.FR_SUAVE_N
    crudas = []
    for _, r in z.iterrows():
        cands = {f: (r[f"FR_{f}"], r[f"FR_{f}_p"]) for f in fuentes}
        crudas.append(fusionar(cands)[0])
    s = pd.Series(crudas, index=z.index).where(z["valido"])
    return s.rolling(suave_n, min_periods=1).median().where(z["valido"])


def subconjuntos():
    for k in range(1, len(FUENTES) + 1):
        for c in itertools.combinations(FUENTES, k):
            yield list(c)