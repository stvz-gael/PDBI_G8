"""Evalua la FR contra las respiraciones marcadas A MANO en BIDMC (mejor referencia que el RESP del monitor).
  python -m validacion.evaluar_fr_anotada               tabla por registro + resumen (ventanas validas)
  python -m validacion.evaluar_fr_anotada --detalle bidmc33     ventana a ventana: monitor, anotada, fuentes y FR final
Referencia anotada por ventana de 60 s = 60 / mediana del intervalo entre respiraciones (>= 5 respiraciones).
Las marcas de los dos anotadores se unen (las que caen a menos de 1 s cuentan como una): 'marcas/unicas' ~ 2
indica que ambos anotaron casi lo mismo; ~ 1 indica que casi no coinciden."""
import sys
import numpy as np
import pandas as pd
from ._comun import z_de_registro, ref_en, REGISTROS
from procesamiento import config as C
from validacion.datasets import leer_bidmc_respiraciones


def rr_anotada(t_fin, t_resp):
    out = []
    for tf in t_fin:
        w = t_resp[(t_resp >= tf - C.VENTANA_S) & (t_resp < tf)]
        out.append(60.0 / np.median(np.diff(w)) if len(w) >= 5 else np.nan)
    return np.array(out)


def cargar(reg):
    z, num, fs_n = z_de_registro(reg)
    t_resp, n_marcas = leer_bidmc_respiraciones(reg)
    z = z.copy()
    z["anot"] = rr_anotada(z["t_fin"].values, t_resp)
    z["monitor"] = ref_en(z, num, fs_n, "RESP")
    return z, n_marcas / max(len(t_resp), 1)


def detalle(reg):
    z, r = cargar(reg)
    cols = ["t_fin", "monitor", "anot", "FR_edr", "FR_ppgb", "FR", "valido"]
    pd.set_option("display.width", 200)
    print(f"{reg}: marcas/unicas = {r:.2f}")
    print(z[cols].round(1).to_string(index=False))
    k = z["valido"] & ~z["anot"].isna()
    print(f"\nMediana |monitor - anotada| = {np.nanmedian(np.abs(z.loc[k, 'monitor'] - z.loc[k, 'anot'])):.2f} rpm | "
          f"|FR - anotada| = {np.nanmedian(np.abs(z.loc[k, 'FR'] - z.loc[k, 'anot'])):.2f} rpm")


def main():
    if "--detalle" in sys.argv:
        detalle(sys.argv[sys.argv.index("--detalle") + 1])
        return
    filas = []
    A, F, E_, P_, M_ = [], [], [], [], []          # todas las ventanas validas con referencia anotada
    for reg in REGISTROS:
        z, r = cargar(reg)
        k = z["valido"].values & ~np.isnan(z["anot"].values)
        if not k.any():
            filas.append(dict(registro=reg, marcas_unicas=round(r, 2), ventanas=0))
            continue
        a, fr, mon = z["anot"].values[k], z["FR"].values[k], z["monitor"].values[k]
        km = ~np.isnan(mon)
        A += list(a); F += list(fr); M_ += list(np.where(km, mon, np.nan))
        E_ += list(z["FR_edr"].values[k]); P_ += list(z["FR_ppgb"].values[k])
        filas.append(dict(registro=reg, marcas_unicas=round(r, 2), ventanas=int(k.sum()),
                          err_FR_vs_anot=np.mean(np.abs(fr - a)),
                          err_monitor_vs_anot=np.mean(np.abs(mon[km] - a[km])) if km.any() else np.nan,
                          razon_mediana=np.median(fr / a)))
    df = pd.DataFrame(filas).set_index("registro")
    pd.set_option("display.width", 200)
    print(df.round(2).to_string())
    A, F, E_, P_, M_ = (np.array(x, float) for x in (A, F, E_, P_, M_))
    e_fr, e_mon = np.abs(F - A), np.abs(M_ - A)
    e_mon = e_mon[~np.isnan(e_mon)]
    print(f"\nVentanas validas con referencia anotada: {len(e_fr)}")
    for nom, e in (("FR de este proyecto vs anotada", e_fr), ("RESP del monitor vs anotada", e_mon)):
        print(f"{nom:<34} media {e.mean():.2f} | mediana {np.median(e):.2f} | p95 {np.percentile(e, 95):.2f} | "
              f"<= 2 rpm: {100*np.mean(e <= 2):.1f} %")
    dudosos = df[df["err_monitor_vs_anot"] > 3].index.tolist()
    print(f"\nRegistros donde el monitor se aleja > 3 rpm de la anotada (referencia del monitor dudosa): {dudosos}")
    # Que tipo de error es? (prueba de la hipotesis del armonico)
    grande = e_fr > 3
    r_ = F[grande] / A[grande]
    n2, nh, no = np.sum((r_ >= 1.8) & (r_ <= 2.2)), np.sum((r_ >= 0.45) & (r_ <= 0.55)), 0
    no = int(grande.sum() - n2 - nh)
    print(f"\nVentanas con error > 3 rpm: {int(grande.sum())} ({100*grande.mean():.1f} %). Razon FR / anotada:")
    print(f"  ~2x (armonico, 1.8 a 2.2): {int(n2)} | ~0.5x (subarmonico, 0.45 a 0.55): {int(nh)} | otras: {no}")
    # Que aportaria elegir mejor entre fuentes? ('oraculo' = elegir la mejor de las dos en cada ventana; NO se puede hacer en vivo)
    ee, ep = np.abs(E_ - A), np.abs(P_ - A)
    orac = np.fmin(ee, ep)
    print("\nError medio contra la anotada, por fuente (ventanas validas):")
    print(f"  solo EDR {np.nanmean(ee):.2f} | solo PPGb {np.nanmean(ep):.2f} | FR final {e_fr.mean():.2f} | "
          f"oraculo (mejor de las 2) {np.nanmean(orac):.2f}")


if __name__ == "__main__":
    main()