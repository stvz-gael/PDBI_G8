"""Cuantas alarmas FALSAS de frecuencia respiratoria evita el control de calidad de senal.
  python -m validacion.alarmas_fr                  BIDMC tal cual (53 registros)
  python -m validacion.alarmas_fr --artefactos     BIDMC + ruido de movimiento SIMULADO (10 % del tiempo)
Compara dos formas de emitir la FR:
  SIN calidad: FR_cruda de todas las ventanas (como un monitor ingenuo)
  CON calidad: FR final, solo en ventanas validas (las dudosas no emiten numero)
Alarma = FR <= 8 o >= 25 rpm (extremos de NEWS2). Referencia = RESP del monitor (limpiada como en evaluar_bidmc).
Falsa alarma = el sistema alarma y la referencia esta en rango normal.
'Sostenida' = alarma en 3 ventanas seguidas (30 s mas de datos nuevos): asi se disenan las alarmas reales.
OJO: las ventanas se traslapan (60 s cada 10 s), asi que se cuentan ventanas, no eventos independientes."""
import sys
import numpy as np
import pandas as pd
from ._comun import z_de_registro, ref_en, REGISTROS
from procesamiento import config as C
from validacion.datasets import leer_bidmc, leer_bidmc_numericos
from procesamiento.pipeline import procesar

FR_BAJA, FR_ALTA = 8.0, 25.0
N_SOSTENIDA = 3


def es_alarma(x):
    x = np.asarray(x, float)
    return (~np.isnan(x)) & ((x <= FR_BAJA) | (x >= FR_ALTA))


def sostenida(a, n=N_SOSTENIDA):
    out = np.zeros(len(a), bool)
    for i in range(n - 1, len(a)):
        out[i] = a[i - n + 1:i + 1].all()
    return out


def poner_artefactos(d, frac=0.10, semilla=0):
    """Ruido de movimiento SIMULADO: rafagas de 5 a 15 s en ECG y PPG que cubren ~frac del tiempo."""
    rng = np.random.default_rng(semilla)
    n, fs = len(d["t"]), d["fs"]
    ecg, ir = d["ecg"].copy(), d["ir"].copy()
    s_e, s_i = np.std(ecg), np.std(ir)
    cubierto, objetivo = 0, int(frac * n)
    while cubierto < objetivo:
        dur = int(rng.uniform(5, 15) * fs)
        i0 = int(rng.integers(0, max(1, n - dur)))
        for x, s in ((ecg, s_e), (ir, s_i)):
            r = np.convolve(rng.normal(0, 1.5 * s, dur), np.ones(5) / 5, mode="same")
            x[i0:i0 + dur] += r
        cubierto += dur
    return dict(d, ecg=ecg, ir=ir)


VARIANTES = [("sin", "sin calidad ni suavizado"), ("cal", "solo calidad"),
             ("sua", "solo suavizado (mediana 5)"), ("con", "calidad + suavizado")]


def contar(z, ref):
    """Cuenta alarmas de una serie z contra la referencia ref (una por ventana, NaN = sin referencia).
    4 variantes, para separar el efecto de la calidad del efecto del suavizado:
      sin = FR_cruda de todas las ventanas | cal = FR_cruda solo en ventanas validas
      sua = FR_cruda suavizada (mediana de 5 ventanas) sin descartar | con = FR final (validas + suavizado)"""
    ok = ~np.isnan(ref)
    ref_al = es_alarma(ref)
    cruda = z["FR_cruda"]
    series = {"sin": cruda.values,
              "cal": cruda.where(z["valido"]).values,
              "sua": cruda.rolling(C.FR_SUAVE_N, min_periods=1).median().values,
              "con": z["FR"].values}
    fila = dict(ventanas=int(ok.sum()), ref_alarma=int((ref_al & ok).sum()))
    for nombre, est in series.items():
        al = es_alarma(est)
        sos = sostenida(al)
        fila[f"{nombre}_cobertura"] = int((~np.isnan(est) & ok).sum())
        fila[f"{nombre}_falsas"] = int((al & ~ref_al & ok).sum())
        fila[f"{nombre}_ciertas"] = int((al & ref_al & ok).sum())
        fila[f"{nombre}_falsas_sost"] = int((sos & ~ref_al & ok).sum())
        fila[f"{nombre}_bajas"] = int((al & (est <= FR_BAJA) & ~ref_al & ok).sum())
        fila[f"{nombre}_altas"] = int((al & (est >= FR_ALTA) & ~ref_al & ok).sum())
    return fila


def main():
    art = "--artefactos" in sys.argv
    filas = []
    for k, reg in enumerate(REGISTROS):
        num, fs_n = leer_bidmc_numericos(reg)
        if art:
            d = poner_artefactos(leer_bidmc(reg), semilla=k)
            z = procesar(d["t"], d["ecg"], d["ir"], None, d["fs"])
        else:
            z, _, _ = z_de_registro(reg)
        f = contar(z, ref_en(z, num, fs_n, "RESP"))
        f["registro"] = reg
        filas.append(f)
    df = pd.DataFrame(filas).set_index("registro")
    pd.set_option("display.width", 200)
    t = df.sum()
    horas = t["ventanas"] * C.PASO_S / 3600
    print(("BIDMC + ARTEFACTOS SIMULADOS" if art else "BIDMC (senal original)") +
          f" | {int(t['ventanas'])} ventanas con referencia (~{horas:.1f} h) | ventanas con FR de referencia en alarma: {int(t['ref_alarma'])}")
    print("\n" + " " * 30 + "".join(f"{n:>14}" for n, _ in VARIANTES))
    print(" " * 30 + "".join(f"{e[:13]:>14}" for _, e in [(0, "sin cal/suav"), (0, "solo calidad"), (0, "solo suav."), (0, "cal + suav.")]))
    def fila_(nombre, clave, fmt="{:>14d}", div=1.0):
        print(f"{nombre:<30}" + "".join(fmt.format(int(t[f'{n}_{clave}']) if div == 1.0 else t[f'{n}_{clave}'] / div) for n, _ in VARIANTES))
    fila_("ventanas con numero de FR", "cobertura")
    fila_("falsas alarmas (ventanas)", "falsas")
    fila_("  por FR baja (<= 8)", "bajas")
    fila_("  por FR alta (>= 25)", "altas")
    fila_("falsas alarmas por hora", "falsas", "{:>14.1f}", horas)
    fila_("falsas SOSTENIDAS (3 vent.)", "falsas_sost")
    fila_(f"ciertas detectadas (de {int(t['ref_alarma'])})", "ciertas")
    print("\nRegistros con mas falsas alarmas SIN calidad ni suavizado:")
    print(df.sort_values("sin_falsas", ascending=False)[["ventanas", "sin_falsas", "cal_falsas", "sua_falsas", "con_falsas", "sin_falsas_sost", "con_falsas_sost"]].head(8).to_string())


if __name__ == "__main__":
    main()