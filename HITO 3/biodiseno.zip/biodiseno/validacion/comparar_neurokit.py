"""Compara TU codigo contra NeuroKit2 en BIDMC (mismas ventanas validas, misma referencia).
  python -m validacion.comparar_neurokit            10 registros
  python -m validacion.comparar_neurokit --todos    53 registros
Compara: (1) detector de R y FC, (2) FR desde el ECG (EDR de NeuroKit vs tu fusion).
Variantes de NeuroKit:
  NK_filtrado: detector de NeuroKit sobre TU senal ya filtrada y orientada (comparacion justa del detector)
  NK_crudo   : NeuroKit completo (su propio filtro) sobre la senal cruda (incluye ECG invertido)
"""
import sys
import warnings
import numpy as np
import pandas as pd
import neurokit2 as nk
from ._comun import z_de_registro, ref_en, REGISTROS
from procesamiento import config as C
from procesamiento import ecg as E
from validacion.datasets import leer_bidmc
from procesamiento.filtros import pasabanda

warnings.filterwarnings("ignore")


def picos_nk(x, fs, limpiar):
    if limpiar:
        x = nk.ecg_clean(x, sampling_rate=fs)
    return np.asarray(nk.ecg_peaks(x, sampling_rate=fs, method="neurokit")[1]["ECG_R_Peaks"], dtype=int)


def fc_ventanas(t_r, t_fin):
    out = []
    for tf in t_fin:
        w = t_r[(t_r >= tf - C.VENTANA_S) & (t_r < tf)]
        out.append(E.fc_hrv(w)[0] if len(w) >= 3 else np.nan)
    return np.array(out)


def fr_nk_ventanas(idx, n, fs, t_fin):
    """EDR de NeuroKit (Van Gent 2019, desde la FC instantanea) y su frecuencia respiratoria por ventana."""
    tasa = nk.signal_rate(idx, sampling_rate=fs, desired_length=n)
    rsp = nk.ecg_rsp(tasa, sampling_rate=fs, method="vangent2019")
    fr = np.asarray(nk.rsp_rate(rsp, sampling_rate=fs, method="trough"), dtype=float)
    t = np.arange(n) / fs
    return np.array([np.nanmedian(fr[(t >= tf - C.VENTANA_S) & (t < tf)]) for tf in t_fin])


def concordancia(a, b, fs, tol_s=0.05):
    """Fraccion de latidos de 'a' que tienen un latido de 'b' a menos de tol_s."""
    if len(a) == 0 or len(b) == 0:
        return np.nan
    k = np.searchsorted(b, a)
    d = np.minimum(np.abs(a - b[np.clip(k, 0, len(b) - 1)]), np.abs(a - b[np.clip(k - 1, 0, len(b) - 1)]))
    return float(np.mean(d <= tol_s * fs))


def comparar(d, z, num, fs_n, nombre="reg"):
    fs, t = d["fs"], d["t"]
    z = z[z["valido"]]
    if len(z) == 0:
        return None
    ecg_f = pasabanda(d["ecg"], fs, *C.ECG_BANDA, C.ORDEN_FILTRO)
    ecg_o, _, _ = E.orientar(ecg_f, fs)
    mio = E.detectar_r(ecg_o, fs, z.attrs.get("metodo_r", "pendiente"))
    nk_f = picos_nk(ecg_o, fs, limpiar=False)
    nk_c = picos_nk(d["ecg"], fs, limpiar=True)
    tf = z["t_fin"].values
    ref_hr = ref_en(z, num, fs_n, "HR")
    fila = dict(registro=nombre, validas=len(z), latidos=len(mio), latidos_NK=len(nk_f),
                coincide_NK=concordancia(mio, nk_f, fs))
    res = {}
    for nom, idx in (("mio", mio), ("NK_filtrado", nk_f), ("NK_crudo", nk_c)):
        res["FC_" + nom] = np.abs(fc_ventanas(t[idx], tf) - ref_hr)
    ref_fr = ref_en(z, num, fs_n, "RESP")
    res["FR_mio"] = np.abs(z["FR_cruda"].values - ref_fr)
    try:
        res["FR_NK_edr"] = np.abs(fr_nk_ventanas(nk_f, len(t), fs, tf) - ref_fr)
    except Exception as e:
        print(f"  {nombre}: FR de NeuroKit fallo ({e})")
    for k, v in res.items():
        fila["err_" + k] = np.nanmean(v) if np.any(~np.isnan(v)) else np.nan
    return fila, res


def main():
    regs = REGISTROS if "--todos" in sys.argv else REGISTROS[:10]
    filas, todo = [], {}
    for reg in regs:
        z, num, fs_n = z_de_registro(reg)
        out = comparar(leer_bidmc(reg), z, num, fs_n, reg)
        if out is None:
            continue
        filas.append(out[0])
        for k, v in out[1].items():
            todo.setdefault(k, []).extend(v[~np.isnan(v)])
    pd.set_option("display.width", 220)
    print(pd.DataFrame(filas).set_index("registro").round(2).to_string())
    print("\nError absoluto sobre todas las ventanas validas (mismas ventanas para todos):")
    print(f"{'metodo':<14}{'n':>7}{'media':>8}{'mediana':>9}{'p95':>8}{'max':>8}")
    for k, v in todo.items():
        v = np.array(v)
        print(f"{k:<14}{len(v):>7}{v.mean():>8.2f}{np.median(v):>9.2f}{np.percentile(v, 95):>8.2f}{v.max():>8.2f}")
    print("FC en lpm, FR en rpm. 'mio' = tu detector / tu FR_cruda (sin suavizar, para que sea comparable).")


if __name__ == "__main__":
    main()
