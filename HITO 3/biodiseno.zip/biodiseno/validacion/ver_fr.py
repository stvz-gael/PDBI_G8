"""Como se equivoca la FR en un registro: ventana por ventana y por fuente.
  python -m validacion.ver_fr bidmc13
Si estimado/real sale ~2 (o ~0,5) el detector se engancha a un armonico: tiene arreglo.
Si sale disperso, el error es aleatorio."""
import sys
import numpy as np
import pandas as pd
from ._comun import z_de_registro, ref_en

reg = sys.argv[1] if len(sys.argv) > 1 else "bidmc13"
z, num, fs_n = z_de_registro(reg)
z = z[z["valido"]].copy()
z["RESP_ref"] = ref_en(z, num, fs_n, "RESP")
for f in ("FR_edr", "FR_ppgb", "FR"):
    z["cociente_" + f.split("_")[-1]] = z[f] / z["RESP_ref"]
cols = ["t_fin", "RESP_ref", "FR_edr", "FR_ppgb", "FR", "FR_n", "cociente_edr", "cociente_ppgb", "cociente_FR"]
pd.set_option("display.width", 200)
print(z[cols].round(2).to_string(index=False))
print("\nMediana de estimado/real:  EDR {:.2f} | PPGb {:.2f} | FR final {:.2f}".format(
    z["cociente_edr"].median(), z["cociente_ppgb"].median(), z["cociente_FR"].median()))
print("(~1 = bien, ~2 = armonico, ~0,5 = subarmonico)")
print(f"Referencia RESP: media {z['RESP_ref'].mean():.1f} rpm, rango {z['RESP_ref'].min():.1f} a {z['RESP_ref'].max():.1f}")
