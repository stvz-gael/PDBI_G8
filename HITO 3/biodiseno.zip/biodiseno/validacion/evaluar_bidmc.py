"""Evalua el pipeline contra BIDMC (PhysioNet). Requiere internet y wfdb.
  python -m validacion.evaluar_bidmc            NUMEROS FINALES: error de FC y FR (solo ventanas validas)
  python -m validacion.evaluar_bidmc --todos    con los 53 registros (sin esto, solo 10)
  python -m validacion.evaluar_bidmc --fuentes  error de FR por registro y por fuente
  python -m validacion.evaluar_bidmc --bandas   compara bandas de filtro del ECG
"""
import sys
import numpy as np
import pandas as pd
from ._comun import z_de_registro, ref_en
from procesamiento import config as C
from validacion.datasets import leer_bidmc, leer_bidmc_numericos
from procesamiento.pipeline import procesar

REGISTROS = [f"bidmc{i:02d}" for i in range(1, 54)]   # BIDMC tiene 53 registros
PRUEBA_RAPIDA = REGISTROS[:10]


def cargar(reg):
    d = leer_bidmc(reg)
    num, fs_n = leer_bidmc_numericos(reg)
    return d, num, fs_n


def finales(registros):
    """Error de FC y FR contra la referencia, solo en ventanas validas.
    Usa la cache (se recalcula sola si cambia el codigo)."""
    e_fc, e_fr, filas = [], [], []
    e_fr_acuerdo, n_acuerdo = [], 0          # FR solo cuando las fuentes coinciden
    for reg in registros:
        z, num, fs_n = z_de_registro(reg)
        z = z[z["valido"]]
        if len(z) == 0:
            filas.append({"registro": reg, "validas": 0})
            continue
        fila = {"registro": reg, "validas": len(z)}
        if "HR" in num:
            e = np.abs(z["FC"].values - ref_en(z, num, fs_n, "HR"))
            e = e[~np.isnan(e)]
            e_fc += list(e)
            fila["err_FC"] = np.mean(e) if len(e) else np.nan
        if "RESP" in num:
            e_all = np.abs(z["FR"].values - ref_en(z, num, fs_n, "RESP"))
            ok = ~np.isnan(e_all)
            e = e_all[ok]
            e_fr += list(e)
            fila["err_FR"] = np.mean(e) if len(e) else np.nan
            # ventanas donde las fuentes coinciden (FR_n = numero de fuentes que coinciden)
            m2 = ok & (z["FR_n"].values >= len(C.FR_FUENTES))
            e_fr_acuerdo += list(e_all[m2])
            fila["FR_acuerdo_%"] = 100 * np.mean(m2[ok]) if ok.any() else np.nan
        filas.append(fila)
    pd.set_option("display.width", 200)
    df = pd.DataFrame(filas).set_index("registro")
    print(df.round(2).to_string())
    e_fc, e_fr = np.array(e_fc), np.array(e_fr)
    n_val = int(df["validas"].sum())
    print(f"\nRegistros: {len(registros)} | ventanas validas: {n_val} | usadas: FC {len(e_fc)}, FR {len(e_fr)}")
    print(f"(FR: {n_val - len(e_fr)} ventanas sin referencia confiable, p. ej. ceros de BIDMC, no se evaluan)")
    print("\nFRECUENCIA CARDIACA (lpm), error absoluto sobre todas las ventanas validas:")
    print(f"  media {e_fc.mean():.2f} | mediana {np.median(e_fc):.2f} | percentil 95 {np.percentile(e_fc, 95):.2f} | maximo {e_fc.max():.2f}")
    print(f"  ventanas con error <= 2 lpm: {100*np.mean(e_fc <= 2):.1f} %   <= 5 lpm: {100*np.mean(e_fc <= 5):.1f} %")
    print("\nFRECUENCIA RESPIRATORIA (rpm), error absoluto sobre todas las ventanas validas:")
    print(f"  media {e_fr.mean():.2f} | mediana {np.median(e_fr):.2f} | percentil 95 {np.percentile(e_fr, 95):.2f} | maximo {e_fr.max():.2f}")
    print(f"  ventanas con error <= 2 rpm: {100*np.mean(e_fr <= 2):.1f} %   <= 3 rpm: {100*np.mean(e_fr <= 3):.1f} %")
    ea = np.array(e_fr_acuerdo)
    if len(ea):
        print(f"\nFR SOLO cuando las {len(C.FR_FUENTES)} fuentes coinciden (menos cobertura, mas confiable):")
        print(f"  cobertura {100*len(ea)/len(e_fr):.1f} % de las ventanas validas")
        print(f"  media {ea.mean():.2f} | mediana {np.median(ea):.2f} | percentil 95 {np.percentile(ea, 95):.2f} | maximo {ea.max():.2f}")
        print(f"  ventanas con error <= 2 rpm: {100*np.mean(ea <= 2):.1f} %   <= 3 rpm: {100*np.mean(ea <= 3):.1f} %")


def diagnostico(registros):
    fuentes = ["FR_edr", "FR_rsa", "FR_ppga", "FR_ppgb", "FR_cruda", "FR"]
    filas = []
    for reg in registros:
        d, num, fs_n = cargar(reg)
        z = procesar(d["t"], d["ecg"], d["ir"], None, d["fs"])
        z = z[z["valido"]].copy()
        if len(z) == 0 or "RESP" not in num:
            continue
        ref = ref_en(z, num, fs_n, "RESP")
        fila = {"registro": reg, "ventanas": len(z), "RESP_ref": np.nanmean(ref)}
        for f in fuentes:
            fila[f] = np.nanmean(np.abs(z[f].values - ref))
        filas.append(fila)
    df = pd.DataFrame(filas).set_index("registro")
    pd.set_option("display.width", 200)
    print("\nError absoluto medio de FR (rpm) por registro y fuente:")
    print(df.round(2).to_string())
    print("\nPromedio de registros:")
    print(df[fuentes].mean().round(2).to_string())
    print("\nMediana de registros:")
    print(df[fuentes].median().round(2).to_string())


def bandas(registros):
    opciones = {"sin filtro": None, "0,5 a 40 Hz": (0.5, 40.0),
                "0,5 a 25 Hz": (0.5, 25.0), "1 a 40 Hz": (1.0, 40.0)}
    for nombre, banda in opciones.items():
        e_fc, e_fr = [], []
        for reg in registros:
            d, num, fs_n = cargar(reg)
            z = procesar(d["t"], d["ecg"], d["ir"], None, d["fs"], ecg_banda=banda)
            z = z[z["valido"]]
            if len(z) == 0:
                continue
            e_fc += list(np.abs(z["FC"].values - ref_en(z, num, fs_n, "HR")))
            if "RESP" in num:
                e_fr += list(np.abs(z["FR"].values - ref_en(z, num, fs_n, "RESP")))
        print(f"{nombre:12s} error FC = {np.nanmean(e_fc):5.2f} lpm   FR = {np.nanmean(e_fr):5.2f} rpm")


if __name__ == "__main__":
    todos = "--todos" in sys.argv
    regs = REGISTROS if todos else PRUEBA_RAPIDA
    print(f"Registros: {len(regs)} (usa --todos para los 53)")
    if "--bandas" in sys.argv:
        bandas(regs)
    elif "--fuentes" in sys.argv:
        diagnostico(regs)
    else:
        finales(regs)