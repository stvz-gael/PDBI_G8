"""Validacion con MIMIC-III waveform (abierta). Compara el PAT con la presion arterial (ABP).
  python -m validacion.evaluar_mimic --buscar 15    busca 15 pacientes y guarda la lista en datos/mimic_lista.txt
  python -m validacion.evaluar_mimic                evalua la lista guardada
  python -m validacion.evaluar_mimic --ancho        igual, pero buscando el pulso hasta 1.2 s despues de la R
                                                 (en MIMIC el pulso llega tarde: ver diagnostico_pat_mimic). El PAT absoluto
                                                 pierde sentido (hay desfase del monitor); solo se mira si SIGUE a la presion.
Solo imprime y guarda numeros agregados (datos/mimic_resumen.csv), no senales.
Ojo: el ECG de MIMIC-III esta reducido a 125 Hz con jitter de 2 a 14 ms: el PAT sale mas ruidoso que en el dispositivo."""
import os
import sys
import numpy as np
import pandas as pd
from scipy.signal import find_peaks
from scipy.stats import spearmanr
from procesamiento import config as C
from validacion.datasets import mimic_buscar, leer_mimic
from procesamiento.pipeline import procesar

LISTA = os.path.join("datos", "mimic_lista.txt")
RESUMEN = os.path.join("datos", "mimic_resumen.csv")


def abp_por_ventana(t, abp, fs, z):
    """Por cada ventana de z: PAS (mediana de picos), PAM (media), FC de la presion. NaN si el ABP no es creible."""
    pk, _ = find_peaks(abp, distance=int(0.3 * fs), prominence=10)
    t_pk, v_pk = t[pk], abp[pk]
    pas, pam, fc = [], [], []
    for t_fin in z["t_fin"].values:
        m = (t_pk >= t_fin - C.VENTANA_S) & (t_pk < t_fin)
        mm = (t >= t_fin - C.VENTANA_S) & (t < t_fin)
        if m.sum() < 20 or not (40 <= np.median(v_pk[m]) <= 250) or np.ptp(abp[mm]) < 20:
            pas.append(np.nan); pam.append(np.nan); fc.append(np.nan)
            continue
        pas.append(np.median(v_pk[m])); pam.append(np.mean(abp[mm]))
        fc.append(60.0 / np.median(np.diff(t_pk[m])))
    return np.array(pas), np.array(pam), np.array(fc)


def evaluar(d, nombre="seg"):
    z = procesar(d["t"], d["ecg"], d["ir"], d.get("red"), fs=d["fs"])
    pas, pam, fc_ref = abp_por_ventana(d["t"], d["abp"], d["fs"], z)
    fila = dict(registro=nombre, ventanas=len(z), validas=int(z["valido"].sum()),
                validas_pat=int(z["valido_pat"].sum()),
                ecg_inv=z.attrs.get("ecg_invertido"), metodo_r=z.attrs.get("metodo_r"))
    ok = z["valido"].values & ~np.isnan(fc_ref)
    fila["err_FC"] = float(np.nanmean(np.abs(z["FC"].values[ok] - fc_ref[ok]))) if ok.any() else np.nan
    k = z["valido_pat"].values & ~np.isnan(pas)
    fila["n_corr"] = int(k.sum())
    fila["rango_PAS"] = float(np.ptp(pas[k])) if k.any() else np.nan
    for nom, ref in (("PAS", pas), ("PAM", pam)):
        # correlacion de rangos: no supone relacion lineal; se exigen >= 20 ventanas y PAS que varie
        if k.sum() >= 20 and np.ptp(ref[k]) >= 10:
            fila[f"rho_PAT_{nom}"] = float(spearmanr(z["PAT"].values[k], ref[k])[0])
            kd = k & ~np.isnan(z["dPAT"].values)
            fila[f"rho_dPAT_{nom}"] = float(spearmanr(z["dPAT"].values[kd], ref[kd])[0]) if kd.sum() >= 20 else np.nan
        else:
            fila[f"rho_PAT_{nom}"] = fila[f"rho_dPAT_{nom}"] = np.nan
    return fila


def main():
    if "--buscar" in sys.argv:
        n = int(sys.argv[sys.argv.index("--buscar") + 1])
        print(f"Buscando {n} pacientes con ECG II + PLETH + ABP (puede tardar unos minutos)...")
        sel = mimic_buscar(n)
        os.makedirs("datos", exist_ok=True)
        with open(LISTA, "w") as f:
            for pn, s, ln in sel:
                f.write(f"{pn}\t{s}\t{ln:.0f}\n")
        print(f"{len(sel)} segmentos guardados en {LISTA}")
        return
    if not os.path.exists(LISTA):
        print("Primero: python -m validacion.evaluar_mimic --buscar 15")
        return
    resumen = RESUMEN
    if "--ancho" in sys.argv:
        C.PAT_BUSQUEDA_S = (0.08, 1.2)
        C.PAT_VALIDO_S = (0.08, 1.2)
        resumen = RESUMEN.replace(".csv", "_ancho.csv")
        print("Modo --ancho: busqueda y rango valido del PAT = 0.08 a 1.2 s (solo para esta prueba)")
    filas = []
    for linea in open(LISTA):
        pn, s, _ = linea.strip().split("\t")
        try:
            filas.append(evaluar(leer_mimic(pn, s), s))
        except Exception as e:
            print(f"  {s}: omitido ({e})")
    r = pd.DataFrame(filas)
    r.to_csv(resumen, index=False)
    pd.set_option("display.width", 200)
    print(r.round(2).to_string(index=False))
    for c in ("rho_PAT_PAS", "rho_dPAT_PAS", "rho_PAT_PAM"):
        v = r[c].dropna()
        if len(v):
            print(f"{c}: n={len(v)}  mediana={v.median():.2f}  con rho<-0.3: {(v < -0.3).mean():.0%}")
    print(f"error FC vs ABP (media de pacientes): {r['err_FC'].mean():.2f} lpm")


if __name__ == "__main__":
    main()