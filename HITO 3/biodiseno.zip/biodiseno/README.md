# Procesamiento de señales (BIODISEÑO)

x[n] (ECG, RED, IR, tiempo) -> filtros -> R, FC, HRV, FR, PAT, SpO2 -> z[n]

Contrato de datos entre módulos: `CONTRATO.md`.

## Carpetas
| Carpeta | Para qué sirve | ¿Va al servidor? |
|---|---|---|
| `procesamiento/` | El núcleo: un archivo por bloque de la Fig. 2A | Sí |
| `servidor/` | Punto de entrada x[n] (.bin) -> z[n] (CSV o JSON) | Sí |
| `firmware/` | Código de la ESP32 (Arduino): ECG + PPG -> paquetes -> SD, USB y Wi-Fi | No (va a la placa) |
| `herramientas/` | Visor en vivo de la señal, FFT y filtros (`ver_senal.py`) | No |
| `pruebas/` | Pruebas rápidas con señales simuladas (sin internet) | No |
| `validacion/` | Evaluación con BIDMC y MIMIC-III (necesita internet y `wfdb`) | No |
| `datos/` | Cachés y resultados de la validación (se genera sola, no se sube) | No |

## Uso
```
pip install -r requirements.txt          # solo lo del servidor
pip install -r requirements-dev.txt      # además, para validar con BIDMC y MIMIC
```
Corre todo desde esta carpeta.

```
python -m pruebas.test_sintetico     # señales simuladas con verdad conocida
python -m pruebas.test_bin           # prueba del archivo .bin de la microSD
python -m pruebas.test_fusion        # la fusión ignora una fuente errónea
python -m pruebas.test_onda_t        # el detector no cuenta ondas T
python -m pruebas.test_paquetes      # formato de paquetes: C++ del firmware <-> Python

python -m herramientas.ver_senal --puerto COM5   # señal, FFT y FC/FR/SpO2 en vivo (ver firmware/README.md)

python -m servidor.procesar entrada.bin salida.csv     # un .bin de la ESP32 -> z[n]

python -m validacion.evaluar_bidmc --todos        # FC y FR contra el monitor (53 registros)
python -m validacion.evaluar_fr_anotada           # FR contra respiraciones marcadas a mano
python -m validacion.ablacion_fr                  # qué fuentes de FR conviene fusionar
python -m validacion.comparar_neurokit --todos    # detector propio vs NeuroKit2
python -m validacion.alarmas_fr                   # prueba de falsas alarmas
python -m validacion.evaluar_mimic --buscar 15    # PAT contra presión arterial en MIMIC-III
python -m validacion.evaluar_mimic --ancho
python -m validacion.diagnostico_pat_mimic
```

## Pendiente antes de usar con tu hardware
1. `PPG_INVERTIDO` en `config.py`: en el MAX30101 la señal suele BAJAR con cada pulso. Graba 10 s y míralo.
2. Ajustar A y B de SpO2 con un oxímetro comercial (valores actuales típicos, sin calibrar).
3. Revisar `PAT_BUSQUEDA_S` con tus datos reales (dedo vs otros sitios).
4. Confirmar con quien hizo el firmware que el `.bin` es de 14 bytes por muestra (ver `CONTRATO.md`).


## Enviar a la app (Firebase)
Ver `herramientas/LEEME_firebase.md`. Prueba rapida: `python -m herramientas.puente_firebase --simular --seco`.
Para probar con un ECG guardado: carpeta `prueba_ecg/`.
