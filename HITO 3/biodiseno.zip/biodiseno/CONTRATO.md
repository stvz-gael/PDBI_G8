# Contrato de datos (lo que se prometen los módulos entre sí)

Si cambias algo aquí, cambia el firmware, el procesamiento y el modelo de IA a la vez.

## x[n]: lo que produce la ESP32 (una fila por muestra)

| Campo | Tipo (firmware) | Unidad | Origen |
|---|---|---|---|
| `t_us` | uint32 | microsegundos desde el inicio | timer de hardware de la ESP32 |
| `ecg` | uint16 | cuentas del ADC (0 a 4095, 12 bits) | AD8232 + filtro RC, ADC interno |
| `red` | uint32 | cuentas del sensor (18 bits) | MAX30101, I2C |
| `ir` | uint32 | cuentas del sensor (18 bits) | MAX30101, I2C |

- Frecuencia de muestreo: **200 Hz** (ECG y PPG). El QRS llega hasta ~40 Hz y 200 Hz da
  margen sobre Nyquist (80 Hz) para ubicar la R con precisión de 5 ms, que importa para el PAT.
- Archivo: binario, empaquetado, little-endian, **14 bytes por muestra** (`<u4 <u2 <u4 <u4`).
  Debe coincidir con `DTYPE_X` en `procesamiento/cargador.py`.
- `t_us` da la vuelta a los ~71 min (32 bits). El cargador lo corrige.
- No hay campo `cal`: sin estimar presión no hay calibración de 4 h.

## Paquetes: cómo viaja x[n] (USB y Wi-Fi)

Un paquete = **cabecera de 32 bytes + n muestras de 14 bytes** (n = 200, o sea 1 s). Todo little-endian.
Definido en `firmware/biodiseno_esp32/protocolo.h` y leído por `leer_paquetes` en `procesamiento/cargador.py`.

| Campo | Tipo | Qué es |
|---|---|---|
| `magic` | 4 bytes | `BIO1` |
| `version` | uint8 | 1 |
| `flags` | uint8 | bit 0: electrodo suelto en algún momento del paquete. Bit 1: hueco de tiempo en el PPG |
| `n` | uint16 | número de muestras |
| `paciente` | uint32 | identificador del paciente |
| `sesion` | uint32 | aleatorio en cada arranque de la ESP32 |
| `seq` | uint32 | 0, 1, 2... dentro de la sesión (permite detectar paquetes perdidos o repetidos) |
| `t0_us` | uint32 | `t_us` de la primera muestra |
| `epoch_s` | uint32 | hora UTC de la primera muestra (0 si la ESP32 aún no tiene hora de internet) |
| `crc` | uint16 | CRC-16/CCITT-FALSE de las n muestras |
| `reservado` | uint16 | 0 |

- Wi-Fi: un POST por paquete, cuerpo = paquete completo, encabezados `X-API-Key`, `X-Paciente`, `X-Sesion`, `X-Seq`.
  Los paquetes que fallen no se reenvían: el servidor detecta los huecos por `seq`.
- microSD: solo las muestras (sin cabecera), el `.bin` de 14 bytes por muestra descrito arriba.
- Un hueco en `seq` significa señal perdida: el procesamiento NO debe interpolar sobre él (hoy `unir_paquetes` solo lo reporta).

## z[n]: lo que produce el procesamiento (una fila cada 10 s, ventana de 60 s)

Columnas que se prometen (`servidor/procesar.py: COLUMNAS_Z`). Los valores no calculables van como
`NaN` en CSV y `null` en JSON.

| Campo | Unidad | Qué es |
|---|---|---|
| `t_fin` | s | final de la ventana, desde el inicio del registro |
| `FC` | lpm | 60 / RR medio (onda R con NeuroKit2) |
| `HRV_SDNN` | ms | desviación estándar de los RR |
| `FR` | resp/min | frecuencia respiratoria final: fusión de EDR (amplitud de R) y línea base del PPG, mediana de las últimas 5 ventanas válidas |
| `FR_n` | # | cuántas fuentes coinciden en la ventana (1 o 2) |
| `PAT` | s | mediana del PAT de la ventana (pie de onda). Solo si `valido_pat` |
| `dPAT` | fracción | (PAT - PAT_base) / PAT_base, base = mediana de las ventanas previas (hasta 4 h). Vacío hasta tener 6 ventanas previas |
| `SpO2` | % | A - B·R, con A y B **sin calibrar** hasta ajustarlos con un oxímetro |
| `PI` | % | índice de perfusión: AC/DC del IR por 100 |
| `Q_ECG` | 0 a 1 | fracción de RR fisiológicos |
| `Q_PPG` | 0 a 1 | fracción de pulsos regulares del PPG |
| `Q_PAT` | 0 a 1 | fracción de latidos con PAT medido |
| `valido` | bool | Q_ECG ≥ 0,8, Q_PPG ≥ 0,6 y la FC del ECG coincide con el pulso del PPG (10 %). Si es False, el modelo no usa FC, HRV, FR, SpO2 ni PI de esa fila |
| `valido_pat` | bool | `valido` y Q_PAT ≥ 0,6. Si es False, el modelo no usa PAT ni dPAT |

Con `--completo` el servidor agrega columnas de diagnóstico (`FR_cruda`, `FR_edr`, `FR_rsa`,
`FR_ppga`, `FR_ppgb`, `FC_ppg`, `acuerdo`, etc.). El modelo no debe depender de ellas.

## Pendientes del contrato (acordar con quien hace la ESP32 y el modelo)
- **Servidor de Firebase:** confirmar con quien lo hizo que acepta este paquete (cuerpo binario y encabezados de arriba).
- **dPAT con bloques**: la base de 4 h necesita el historial del paciente. Si cada bloque se procesa
  por separado, la base se reinicia en cada uno. Hay que guardar los PAT previos o reprocesar.
- **Identificador del paciente y de la sesión** en cada archivo o mensaje (no está en x[n]).
