"""Une todo: x[n] (senales) -> z[n] (una fila por ventana).
Columnas de z: t_fin, FC, HRV_SDNN, FR (final), FR_cruda y FR por fuente, PAT, dPAT, SpO2, PI,
Q_ECG, Q_PPG (pulsos regulares), Q_PAT (PAT medido), valido (FC/FR/SpO2 usables), valido_pat (PAT usable)
"""
import numpy as np
import pandas as pd
from scipy.signal import find_peaks
from . import config as C
from .filtros import pasabanda, muesca
from . import ecg as E
from . import ppg as P
from . import respiracion as RESP


def procesar(t, ecg, ir, red=None, fs=C.FS_DISPOSITIVO,
             ecg_banda="defecto", ppg_banda="defecto"):
    """t en segundos (uniforme a fs). ecg, ir, red: arreglos del mismo largo."""
    # "defecto" = usar config.py; None = SIN filtro (no confundir los dos)
    if isinstance(ecg_banda, str):
        ecg_banda = C.ECG_BANDA
    if isinstance(ppg_banda, str):
        ppg_banda = C.PPG_BANDA
    ecg_f = pasabanda(ecg, fs, *ecg_banda, C.ORDEN_FILTRO) if ecg_banda else np.asarray(ecg, float)
    if ecg_banda:
        for f0 in C.ECG_MUESCAS:
            if f0 < fs / 2:
                ecg_f = muesca(ecg_f, fs, f0)
    ir_u = pasabanda(ir, fs, *ppg_banda, C.ORDEN_FILTRO) if ppg_banda else np.asarray(ir, float)
    # Polaridad del PPG: automatica (None) o forzada (True/False) desde config.py
    ppg_inv = P.invertido(ir_u, fs) if C.PPG_INVERTIDO is None else bool(C.PPG_INVERTIDO)
    sg = -1.0 if ppg_inv else 1.0
    ir_f = sg * ir_u
    red_f = None
    if red is not None:
        red_f = sg * (pasabanda(red, fs, *ppg_banda, C.ORDEN_FILTRO) if ppg_banda else np.asarray(red, float))

    # Detecciones sobre toda la senal (una vez); luego se reparten por ventana
    ecg_f, idx_r, ecg_invertido = E.orientar(ecg_f, fs)   # corrige polaridad si hace falta

    # Pulsos del PPG (para comprobar que la FC del ECG coincide con el pulso)
    t_p = P.pulsos(t, ir_f, fs)

    # Metodo de deteccion de R: en "auto" se prueban ambos y gana el que cuenta
    # casi los mismos latidos que pulsos tiene el PPG (cada latido = un pulso).
    metodo_r = C.R_METODO
    if metodo_r == "auto":
        if len(t_p) >= 4:
            err = {}
            for m_ in ("pendiente", "altura"):
                n_r = len(E.detectar_r(ecg_f, fs, m_))
                err[m_] = abs(n_r - len(t_p)) / len(t_p)
            metodo_r = "altura" if err["altura"] + C.R_AUTO_PREFIERE_PENDIENTE < err["pendiente"] else "pendiente"
        else:
            metodo_r = "pendiente"
    idx_r = E.detectar_r(ecg_f, fs, metodo_r)
    t_r, amp_r = t[idx_r], ecg_f[idx_r]
    pat = P.pat_por_latido(t, ir_f, t_r, fs)

    # Series latido a latido para la respiracion (NaN si el latido no sirve)
    rr = np.full(len(t_r), np.nan)
    a_ppg = np.full(len(t_r), np.nan)
    b_ppg = np.full(len(t_r), np.nan)
    ir_arr = np.asarray(ir, float)
    for k in range(len(t_r) - 1):
        dt = t_r[k + 1] - t_r[k]
        if not (C.RR_MIN_S <= dt <= C.RR_MAX_S):
            continue
        rr[k] = dt
        i0, i1 = idx_r[k], idx_r[k + 1]
        seg = ir_f[i0:i1]
        if len(seg) > 4:
            a_ppg[k] = np.ptp(seg)
            b_ppg[k] = np.mean(ir_arr[i0:i1])

    filas = []
    t_fin = t[0] + C.VENTANA_S
    while t_fin <= t[-1]:
        t_ini = t_fin - C.VENTANA_S
        m = (t >= t_ini) & (t < t_fin)
        mr = (t_r >= t_ini) & (t_r < t_fin)
        tr_w, ar_w, pat_w = t_r[mr], amp_r[mr], pat[mr]
        fc, hrv = E.fc_hrv(tr_w)
        cands = {"edr": RESP.espectro_pico(tr_w, ar_w),
                 "rsa": RESP.espectro_pico(tr_w, rr[mr]),
                 "ppga": RESP.espectro_pico(tr_w, a_ppg[mr]),
                 "ppgb": RESP.espectro_pico(tr_w, b_ppg[mr])}
        fr, n_acuerdo = RESP.fusionar({k: v for k, v in cands.items() if k in C.FR_FUENTES})
        spo2, pi = P.spo2_y_pi(np.asarray(ir)[m], ir_f[m],
                               None if red is None else np.asarray(red)[m],
                               None if red_f is None else red_f[m])
        # Calidad del ECG: fraccion de RR fisiologicos
        if len(tr_w) >= 3:
            _, ok = E.rr_validos(tr_w)
            q_ecg = float(np.mean(ok))
            q_pat = float(np.mean(~np.isnan(pat_w)))     # PAT medido en que fraccion de latidos
        else:
            q_ecg = q_pat = 0.0
        # Calidad del PPG: pulsos regulares (intervalos fisiologicos). NO depende del PAT.
        tp_w = t_p[(t_p >= t_ini) & (t_p < t_fin)]
        if len(tp_w) >= 3:
            ipp = np.diff(tp_w)
            q_ppg = float(np.mean((ipp >= C.RR_MIN_S) & (ipp <= C.RR_MAX_S)))
        else:
            q_ppg = 0.0
        if len(tp_w) >= 4:
            fc_ppg = 60.0 / np.median(np.diff(tp_w))   # mediana: un pulso mal contado no arruina la ventana
        else:
            fc_ppg = np.nan
        acuerdo = bool(not np.isnan(fc) and not np.isnan(fc_ppg)
                       and abs(fc - fc_ppg) <= C.FC_ACUERDO_FRAC * fc_ppg)
        # valido: FC, HRV, FR, SpO2 y PI se pueden usar. valido_pat: ademas el PAT es confiable.
        valido = (q_ecg >= C.Q_ECG_MIN) and (q_ppg >= C.Q_PPG_MIN) and acuerdo
        valido_pat = valido and (q_pat >= C.Q_PAT_MIN)
        filas.append(dict(t_fin=t_fin, FC=fc, HRV_SDNN=hrv, FC_ppg=fc_ppg, acuerdo=acuerdo, FR_cruda=fr, FR_n=n_acuerdo,
                          FR_edr=cands["edr"][0], FR_rsa=cands["rsa"][0],
                          FR_ppga=cands["ppga"][0], FR_ppgb=cands["ppgb"][0],
                          FR_edr_p=cands["edr"][1], FR_rsa_p=cands["rsa"][1],
                          FR_ppga_p=cands["ppga"][1], FR_ppgb_p=cands["ppgb"][1],
                          PAT=np.nanmedian(pat_w) if np.any(~np.isnan(pat_w)) else np.nan,
                          SpO2=spo2, PI=pi, Q_ECG=q_ecg, Q_PPG=q_ppg, Q_PAT=q_pat,
                          valido=valido, valido_pat=valido_pat))
        t_fin += C.PASO_S

    z = pd.DataFrame(filas)
    z.attrs["ecg_invertido"] = ecg_invertido
    z.attrs["ppg_invertido"] = ppg_inv
    z.attrs["metodo_r"] = metodo_r
    if len(z):
        # FR final: mediana de las ultimas N ventanas validas (la FR cambia lento,
        # asi un valor erroneo aislado no pasa)
        fr_ok = z["FR_cruda"].where(z["valido"])
        z["FR"] = fr_ok.rolling(C.FR_SUAVE_N, min_periods=1).median().where(z["valido"])
        # dPAT: cambio relativo frente a la linea base propia del paciente
        # (mediana de las ventanas previas, ultimas 4 h). Sin saltos de calibracion.
        z["PAT"] = z["PAT"].where(z["valido_pat"])          # PAT solo si es confiable
        base = z["PAT"].shift(1).rolling(C.PAT_BASE_VENTANAS, min_periods=6).median()
        z["dPAT"] = ((z["PAT"] - base) / base).where(z["valido_pat"])
    return z