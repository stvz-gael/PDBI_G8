"""PPG: PAT, indice de perfusion y SpO2."""
import numpy as np
from scipy.signal import find_peaks
from . import config as C


def invertido(ppg_f, fs):
    """True si el PPG viene invertido. Un pulso correcto SUBE rapido y BAJA lento,
    asi que la pendiente maxima hacia arriba (percentil 99 de la derivada) es mayor
    que la maxima hacia abajo (percentil 1). Si es al reves, esta invertido."""
    d = np.gradient(ppg_f, 1.0 / fs)
    return bool(-np.percentile(d, 1) > C.ORIENTACION_RATIO * np.percentile(d, 99))


def pulsos(t, ppg_f, fs):
    """Instantes de cada pulso, contados por la SUBIDA mas empinada (sistole).
    Es mas robusto que contar picos de altura: la muesca dicrota crea un segundo
    pico, pero su subida es mucho mas suave que la de la sistole."""
    d = np.gradient(ppg_f, 1.0 / fs)
    umbral = 0.4 * np.percentile(d, 99)
    idx, _ = find_peaks(d, height=umbral, distance=int(C.RR_MIN_S * fs))
    return t[idx]


def pat_por_latido(t, ppg_f, t_r, fs):
    """PAT de cada latido = t_pulso - t_R.
    Punto del pulso:
      "pie": cruce de la tangente en la maxima pendiente con la linea base
             (menos afectado por la reflexion de la onda).
      "medio": instante de maxima pendiente (mas robusto al ruido).
    Devuelve (t_R usados, PAT en s), con NaN donde no se pudo medir.
    """
    d = np.gradient(ppg_f, 1.0 / fs)
    pend_min = C.PAT_PEND_MIN_FRAC * np.percentile(d, 99)   # pendiente tipica de la sistole
    out = np.full(len(t_r), np.nan)
    for k, tr in enumerate(t_r):
        i0 = int(np.searchsorted(t, tr + C.PAT_BUSQUEDA_S[0]))
        i1 = int(np.searchsorted(t, tr + C.PAT_BUSQUEDA_S[1]))
        if i1 - i0 < 5 or i1 >= len(t):
            continue
        im = i0 + int(np.argmax(d[i0:i1]))          # maxima pendiente
        pend = d[im]
        # debe ser una subida real y no estar pegada al borde de la ventana
        if pend < pend_min or im >= i1 - 3:
            continue
        if C.PAT_PUNTO == "medio":
            t_p = t[im]
        else:
            ib = max(int(np.searchsorted(t, tr)), im - int(0.3 * fs))
            base = np.min(ppg_f[ib:im + 1])          # linea base local
            t_p = t[im] - (ppg_f[im] - base) / pend  # tangente corta la base
        pat = t_p - tr
        if C.PAT_VALIDO_S[0] <= pat <= C.PAT_VALIDO_S[1]:
            out[k] = pat
    return out


def ac_dc(crudo, filtrado):
    """DC = media de la senal cruda. AC = amplitud pico a pico del pulso filtrado
    (percentil 95 menos percentil 5, mas estable que max menos min)."""
    dc = np.mean(crudo)
    ac = np.percentile(filtrado, 95) - np.percentile(filtrado, 5)
    return ac, dc


def spo2_y_pi(ir_raw, ir_f, red_raw=None, red_f=None):
    """PI (%) = AC/DC del IR * 100.
    SpO2 = A - B*R, con R = (AC/DC rojo) / (AC/DC IR). Sin red: NaN."""
    ac_i, dc_i = ac_dc(ir_raw, ir_f)
    pi = 100.0 * ac_i / dc_i if dc_i else np.nan
    if red_raw is None:
        return np.nan, pi
    ac_r, dc_r = ac_dc(red_raw, red_f)
    if not (dc_i and dc_r and ac_i):
        return np.nan, pi
    R = (ac_r / dc_r) / (ac_i / dc_i)
    return float(np.clip(C.SPO2_A - C.SPO2_B * R, 0, 100)), pi