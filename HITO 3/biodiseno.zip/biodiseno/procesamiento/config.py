"""Parametros del procesamiento. Todo lo que se pueda ajustar vive aqui,
asi cada decision queda escrita y la puedes justificar en tu informe."""

FS_DISPOSITIVO = 200.0      # Hz, frecuencia de muestreo de tu ESP32 (ECG y PPG)

# Bandas de los filtros (Hz). Se eligen por fisiologia y se validan con datos.
ECG_BANDA = (0.5, 40.0)     # conserva QRS (10 a 40 Hz) y quita deriva (<0,5 Hz)
PPG_BANDA = (0.3, 10.0)     # conserva el pulso (1 a 3 Hz) y sus armonicos
ORDEN_FILTRO = 4
# Muescas (notch) opcionales para el ECG. Vacio = ninguna (como se valido con BIDMC).
# Con la ESP32 a 200 Hz la red de 60 Hz y sus armonicos 120, 180 y 240 Hz aparecen "doblados" en 60, 80, 20 y 40 Hz.
ECG_MUESCAS = ()
MUESCAS_RED_200HZ = (60.0, 80.0, 20.0, 40.0)
# PPG del MAX30101: si el IR reflejado (cuentas crudas) es menor que esto, no hay dedo sobre el sensor
PPG_UMBRAL_DEDO = 50000

# Detector de R (bloque "Detector de R" de la Fig. 2A)
R_REFRACTARIO_S = 0.25      # no puede haber dos latidos mas juntos que esto
R_METODO = "neurokit"   # "neurokit" (por defecto), "pendiente", "altura" o "auto" (propios: elige el que coincide con el PPG)
                            # o fuerza "pendiente" (Pan-Tompkins, rechaza ondas T) / "altura"
R_UMBRAL_FRAC = 0.5         # umbral = 0,5 * media de las ultimas N amplitudes R
R_N_ULTIMAS = 8
RR_MIN_S, RR_MAX_S = 0.3, 2.0   # RR fuera de este rango se descarta (200 a 30 lpm)

# Ventanas de analisis
VENTANA_S = 60.0            # ventana de calculo (FR necesita 30 a 60 s)
PASO_S = 10.0               # cada cuanto sale una fila de z[n]

# Respiracion derivada del ECG
FR_REMUESTREO_HZ = 4.0      # la senal respiratoria derivada se remuestrea a 4 Hz
FR_BANDA_HZ = (0.1, 0.5)    # 6 a 30 respiraciones por minuto

# PAT
PAT_PUNTO = "pie"           # "pie" (tangente) o "medio" (maxima pendiente)
PAT_BUSQUEDA_S = (0.08, 0.60)   # donde buscar el pulso tras la R
PAT_VALIDO_S = (0.08, 0.60)
PAT_BASE_VENTANAS = 1440    # 4 h con paso de 10 s (4*3600/10)
PPG_INVERTIDO = None        # None = automatico. True/False fuerza la polaridad del PPG
                            # (True si tu PPG crudo BAJA en cada pulso, como en reflexion)

# SpO2 = A - B*R. Valores tipicos, SIN calibrar. Se ajustan por sensor.
SPO2_A, SPO2_B = 110.0, 25.0

# Calidad
Q_ECG_MIN = 0.8
Q_PPG_MIN = 0.6

# Fusion de fuentes respiratorias
FR_TOL_RPM = 3.0            # dos fuentes "coinciden" si difieren menos de esto
FR_SUAVE_N = 5              # mediana de las ultimas N ventanas validas
FR_PROM_MIN = 0.15          # pico poco claro (< 15 % de la energia de la banda) = dudoso

# Fuentes que entran a la fusion. Elegidas con la ablacion en BIDMC (53 registros,
# decidido con los registros 1 a 26 y confirmado con 27 a 53): edr+ppgb gano en ambos.
# rsa y ppga se siguen calculando (columnas FR_rsa, FR_ppga) pero NO entran a la fusion.
FR_FUENTES = ["edr", "ppgb"]

# Acuerdo ECG vs PPG: la FC del ECG debe coincidir con la frecuencia de pulso del PPG.
# Si el detector cuenta latidos de mas (R y T) o de menos, no coinciden y la ventana se descarta.
FC_ACUERDO_FRAC = 0.10      # diferencia maxima permitida (10 %)
ORIENTACION_RATIO = 1.3     # el lado de la R debe ser 1,3 veces mayor que el otro para decidir polaridad

# Calidad del PPG (pulsos regulares) y del PAT (medido en suficientes latidos) por separado
Q_PAT_MIN = 0.6             # PAT solo se reporta si se midio en >= 60 % de los latidos
R_AUTO_PREFIERE_PENDIENTE = 0.02   # en empate (diferencia < 2 %) se prefiere el metodo por pendiente

# PAT: la subida elegida debe ser de verdad la sistole (no el eco del filtro ni ruido)
PAT_PEND_MIN_FRAC = 0.4     # pendiente minima = 40 % de la pendiente tipica de la sistole (percentil 99)