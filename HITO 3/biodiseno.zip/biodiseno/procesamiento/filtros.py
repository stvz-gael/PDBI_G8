"""Filtros. Por que asi:
- Butterworth: respuesta plana en la banda de paso, o sea NO cambia la amplitud
  de lo que te interesa.
- sosfiltfilt: filtra hacia adelante y hacia atras (fase cero), asi los picos
  no se desplazan en el tiempo. Esto es clave para el PAT.
  Solo se puede usar fuera de linea (en el servidor), no en la ESP32.
"""
import numpy as np
from scipy.signal import butter, sosfiltfilt, iirnotch, filtfilt


def pasabanda(x, fs, lo, hi, orden=4):
    sos = butter(orden, [lo, hi], btype="band", fs=fs, output="sos")
    return sosfiltfilt(sos, np.asarray(x, dtype=float))


def muesca(x, fs, f0=60.0, q=30.0):
    """Quita la red electrica (60 Hz en Peru). Solo si hace falta."""
    b, a = iirnotch(f0, q, fs=fs)
    return filtfilt(b, a, np.asarray(x, dtype=float))


def zscore(x):
    """Normaliza la ventana: la amplitud absoluta deja de importar."""
    x = np.asarray(x, dtype=float)
    s = np.std(x)
    return (x - np.mean(x)) / s if s > 0 else x - np.mean(x)
