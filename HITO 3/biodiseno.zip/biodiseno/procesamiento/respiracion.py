"""Frecuencia respiratoria (FR) por FUSION de varias fuentes.

La respiracion deja huella en varias senales a la vez:
  EDR  : altura de la onda R (el corazon se mueve respecto a los electrodos)
  RSA  : duracion de los RR (se acortan al inhalar, se alargan al exhalar)
  PPGa : amplitud de cada pulso del PPG
  PPGb : nivel medio (linea base) del PPG
Cada una da su estimacion; si dos o mas coinciden, es mucho mas probable que
sea la respiracion real y no ruido. Asi un pico falso en una fuente se descarta.
"""
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.signal import detrend, find_peaks
from . import config as C


def espectro_pico(t_b, y):
    """(FR en rpm, prominencia 0 a 1) de una serie dada latido a latido.
    Prominencia = energia del pico / energia total de la banda 0,1 a 0,5 Hz:
    cerca de 1 = pico claro, cerca de 0 = espectro plano (no hay respiracion clara)."""
    t_b, y = np.asarray(t_b, float), np.asarray(y, float)
    ok = ~np.isnan(y)
    t_b, y = t_b[ok], y[ok]
    if len(t_b) < 8 or (t_b[-1] - t_b[0]) < 20:
        return np.nan, 0.0
    fs_r = C.FR_REMUESTREO_HZ
    tu = np.arange(t_b[0], t_b[-1], 1.0 / fs_r)
    # Pchip: interpola sin "rebotes" entre latidos (mejor que la lineal y que el spline normal)
    yu = PchipInterpolator(t_b, y)(tu)
    yu = detrend(yu) * np.hanning(len(yu))
    nfft = 8 * len(yu)
    S = np.abs(np.fft.rfft(yu, nfft)) ** 2
    f = np.fft.rfftfreq(nfft, 1.0 / fs_r)
    m = (f >= C.FR_BANDA_HZ[0]) & (f <= C.FR_BANDA_HZ[1])
    if not m.any() or S[m].sum() == 0:
        return np.nan, 0.0
    Sb, fb = S[m], f[m]
    # Solo picos REALES (maximo local con vecinos mas bajos a ambos lados). El borde de la
    # banda nunca cuenta: una deriva lenta puede dejar el maximo pegado en 0,1 Hz sin que
    # haya respiracion ahi (caso bidmc05: se quedaba en 6 rpm).
    pk, _ = find_peaks(Sb)
    if len(pk) == 0:
        return np.nan, 0.0
    i = pk[np.argmax(Sb[pk])]
    return 60.0 * fb[i], float(Sb[i] / Sb.sum())


def fusionar(cands):
    """cands: {nombre: (fr, prominencia)}. Devuelve (FR, cuantas fuentes coinciden).
    Elige el grupo de fuentes que coinciden (dentro de FR_TOL_RPM) con mas miembros;
    el empate se rompe por prominencia. FR = promedio ponderado por prominencia."""
    v = {k: x for k, x in cands.items() if not np.isnan(x[0])}
    if not v:
        return np.nan, 0
    mejor, mejor_clave = None, None
    for k, (fr, _) in v.items():
        grupo = [j for j, (f2, _) in v.items() if abs(f2 - fr) <= C.FR_TOL_RPM]
        clave = (len(grupo), sum(v[j][1] for j in grupo))
        if mejor_clave is None or clave > mejor_clave:
            mejor, mejor_clave = grupo, clave
    w = np.array([v[j][1] for j in mejor])
    f = np.array([v[j][0] for j in mejor])
    fr = float(np.average(f, weights=w)) if w.sum() > 0 else float(np.mean(f))
    return fr, len(mejor)