"""Lector del archivo .bin que escribe la ESP32 (lo unico que necesita el servidor).
Devuelve dict(t, ecg, ir, red, fs). Los lectores de BIDMC y MIMIC estan en validacion/datasets.py."""
import numpy as np

# Debe coincidir EXACTAMENTE con el struct del firmware (empaquetado, little-endian)
DTYPE_X = np.dtype([("t_us", "<u4"), ("ecg", "<u2"), ("red", "<u4"), ("ir", "<u4")])


def uniformizar(t_s, canales, fs):
    """El reloj de la ESP32 no es perfecto: interpola a una rejilla uniforme."""
    t_u = np.arange(t_s[0], t_s[-1], 1.0 / fs)
    return t_u, {k: np.interp(t_u, t_s, v) for k, v in canales.items()}


def x_desde_array(a, fs):
    """Arreglo estructurado DTYPE_X -> dict(t, ecg, ir, red, fs), con tiempo uniforme."""
    # t_us es de 32 bits y da la vuelta a los 71 min: unwrap lo corrige
    t = np.unwrap(a["t_us"].astype(np.float64), period=2**32) * 1e-6
    t = t - t[0]
    t_u, c = uniformizar(t, {"ecg": a["ecg"].astype(float),
                             "red": a["red"].astype(float),
                             "ir": a["ir"].astype(float)}, fs)
    return dict(t=t_u, fs=fs, **c)


def leer_bin(ruta, fs):
    """Lee el archivo binario que escribe la ESP32 en la microSD (14 bytes por muestra)."""
    return x_desde_array(np.fromfile(ruta, dtype=DTYPE_X), fs)


# ---------------------------------------------------------------- paquetes (USB y Wi-Fi)
# Cabecera de 32 bytes + n muestras de 14 bytes. Debe coincidir con firmware/.../protocolo.h
DTYPE_CAB = np.dtype([("magic", "S4"), ("version", "u1"), ("flags", "u1"), ("n", "<u2"),
                      ("paciente", "<u4"), ("sesion", "<u4"), ("seq", "<u4"),
                      ("t0_us", "<u4"), ("epoch_s", "<u4"), ("crc", "<u2"), ("reservado", "<u2")])
MAGIC = b"BIO1"
N_MAX_PAQUETE = 2000      # un paquete mas grande que esto se considera basura


def crc16_ccitt(datos):
    """CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF). Igual que el firmware."""
    crc = 0xFFFF
    for b in bytes(datos):
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc


def leer_paquetes(datos):
    """Busca paquetes en un flujo de bytes (puede traer texto de depuracion mezclado).
    Devuelve (lista de (cabecera, muestras), bytes_consumidos, n_crc_malos).
    Lo que sobre al final (un paquete a medias) NO se consume: vuelve a llamar con el resto."""
    paquetes, malos, i = [], 0, 0
    datos = bytes(datos)
    ncab = DTYPE_CAB.itemsize
    while True:
        j = datos.find(MAGIC, i)
        if j < 0:
            # conserva los ultimos 3 bytes por si el 'BIO1' viene partido
            return paquetes, max(i, len(datos) - 3), malos
        if len(datos) - j < ncab:
            return paquetes, j, malos
        cab = np.frombuffer(datos, dtype=DTYPE_CAB, count=1, offset=j)[0]
        n = int(cab["n"])
        if cab["version"] != 1 or n == 0 or n > N_MAX_PAQUETE:
            i = j + 1
            continue
        fin = j + ncab + n * DTYPE_X.itemsize
        if len(datos) < fin:
            return paquetes, j, malos
        cuerpo = datos[j + ncab:fin]
        if crc16_ccitt(cuerpo) != int(cab["crc"]):
            malos += 1
            i = j + 1
            continue
        paquetes.append((cab.copy(), np.frombuffer(cuerpo, dtype=DTYPE_X)))
        i = fin


def unir_paquetes(paquetes):
    """Lista de (cabecera, muestras) de UNA sesion -> arreglo DTYPE_X ordenado por seq, y secuencias que faltan."""
    if not paquetes:
        return np.zeros(0, dtype=DTYPE_X), []
    orden = sorted(paquetes, key=lambda p: int(p[0]["seq"]))
    vistos, utiles = set(), []
    for cab, m in orden:                       # descarta repetidos (reintentos)
        if int(cab["seq"]) not in vistos:
            vistos.add(int(cab["seq"]))
            utiles.append((cab, m))
    seqs = [int(c["seq"]) for c, _ in utiles]
    faltan = sorted(set(range(seqs[0], seqs[-1] + 1)) - set(seqs))
    return np.concatenate([m for _, m in utiles]), faltan
