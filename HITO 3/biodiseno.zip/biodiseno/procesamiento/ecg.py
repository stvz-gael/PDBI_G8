"""ECG: picos R, RR, frecuencia cardiaca, HRV y respiracion derivada."""
import numpy as np
from scipy.signal import find_peaks
from . import config as C


def _detectar_r_altura(ecg_f, fs):
    """Metodo anterior: candidatos por altura. Se confunde si la onda T es alta."""
    cand, _ = find_peaks(ecg_f, distance=int(C.R_REFRACTARIO_S * fs))
    if len(cand) == 0:
        return np.array([], dtype=int)
    umbral0 = 0.5 * np.percentile(ecg_f, 99)
    aceptadas = []
    for i in cand:
        ref = np.mean([ecg_f[j] for j in aceptadas[-C.R_N_ULTIMAS:]]) if aceptadas else None
        umbral = C.R_UMBRAL_FRAC * ref if ref is not None else umbral0
        if ecg_f[i] >= umbral:
            aceptadas.append(i)
    return np.array(aceptadas, dtype=int)


def _detectar_r_pendiente(ecg_f, fs):
    """Estilo Pan-Tompkins: el QRS es lo mas EMPINADO del ECG, la onda T y la P
    suben despacio. Se detecta sobre la energia de la pendiente:
      d = derivada de la senal   ->   e = d^2   ->   promedio movil de 80 ms
    y luego se ubica la R exacta como el maximo de la senal cerca de ese pico.
    Mismo criterio adaptativo de antes (0,5 x media de las ultimas 8), pero sobre e."""
    d = np.gradient(ecg_f, 1.0 / fs)
    w = max(1, int(0.08 * fs))
    env = np.convolve(d ** 2, np.ones(w) / w, mode="same")
    cand, _ = find_peaks(env, distance=int(C.R_REFRACTARIO_S * fs))
    if len(cand) == 0:
        return np.array([], dtype=int)
    umbral0 = 0.2 * np.percentile(env, 99)
    aceptadas = []
    for i in cand:
        ref = np.mean([env[j] for j in aceptadas[-C.R_N_ULTIMAS:]]) if aceptadas else None
        umbral = C.R_UMBRAL_FRAC * ref if ref is not None else umbral0
        if env[i] >= umbral:
            aceptadas.append(i)
    medio = int(0.06 * fs)
    idx = []
    for i in aceptadas:
        a, b = max(0, i - medio), min(len(ecg_f), i + medio + 1)
        idx.append(a + int(np.argmax(ecg_f[a:b])))
    return np.unique(np.array(idx, dtype=int))


def detectar_r(ecg_f, fs, metodo=None):
    """Indices de las ondas R. 'metodo' = "altura" o "pendiente"; si es None se usa
    config.py (R_METODO). Con "auto" aqui se usa pendiente (pipeline.py elige entre ambos)."""
    metodo = metodo or C.R_METODO
    if metodo == "neurokit":
        return _detectar_r_neurokit(ecg_f, fs)
    if metodo == "altura":
        return _detectar_r_altura(ecg_f, fs)
    return _detectar_r_pendiente(ecg_f, fs)


def _detectar_r_neurokit(ecg_f, fs):
    """Detector de NeuroKit2 (libreria publicada y muy usada). Recibe el ECG YA filtrado y
    orientado (el filtro y la polaridad siguen siendo de este proyecto).
    Si NeuroKit falla o no esta instalado, usa el detector propio por pendiente."""
    try:
        import neurokit2 as nk
        idx = nk.ecg_peaks(ecg_f, sampling_rate=fs, method="neurokit")[1]["ECG_R_Peaks"]
        return np.asarray(idx, dtype=int)
    except Exception:
        return _detectar_r_pendiente(ecg_f, fs)


def orientar(ecg_f, fs):
    """Detecta si el ECG viene invertido (R hacia abajo) y lo corrige.
    Criterio principal: el QRS es la deflexion mas grande y rapida. Si los picos
    negativos (percentil 1) son bastante mayores que los positivos (percentil 99),
    la senal esta invertida. Solo si hay duda (ratio cercano a 1) se usa la
    regularidad de los RR como desempate.
    (Elegir solo por regularidad fallo: contar cada latido dos veces tambien es regular.)
    Devuelve (ecg orientado, indices R, invertido)."""
    p_hi = np.percentile(ecg_f, 99)
    p_lo = -np.percentile(ecg_f, 1)
    if p_lo > C.ORIENTACION_RATIO * p_hi:
        inv = True
    elif p_hi > C.ORIENTACION_RATIO * p_lo:
        inv = False
    else:
        def calidad(x):
            idx = detectar_r(x, fs)
            if len(idx) < 3:
                return 0.0
            rr = np.diff(idx) / fs
            return float(np.mean((rr >= C.RR_MIN_S) & (rr <= C.RR_MAX_S)))
        inv = calidad(-ecg_f) > calidad(ecg_f) + 0.1
    x = -ecg_f if inv else ecg_f
    return x, detectar_r(x, fs), inv


def rr_validos(t_r):
    """RR en segundos y mascara de los RR fisiologicamente posibles."""
    rr = np.diff(t_r)
    ok = (rr >= C.RR_MIN_S) & (rr <= C.RR_MAX_S)
    return rr, ok


def fc_hrv(t_r):
    """FC media (lpm) y HRV como SDNN (ms): desviacion estandar de los RR."""
    rr, ok = rr_validos(t_r)
    rr = rr[ok]
    if len(rr) < 3:
        return np.nan, np.nan
    return 60.0 / np.mean(rr), 1000.0 * np.std(rr, ddof=1)


def frecuencia_respiratoria(t_r, amp_r):
    """Solo la fuente EDR (altura de la R). La version completa, con fusion,
    esta en respiracion.py y la usa pipeline.py."""
    from .respiracion import espectro_pico
    return espectro_pico(t_r, amp_r)[0]