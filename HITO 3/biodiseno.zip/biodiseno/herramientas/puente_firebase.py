"""Puente: ESP32 (USB) o archivo de ECG  ->  calcula FC, FR, SpO2  ->  Firebase (la app lo lee).

Idea: la laptop hace de servidor mientras pruebas. No necesita Cloud Functions ni plan Blaze.

Fuentes (elige una):
  --puerto COM11            ESP32 por USB, en vivo
  --archivo grabacion.pkt   paquetes BIO1 guardados con ver_senal --guardar (o .bin de 14 bytes por muestra)
  --archivo mi_ecg.csv      un ECG tuyo (1 columna: ecg, o 2 columnas: tiempo_s, ecg). Usa --fs si es 1 columna
  --simular                 senal sintetica con valores conocidos (FC 75, FR 15, SpO2 97), para probar la app

Que se publica: ecg, ppg (IR y rojo), actual (FC, FR, SpO2, calidad, estado) e historial.
  Con --simular, FC/FR/SpO2 salen desde el primer segundo (valores falsos: 75, 15, 97).

Destino:
  (por defecto)   Firebase, segun herramientas/firebase_config.json
  --seco          NO envia nada: solo imprime lo que enviaria (prueba sin Firebase)

Ejemplos:
  python -m herramientas.puente_firebase --simular --seco
  python -m herramientas.puente_firebase --simular
  python -m herramientas.puente_firebase --puerto COM11
  python -m herramientas.puente_firebase --archivo prueba_ecg/ecg_ejemplo.csv --fs 250
"""
import argparse
import json
import os
import re
import sys
import threading
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from procesamiento import config as C
from procesamiento import ecg as E
from procesamiento import respiracion as RESP
from procesamiento import ppg as PPG_P
from procesamiento.filtros import pasabanda
from procesamiento.cargador import DTYPE_X, leer_paquetes
from procesamiento.pipeline import procesar
from herramientas.ver_senal import Acumulador, abrir_puerto, filtrar_ecg, hay_dedo, ruido_red_pct

# Con la ESP32 a 200 Hz la red de 60 Hz y sus armonicos se ven en 60, 80, 20 y 40 Hz: se quitan antes de detectar latidos
C.ECG_MUESCAS = C.MUESCAS_RED_200HZ

FS = int(C.FS_DISPOSITIVO)
RUTA_CONFIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "firebase_config.json")
CADA_METRICAS_S = 5          # cada cuanto se recalculan FC, FR y SpO2 (y se actualiza la app)
MIN_ECG_S = 15               # segundos de ECG para dar la primera FC
MIN_FR_S = 60                # segundos para dar FR
MIN_SPO2_S = 70              # segundos para dar SpO2 (necesita PPG)
Q_MIN = 0.8                  # calidad minima del ECG para publicar FC
Q_PPG_MIN = 0.6              # fraccion minima de pulsos regulares para dar FC desde el PPG
PI_MIN = 0.2                 # indice de perfusion minimo (%) para dar SpO2
RUIDO_RED_MAX = 40.0         # si mas de este % de la potencia es ruido de red, no se publica nada


# ------------------------------------------------------------------ calculo
def valores_ppg(t, c):
    """FC (pulso), SpO2 y FR solo con el PPG. Sirve cuando el ECG no es util (electrodos sueltos, ruido).
    Devuelve dict(FC, FR, SpO2, PI, q). Un valor es None si la senal no alcanza."""
    out = dict(FC=None, FR=None, SpO2=None, PI=None, q=0.0)
    if not hay_dedo(c["ir"]) or t[-1] - t[0] < 20:
        return out
    ir_f = pasabanda(c["ir"], FS, *C.PPG_BANDA, C.ORDEN_FILTRO)
    red_f = pasabanda(c["red"], FS, *C.PPG_BANDA, C.ORDEN_FILTRO)
    if PPG_P.invertido(ir_f, FS):
        ir_f, red_f = -ir_f, -red_f
    t_p = PPG_P.pulsos(t, ir_f, FS)
    tp = t_p[t_p >= t[-1] - 20]
    if len(tp) < 8:
        return out
    d = np.diff(tp)
    d = d[(d >= C.RR_MIN_S) & (d <= C.RR_MAX_S)]
    if len(d) < 6:
        return out
    med = float(np.median(d))
    out["q"] = float(np.mean(np.abs(d - med) / med < 0.2))          # fraccion de pulsos con intervalo regular
    if out["q"] < Q_PPG_MIN:
        return out
    out["FC"] = round(60.0 / med, 1)
    n = 30 * FS
    sp, pi = PPG_P.spo2_y_pi(c["ir"][-n:], ir_f[-n:], c["red"][-n:], red_f[-n:])
    if pi == pi:
        out["PI"] = round(float(pi), 2)
    if sp == sp and pi == pi and pi >= PI_MIN:
        out["SpO2"] = round(float(sp), 1)
    if t[-1] - t[0] >= MIN_FR_S:                                    # FR por la variacion lenta (linea base) del PPG
        i_p = np.searchsorted(t, t_p)
        i_p = i_p[i_p < len(t)]
        mask = t[i_p] >= t[-1] - 60
        fr, prom = RESP.espectro_pico(t[i_p][mask], c["ir"][i_p][mask])
        if fr == fr and prom >= C.FR_PROM_MIN:
            out["FR"] = round(float(fr), 1)
    return out


def calcular_valores(acu):
    """Devuelve dict(FC, FR, SpO2, calidad, motivo, fuente). Un valor es None si la senal no alcanza para calcularlo.
    Nunca inventa: si la senal esta mala, manda None y la app no debe mostrar un numero falso.
    FC y FR salen del ECG cuando este es bueno; si no, el pulso (FC) y la linea base (FR) salen del PPG.
    SpO2 siempre sale del PPG (necesita el dedo puesto)."""
    v = dict(FC=None, FR=None, SpO2=None, calidad=0.0, motivo="", fuente=None)
    d = acu.ultimos(120)
    if d is None or len(d[0]) < (MIN_ECG_S + 2) * FS:
        v["motivo"] = "juntando senal"
        return v
    t, c = d
    t, c = t[:-2 * FS], {k: x[:-2 * FS] for k, x in c.items()}      # el borde final del filtro de fase cero se descarta
    motivos = []
    ecg_ok = False
    try:
        # ---------------- ECG
        pct = ruido_red_pct(c["ecg"][-8 * FS:])
        if acu.flags & 1:
            motivos.append("electrodo suelto")
        elif pct > RUIDO_RED_MAX:                                    # casi no hay ECG: son los 60 Hz y sus rebotes
            motivos.append(f"ECG con ruido de red {pct:.0f} %")
        else:
            ecg_f = filtrar_ecg(c["ecg"])
            ecg_f, _, _ = E.orientar(ecg_f, FS)
            idx = E.detectar_r(ecg_f, FS, C.R_METODO)
            tr, ar = t[idx], ecg_f[idx]
            m = tr >= t[-1] - 15
            if m.sum() < 5:
                motivos.append("ECG: pocos latidos")
            else:
                fc, _ = E.fc_hrv(tr[m])
                _, ok = E.rr_validos(tr[m])
                q = float(np.mean(ok))
                v["calidad"] = round(q, 2)
                if q < Q_MIN or fc != fc:
                    motivos.append(f"ECG de mala calidad ({q:.2f})")
                else:
                    ecg_ok = True
                    v["FC"], v["fuente"] = round(float(fc), 1), "ECG"
                    if t[-1] - t[0] >= MIN_FR_S:
                        m60 = tr >= t[-1] - 60
                        fr = RESP.espectro_pico(tr[m60], ar[m60])[0]
                        if fr == fr:
                            v["FR"] = round(float(fr), 1)
        # ---------------- PPG
        pp = valores_ppg(t, c)
        if hay_dedo(c["ir"]) and t[-1] - t[0] >= MIN_SPO2_S and ecg_ok:   # con ECG bueno, el calculo completo del proyecto
            z = procesar(t, c["ecg"], c["ir"], c["red"], FS)
            if len(z):
                u = z.iloc[-1]
                if bool(u.valido):
                    v["FC"] = round(float(u.FC), 1)
                    if u.FR == u.FR:
                        v["FR"] = round(float(u.FR), 1)
                    if u.SpO2 == u.SpO2:
                        v["SpO2"] = round(float(u.SpO2), 1)
        if v["FC"] is None and pp["FC"] is not None:
            v["FC"], v["fuente"] = pp["FC"], "PPG"
            v["calidad"] = round(pp["q"], 2)
        if v["FR"] is None and pp["FR"] is not None:
            v["FR"] = pp["FR"]
        if v["SpO2"] is None and pp["SpO2"] is not None:
            v["SpO2"] = pp["SpO2"]
        if not hay_dedo(c["ir"]):
            import numpy as _np
            _ir = _np.asarray(c["ir"], float)
            motivos.append(f"PPG sin dedo: IR medio {_ir.mean():.0f}, variacion {_ir.std():.1f}, hace falta > {C.PPG_UMBRAL_DEDO:.0f}")
        v["motivo"] = "ok" if ecg_ok else "; ".join(motivos) or "sin senal util"
        if not ecg_ok and v["FC"] is not None:
            v["motivo"] = "FC desde PPG (" + v["motivo"] + ")"
    except Exception as e:                                           # nunca tumbar el puente por un calculo
        v["motivo"] = f"error de calculo: {e}"
    return v


# ------------------------------------------------------------------ Firebase
class Destino:
    """Escribe en Firebase (Realtime Database o Firestore) con las rutas de firebase_config.json."""

    def __init__(self, seco):
        self.seco = seco
        self.cfg = self._leer_config()
        self.db = self.fs = None
        if seco:
            return
        try:
            import firebase_admin
            from firebase_admin import credentials
        except ImportError:
            raise SystemExit("Falta firebase-admin. Instalalo con:  pip install firebase-admin")
        clave = self.cfg["clave_servicio"]
        if not os.path.isabs(clave):
            clave = os.path.join(os.path.dirname(RUTA_CONFIG), clave)
        if not os.path.exists(clave):
            raise SystemExit(f"No encuentro la clave de servicio: {clave}\n"
                             "Descargala en Firebase > Configuracion del proyecto > Cuentas de servicio > Generar clave privada,\n"
                             "y ponla en la carpeta herramientas con ese nombre. Para probar sin Firebase usa --seco.")
        opciones = {"databaseURL": self.cfg["database_url"]} if self.cfg["backend"] == "rtdb" else {}
        firebase_admin.initialize_app(credentials.Certificate(clave), opciones)
        if self.cfg["backend"] == "rtdb":
            from firebase_admin import db
            self.db = db
        else:
            from firebase_admin import firestore
            self.fs = firestore.client()

    @staticmethod
    def _leer_config():
        if not os.path.exists(RUTA_CONFIG):
            return dict(backend="rtdb", database_url="", clave_servicio="clave_servicio.json",
                        ruta_base="pacientes/1", nombres=dict(ecg="ecg", valores="actual", historial="historial"))
        return json.load(open(RUTA_CONFIG, encoding="utf-8"))

    def _mostrar(self, ruta, dato):
        txt = json.dumps(dato, ensure_ascii=False)
        print(f"[seco] {ruta} <- {txt[:150]}{'...' if len(txt) > 150 else ''}")

    def escribir(self, sub, dato, historial=False):
        ruta = f"{self.cfg['ruta_base']}/{sub}"
        if self.seco:
            self._mostrar(ruta, dato)
            return
        if self.db is not None:
            ref = self.db.reference(ruta)
            ref.push(dato) if historial else ref.set(dato)
        else:                                                         # Firestore: coleccion/documento
            partes = ruta.split("/")
            if historial:
                partes.append(str(int(time.time() * 1000)))
            if len(partes) % 2:
                partes.append("datos")
            self.fs.document("/".join(partes)).set(dato)


def publicar(dest, ecg_bloque, valores, historial=False, ppg_bloque=None):
    n = dest.cfg.get("nombres", {})
    nom_ecg, nom_ppg = n.get("ecg", "ecg"), n.get("ppg", "ppg")
    nom_val, nom_his = n.get("valores", "actual"), n.get("historial", "historial")
    ahora = time.time()
    if ecg_bloque is not None:
        dest.escribir(nom_ecg, dict(t=ahora, fs=FS, muestras=ecg_bloque))
    if ppg_bloque is not None:
        dest.escribir(nom_ppg, dict(t=ahora, fs=FS, ir=ppg_bloque[0], rojo=ppg_bloque[1], dedo=bool(ppg_bloque[2])))
    if valores is not None:
        dato = dict(t=ahora, FC=valores["FC"], FR=valores["FR"], SpO2=valores["SpO2"],
                    calidad=valores["calidad"], estado=valores["motivo"], fuenteFC=valores.get("fuente"))
        dest.escribir(nom_val, dato)
        if historial:
            dest.escribir(nom_his, dato, historial=True)


def valores_simulados(rng):
    """Para --simular: FC, FR y SpO2 desde el primer segundo (los de la senal falsa, con una pequena variacion)."""
    return dict(FC=round(75 + rng.normal(0, 0.6), 1), FR=round(15 + rng.normal(0, 0.4), 1),
                SpO2=round(97 + rng.normal(0, 0.3), 1), calidad=1.0, motivo="simulado", fuente="simulado")


# ------------------------------------------------------------------ fuentes
def hilo_serie(ser, acu, parar):
    buf = b""
    while not parar.is_set():
        buf += ser.read(ser.in_waiting or 1)
        paq, usados, malos = leer_paquetes(buf)
        for m in re.finditer(rb"#[ -~]{3,200}\n", buf[:usados]):
            print(m.group().decode().strip())
        buf = buf[usados:]
        acu.crc_malos += malos
        for cab, m in paq:
            acu.agregar(cab, m)
    ser.close()


def muestras_desde_csv(ruta, fs_arg):
    """CSV/TXT de ECG -> arreglo DTYPE_X a 200 Hz (ecg escalado a cuentas de 12 bits, sin PPG)."""
    primera = open(ruta, encoding="utf-8-sig").readline().replace(";", ",").replace("\t", ",")
    try:
        [float(x) for x in primera.strip().split(",") if x.strip()]
        salto = 0                                   # la primera fila ya son numeros
    except ValueError:
        salto = 1                                   # la primera fila es el encabezado
    d = np.genfromtxt(ruta, delimiter=",", skip_header=salto, comments="#", encoding="utf-8-sig")
    d = np.atleast_2d(d.T).T if d.ndim == 1 else d
    if d.shape[1] == 1:
        if not fs_arg:
            raise SystemExit("El archivo tiene 1 columna: dime la frecuencia de muestreo con --fs (ej. --fs 250).")
        y, t = d[:, 0], np.arange(len(d)) / fs_arg
    else:
        t, y = d[:, 0], d[:, 1]
    t_u = np.arange(t[0], t[-1], 1.0 / FS)
    y_u = np.interp(t_u, t, y)
    y_u = (y_u - np.mean(y_u)) / (np.std(y_u) + 1e-12)
    a = np.zeros(len(t_u), dtype=DTYPE_X)
    a["t_us"] = ((t_u - t_u[0]) * 1e6).astype(np.uint64) % 2**32
    a["ecg"] = np.clip(2048 + 400 * y_u, 0, 4095).astype(np.uint16)
    return a


def muestras_simuladas(duracion=600):
    from pruebas.simulador import simular
    x, _ = simular(duracion_s=duracion, fs=FS, fc=75, fr=15, spo2=97, semilla=1)
    a = np.zeros(len(x["t"]), dtype=DTYPE_X)
    a["t_us"] = (x["t"] * 1e6).astype(np.uint64) % 2**32
    e = x["ecg"]
    a["ecg"] = np.clip(2048 + 600 * (e - e.mean()) / e.std() * 0.6, 0, 4095).astype(np.uint16)
    a["ir"], a["red"] = (2 * x["ir"]).astype(np.uint32), (2 * x["red"]).astype(np.uint32)   # x2: sube el nivel DC sobre el umbral de dedo; la razon rojo/IR no cambia
    return a


def muestras_desde_archivo(ruta, fs_arg):
    if ruta.lower().endswith((".csv", ".txt")):
        return muestras_desde_csv(ruta, fs_arg)
    datos = open(ruta, "rb").read()
    paq, _, _ = leer_paquetes(datos)
    if paq:
        return np.concatenate([m for _, m in paq])
    return np.fromfile(ruta, dtype=DTYPE_X)                            # .bin crudo de la microSD


def hilo_reproducir(a, acu, parar):
    """Entrega las muestras como si llegaran en vivo: un bloque de 1 s por segundo."""
    cab = dict(seq=0, flags=0)
    for i in range(0, len(a) - FS + 1, FS):
        if parar.is_set():
            return
        cab["seq"] = i // FS
        acu.agregar(cab, a[i:i + FS])
        time.sleep(1.0)
    print("# fin del archivo: el puente se detiene en unos segundos")
    time.sleep(CADA_METRICAS_S + 1)
    parar.set()


MANTENER_S = 30   # si un valor falla un momento, se repite el ultimo bueno hasta 30 s (la app no parpadea)


def mantener(v, previos):
    ahora = time.time()
    for k in ("FC", "FR", "SpO2"):
        if v[k] is not None:
            previos[k] = (v[k], ahora)
        elif k in previos and ahora - previos[k][1] <= MANTENER_S and v["motivo"] not in ("electrodo suelto",):
            v[k] = previos[k][0]
    return v


# ------------------------------------------------------------------ principal
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--puerto")
    ap.add_argument("--baud", type=int, default=921600)
    ap.add_argument("--archivo")
    ap.add_argument("--fs", type=float, help="frecuencia de muestreo del CSV si tiene 1 columna")
    ap.add_argument("--simular", action="store_true")
    ap.add_argument("--umbral-dedo", type=float, help="IR minimo para considerar dedo (por defecto 50000)")
    ap.add_argument("--seco", action="store_true", help="no envia a Firebase, solo imprime")
    a = ap.parse_args()
    if a.umbral_dedo:
        C.PPG_UMBRAL_DEDO = a.umbral_dedo
    if not (a.puerto or a.archivo or a.simular):
        ap.error("elige una fuente: --puerto COMx, --archivo ruta o --simular")

    dest = Destino(a.seco)
    acu, parar = Acumulador(), threading.Event()
    if a.puerto:
        threading.Thread(target=hilo_serie, args=(abrir_puerto(a.puerto, a.baud), acu, parar), daemon=True).start()
    else:
        datos = muestras_simuladas() if a.simular else muestras_desde_archivo(a.archivo, a.fs)
        print(f"# {len(datos) / FS:.0f} s de senal; se reproduce en tiempo real")
        threading.Thread(target=hilo_reproducir, args=(datos, acu, parar), daemon=True).start()

    print("# Puente en marcha. Ctrl+C para detener.")
    t_pub, t_val, valores, previos = 0.0, 0.0, None, {}
    rng = np.random.default_rng(7)
    try:
        while not parar.is_set():
            time.sleep(0.2)
            if acu.seq_ultima is None or time.time() - t_pub < 1.0:      # se publica 1 vez por segundo (los paquetes pueden ser de 0,1 s)
                continue
            t_pub = time.time()
            with acu.lock:
                bloque = acu.m["ecg"][-FS:].astype(int).tolist()
                ir_b, rojo_b = acu.m["ir"][-FS:], acu.m["red"][-FS:]
            ppg = None
            if ir_b.mean() > 0:                                          # el sensor manda datos (con 0 no se publica PPG)
                ppg = (ir_b.astype(int).tolist(), rojo_b.astype(int).tolist(), hay_dedo(ir_b))
            historial = False
            if time.time() - t_val >= CADA_METRICAS_S:
                t_val = time.time()
                valores = valores_simulados(rng) if a.simular else mantener(calcular_valores(acu), previos)
                historial = True
                print(f"FC {valores['FC']}  FR {valores['FR']}  SpO2 {valores['SpO2']}  ({valores['motivo']})")
            try:
                publicar(dest, bloque, valores, historial, ppg)
            except Exception as e:
                print(f"# No se pudo enviar a Firebase: {e}")
    except KeyboardInterrupt:
        pass
    parar.set()


if __name__ == "__main__":
    main()