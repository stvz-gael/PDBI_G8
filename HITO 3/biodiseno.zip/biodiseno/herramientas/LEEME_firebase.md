# Enviar los datos a la app (Firebase)

La laptop hace de servidor: lee la ESP32 por USB, calcula FC, FR y SpO2 y los escribe en Firebase.
La app solo tiene que leer esas rutas.

## 1. Averigua que rutas lee la app (lo unico que depende de tu companera)
En Android Studio busca (Ctrl+Shift+F) el texto `getReference(` (Realtime Database) o `collection(` (Firestore).
Anota los nombres. Ejemplo: `getReference("pacientes").child("1").child("actual")`.
Pon esos nombres en `firebase_config.json` (paso 3). Si la app aun no lee nada, usa los por defecto y se los pasas a ella.

## 2. Clave para escribir desde la laptop
Firebase > Configuracion del proyecto > Cuentas de servicio > Generar nueva clave privada.
Guarda el archivo como `herramientas/clave_servicio.json`. NO lo subas a GitHub ni lo mandes por chat.

## 3. Configuracion
Copia `firebase_config.ejemplo.json` como `firebase_config.json` y edita `database_url` (esta en Firebase > Realtime Database),
`ruta_base` y `nombres` segun el paso 1.

## 4. Probar (de menos a mas)
    pip install -r requirements-dev.txt
    python -m herramientas.puente_firebase --simular --seco     # sin Firebase: solo imprime
    python -m herramientas.puente_firebase --simular            # manda una senal falsa (FC 75, FR 15, SpO2 97) a la app
    python -m herramientas.puente_firebase --archivo prueba_ecg/ecg_ejemplo.csv --seco
    python -m herramientas.puente_firebase --puerto COM11       # tu ESP32 real

## Que se escribe
- `<ruta_base>/ecg`: {t, fs, muestras[200]} cada segundo (el ultimo segundo de ECG, cuentas de 12 bits)
- `<ruta_base>/actual`: {t, FC, FR, SpO2, calidad, estado} cada segundo (FC/FR/SpO2 se recalculan cada 5 s)
- `<ruta_base>/historial/...`: lo mismo, una fila cada 5 s (para la grafica de tendencia)

## Reglas
- Si la senal es mala o hay electrodo suelto, el valor se manda como `null` (no un numero falso). La app debe mostrar "--".
- Tiempos: FC desde los 17 s de senal, FR desde los 62 s, SpO2 desde los 72 s y solo con PPG conectado.
- Firestore (`"backend": "firestore"`): su plan gratis permite 20 mil escrituras al dia, y 1 por segundo son 86 mil. Para pruebas largas usa Realtime Database.
