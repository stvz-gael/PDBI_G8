"""Visor de señal en vivo: ve la señal cruda y filtrada, su espectro (FFT) y FC/FR/SpO2.
Sirve para decidir los filtros con datos reales antes de mandar nada al servidor.

En vivo (ESP32 por USB):      python -m herramientas.ver_senal --puerto COM5
Repetir una grabacion:        python -m herramientas.ver_senal --archivo grabacion.pkt
Solo texto (sin ventana):     agrega  --texto   (una linea por segundo con la calidad del ECG y del PPG; muy liviano)
Guardar lo que llega:         agrega  --guardar sesion.bin   (el .bin de 14 bytes por muestra del contrato)
Solo una imagen, sin ventana: python -m herramientas.ver_senal --archivo g.pkt --png salida.png

Los deslizadores cambian los filtros: la señal filtrada, la FFT y los valores de FC, FR y SpO2
se recalculan con las bandas nuevas. Cuando encuentres las que funcionan, ponlas en
procesamiento/config.py (ECG_BANDA y PPG_BANDA).
Corre desde la carpeta del proyecto. Necesita: pip install pyserial matplotlib
"""
import argparse
import os
import re
import sys
import threading
import time

import numpy as np

# Permite correrlo tambien como archivo suelto (boton Run de VS Code): agrega la carpeta del proyecto al path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from procesamiento import config as C
from procesamiento.cargador import DTYPE_X, leer_paquetes, uniformizar
from procesamiento import ecg as E
from procesamiento import respiracion as RESP
from procesamiento.filtros import pasabanda, muesca
from procesamiento.pipeline import procesar

FS = int(C.FS_DISPOSITIVO)


def filtrar_ecg(x):
    """Pasa-banda del proyecto y, si estan activadas, las muescas de la red electrica."""
    y = pasabanda(x, FS, *C.ECG_BANDA, C.ORDEN_FILTRO)
    for f0 in C.ECG_MUESCAS:
        if f0 < FS / 2:
            y = muesca(y, FS, f0)
    return y
MAX_S = 150            # segundos de señal que se guardan en memoria
CADA_METRICAS_S = 10   # cada cuanto se recalculan FC, FR y SpO2


def hay_dedo(ir):
    """True si el IR crudo muestra un dedo sobre el MAX30101 (nivel alto y con variacion).
    Sin dedo, el filtro normaliza ruido y parece una senal: por eso no basta mirar la forma."""
    ir = np.asarray(ir, float)
    return len(ir) > 0 and ir.std() >= 1.0 and ir.mean() >= C.PPG_UMBRAL_DEDO


class Acumulador:
    """Guarda las muestras recientes y las entrega con tiempo continuo y uniforme."""

    def __init__(self):
        self.lock = threading.Lock()
        self.m = np.zeros(0, dtype=DTYPE_X)
        self.paquetes = self.crc_malos = 0
        self.seq_ultima = None
        self.perdidos = 0
        self.flags = 0
        self.llegadas = []          # hora (reloj del PC) a la que llego cada paquete

    def velocidad(self):
        """(paquetes por segundo, muestras por segundo reales segun t_us). Deben dar ~1 y ~200."""
        with self.lock:
            ll = self.llegadas[-20:]
            t = self.m["t_us"][-2000:].astype(np.float64)
        pps = (len(ll) - 1) / (ll[-1] - ll[0]) if len(ll) >= 3 and ll[-1] > ll[0] else float("nan")
        t = np.unwrap(t, period=2**32) * 1e-6
        fs_real = (len(t) - 1) / (t[-1] - t[0]) if len(t) >= 20 and t[-1] > t[0] else float("nan")
        return pps, fs_real

    def agregar(self, cab, muestras):
        with self.lock:
            s = int(cab["seq"])
            if self.seq_ultima is not None and s > self.seq_ultima + 1:
                self.perdidos += s - self.seq_ultima - 1
            self.seq_ultima = s
            self.flags = int(cab["flags"])
            self.paquetes += 1
            self.llegadas.append(time.time())
            self.m = np.concatenate([self.m, muestras])[-MAX_S * FS:]

    def ultimos(self, seg):
        """t (s), ecg, red, ir de los ultimos `seg` segundos, a rejilla uniforme de 200 Hz."""
        with self.lock:
            a = self.m[-int(seg * FS * 1.05):].copy()
        if len(a) < 20:
            return None
        t = np.unwrap(a["t_us"].astype(np.float64), period=2**32) * 1e-6
        t_u, c = uniformizar(t, {"ecg": a["ecg"].astype(float), "red": a["red"].astype(float),
                                 "ir": a["ir"].astype(float)}, FS)
        return t_u[-int(seg * FS):], {k: v[-int(seg * FS):] for k, v in c.items()}


def abrir_puerto(puerto, baud):
    """Abre el puerto serie o termina con un mensaje claro (el error mas comun es que otro programa lo tenga abierto)."""
    try:
        import serial
    except ImportError:
        raise SystemExit("Falta pyserial. Instalalo con:  pip install pyserial")
    try:
        return serial.Serial(puerto, baud, timeout=0.1)
    except serial.SerialException as e:
        raise SystemExit(
            f"No se pudo abrir {puerto}: {e}\n"
            "Casi siempre es que otro programa lo tiene abierto: cierra el Monitor Serie del Arduino IDE,\n"
            "otra ventana de este visor (o su terminal, con Ctrl+C) y vuelve a intentar.\n"
            "Si no, desconecta y conecta el USB y revisa el numero de puerto en el IDE.")


def hilo_serie(ser, acu, archivo_guardar, parar):
    buf = b""
    guardar = open(archivo_guardar, "ab") if archivo_guardar else None
    while not parar.is_set():
        buf += ser.read(ser.in_waiting or 1)
        paq, usados, malos = leer_paquetes(buf)
        for m in re.finditer(rb"#[ -~]{3,200}\n", buf[:usados]):       # lineas de estado del firmware
            print(m.group().decode().strip())
        buf = buf[usados:]
        acu.crc_malos += malos
        for cab, m in paq:
            acu.agregar(cab, m)
            if guardar:
                guardar.write(m.tobytes())
                guardar.flush()
    ser.close()


def cargar_archivo(ruta, acu, archivo_guardar=None):
    datos = open(ruta, "rb").read()
    paq, _, malos = leer_paquetes(datos)
    acu.crc_malos += malos
    for cab, m in paq:
        acu.agregar(cab, m)
    if archivo_guardar:
        with open(archivo_guardar, "wb") as f:
            for _, m in paq:
                f.write(m.tobytes())
    print(f"{len(paq)} paquetes leidos de {ruta} (CRC malos: {malos})")


class Metricas:
    """Corre el procesamiento del proyecto cada 10 s en un hilo aparte (puede tardar ~1 s)."""

    def __init__(self, acu):
        self.acu, self.texto, self.t_ult, self.ocupado = acu, "Calculando... (hacen falta 70 s de señal)", 0, False

    def calcular_solo_ecg(self, t, c):
        """Sin PPG: FC y HRV (ultimos 30 s) y FR por EDR (ultimos 60 s) con las funciones del proyecto."""
        ecg_f = filtrar_ecg(c["ecg"])
        ecg_f, _, inv = E.orientar(ecg_f, FS)
        idx = E.detectar_r(ecg_f, FS, C.R_METODO)
        tr, ar = t[idx], ecg_f[idx]
        f = lambda v, d=1: "--" if v != v else f"{v:.{d}f}"
        m30 = tr >= t[-1] - 30
        fc, hrv = E.fc_hrv(tr[m30])
        _, ok = E.rr_validos(tr[m30]) if m30.sum() >= 3 else (None, np.array([0.0]))
        q = float(np.mean(ok))
        fr = np.nan
        if t[-1] - t[0] >= 60:
            m60 = tr >= t[-1] - 60
            fr = RESP.espectro_pico(tr[m60], ar[m60])[0]
        self.texto = (f"FC {f(fc)} lpm   HRV {f(hrv, 0)} ms   FR {f(fr)} rpm (solo EDR, sin PPG)   Latidos en 30 s: {int(m30.sum())}\n"
                      f"Q_ECG {q:.2f}   ECG invertido: {inv}   [PPG sin dedo o no conectado: sin SpO2, PI ni PAT]")

    def calcular(self):
        d = self.acu.ultimos(120)
        if d is None or len(d[0]) < 35 * FS:
            n = 0 if d is None else len(d[0]) / FS
            self.texto = f"Calculando... ({n:.0f} s de 35 s)"
            return
        if hay_dedo(d[1]["ir"]) and len(d[0]) < 70 * FS:
            self.texto = f"Calculando... ({len(d[0]) / FS:.0f} s de 70 s)"
            return
        t, c = d
        t, c = t[:-2 * FS], {k: v[:-2 * FS] for k, v in c.items()}   # el filtro de fase cero deforma el borde final: se descartan los ultimos 2 s
        if not hay_dedo(c["ir"]):        # sin PPG (ceros) o sin dedo sobre el sensor
            try:
                self.calcular_solo_ecg(t, c)
            except Exception as e:
                self.texto = f"Error al procesar el ECG: {e}"
            return
        try:
            z = procesar(t, c["ecg"], c["ir"], c["red"], FS)
        except Exception as e:
            self.texto = f"Error al procesar: {e}"
            return
        if len(z) == 0:
            self.texto = "Sin ventanas completas todavia"
            return
        u = z.iloc[-1]
        f = lambda v, d=1: "--" if v != v else f"{v:.{d}f}"
        self.texto = (f"FC {f(u.FC)} lpm   HRV {f(u.HRV_SDNN, 0)} ms   FR {f(u.FR)} rpm   SpO2 {f(u.SpO2)} %   "
                      f"PI {f(u.PI, 2)} %\n"
                      f"Q_ECG {u.Q_ECG:.2f}  Q_PPG {u.Q_PPG:.2f}  Q_PAT {u.Q_PAT:.2f}   "
                      f"valido={bool(u.valido)}  valido_pat={bool(u.valido_pat)}   "
                      f"ECG invertido: {z.attrs.get('ecg_invertido')}  PPG invertido: {z.attrs.get('ppg_invertido')}")

    def lanzar_si_toca(self):
        if self.ocupado or time.time() - self.t_ult < CADA_METRICAS_S:
            return
        self.ocupado, self.t_ult = True, time.time()

        def tarea():
            try:
                self.calcular()
            finally:
                self.ocupado = False
        threading.Thread(target=tarea, daemon=True).start()


def ruido_red_pct(ecg):
    """% de la potencia del ECG crudo que esta en 20, 40, 60 y 80 Hz (red de 60 Hz y sus rebotes a 200 Hz de muestreo).
    Cerca de 100 % = casi no entra ECG, solo interferencia."""
    x = np.asarray(ecg, float)
    x = x - x.mean()
    sp = np.abs(np.fft.rfft(x * np.hanning(len(x)))) ** 2
    f = np.fft.rfftfreq(len(x), 1.0 / FS)
    total = sp[(f >= 0.5) & (f <= 99)].sum() + 1e-12
    red = sum(sp[(f >= h - 1.5) & (f <= h + 1.5)].sum() for h in (20.0, 40.0, 60.0, 80.0))
    return 100.0 * red / total


def calidad(acu):
    """Resumen de calidad de los ultimos segundos. Devuelve (texto de una linea, dict)."""
    d = acu.ultimos(12)
    if d is None or len(d[0]) < 8 * FS:
        return "juntando senal...", {}
    t, c = d
    ecg = c["ecg"][-8 * FS:]
    # ECG: ruido de red = potencia en 20, 40, 60 y 80 Hz (+-1,5 Hz) frente a la potencia total
    pct_red = ruido_red_pct(ecg)
    # amplitud del ECG ya limpio (0,5 a 40 Hz y muescas de la red)
    viejo = C.ECG_MUESCAS
    C.ECG_MUESCAS = C.MUESCAS_RED_200HZ
    try:
        ef = filtrar_ecg(ecg)[FS:-FS]
    finally:
        C.ECG_MUESCAS = viejo
    ptp = float(np.percentile(ef, 99) - np.percentile(ef, 1))
    lo_p, lo_n = (1 if acu.flags & 4 else 0), (1 if acu.flags & 8 else 0)
    if acu.flags & 1:
        v_ecg = "SIN CONTACTO (revisa electrodos)"
    elif pct_red > 40:
        v_ecg = "RUIDO DE RED (pega bien los electrodos, aleja cargador y cables)"
    elif ptp < 40:
        v_ecg = "SENAL MUY DEBIL"
    else:
        v_ecg = "buena"
    ir = c["ir"][-8 * FS:]
    ir_m = float(ir.mean())
    if ir_m < 1:
        v_ppg = "el sensor manda 0 (revisa USAR_PPG 1 y cables SDA/SCL)"
        pi = float("nan")
    elif ir_m < C.PPG_UMBRAL_DEDO:
        v_ppg = f"SIN DEDO (IR {ir_m:.0f}, hace falta > {C.PPG_UMBRAL_DEDO:.0f})"
        pi = float("nan")
    else:
        irf = pasabanda(c["ir"], FS, *C.PPG_BANDA, C.ORDEN_FILTRO)[FS:-FS]
        pi = 100.0 * float(np.percentile(irf, 95) - np.percentile(irf, 5)) / ir_m
        v_ppg = "buena" if 0.1 <= pi <= 20 else f"DEBIL o saturada (PI {pi:.2f} %)"
    txt = (f"ECG: {v_ecg} | LO+={lo_p} LO-={lo_n} | amplitud {ptp:.0f} | ruido de red {pct_red:.0f} %"
           f"   ||   PPG: {v_ppg} | IR medio {ir_m:.0f}" + ("" if pi != pi else f" | PI {pi:.2f} %"))
    return txt, dict(ptp=ptp, pct_red=pct_red, ir=ir_m, pi=pi)


def espectro(x, fs):
    x = np.asarray(x, float)
    x = (x - x.mean()) * np.hanning(len(x))
    f = np.fft.rfftfreq(len(x), 1 / fs)
    mag = np.abs(np.fft.rfft(x)) / len(x)
    return f, 20 * np.log10(mag + 1e-12)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--puerto", help="puerto serie de la ESP32 (COM5, /dev/ttyACM0...)")
    ap.add_argument("--baud", type=int, default=921600)
    ap.add_argument("--archivo", help="repetir una grabacion de paquetes (.pkt)")
    ap.add_argument("--guardar", help="guardar las muestras en un .bin de 14 bytes por muestra")
    ap.add_argument("--ventana", type=float, default=6.0, help="segundos que se ven en pantalla")
    ap.add_argument("--png", help="guardar una imagen y salir (sin ventana)")
    ap.add_argument("--texto", action="store_true", help="sin ventana: una linea por segundo con la calidad del ECG y del PPG")
    a = ap.parse_args()
    if not a.puerto and not a.archivo:
        ap.error("indica --puerto o --archivo")

    if a.texto:
        acu, parar = Acumulador(), threading.Event()
        if a.archivo:
            cargar_archivo(a.archivo, acu, a.guardar)
        else:
            ser = abrir_puerto(a.puerto, a.baud)
            threading.Thread(target=hilo_serie, args=(ser, acu, a.guardar, parar), daemon=True).start()
        print("Modo texto: una linea por segundo. Ctrl+C para salir.")
        try:
            while True:
                pps, fs_real = acu.velocidad()
                linea, _ = calidad(acu)
                print(f"[{pps:4.1f} paq/s {fs_real:5.1f} m/s perdidos {acu.perdidos}] {linea}", flush=True)
                if a.archivo:
                    break
                time.sleep(1.0)
        except KeyboardInterrupt:
            pass
        parar.set()
        return

    import matplotlib
    if a.png:
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.widgets import Slider, CheckButtons

    acu, parar = Acumulador(), threading.Event()
    if a.archivo:
        cargar_archivo(a.archivo, acu, a.guardar)
    else:
        ser = abrir_puerto(a.puerto, a.baud)          # antes de abrir la ventana: si falla, se sabe de inmediato
        threading.Thread(target=hilo_serie, args=(ser, acu, a.guardar, parar), daemon=True).start()
    met = Metricas(acu)

    fig = plt.figure(figsize=(12.5, 7.8))
    gs = fig.add_gridspec(3, 2, left=0.06, right=0.98, top=0.95, bottom=0.27, hspace=0.75, wspace=0.18,
                          height_ratios=[1, 1, 0.25])
    ax_e, ax_fe = fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 1])
    ax_p, ax_fp = fig.add_subplot(gs[1, 0]), fig.add_subplot(gs[1, 1])
    ax_t = fig.add_subplot(gs[2, :]); ax_t.axis("off")
    txt = ax_t.text(0, 0.5, "", fontsize=10.5, va="center", family="monospace")

    def slider(y, nombre, lo, hi, v0, paso):
        ax = fig.add_axes([0.20, y, 0.30, 0.03])
        return Slider(ax, nombre, lo, hi, valinit=v0, valstep=paso)
    s_el = slider(0.17, "ECG pasa-altos (Hz)", 0.05, 5.0, C.ECG_BANDA[0], 0.05)
    s_eh = slider(0.12, "ECG pasa-bajos (Hz)", 15.0, 90.0, C.ECG_BANDA[1], 1.0)
    s_pl = slider(0.07, "PPG pasa-altos (Hz)", 0.05, 2.0, C.PPG_BANDA[0], 0.05)
    s_ph = slider(0.02, "PPG pasa-bajos (Hz)", 3.0, 30.0, C.PPG_BANDA[1], 0.5)

    ax_chk = fig.add_axes([0.56, 0.10, 0.34, 0.09]); ax_chk.set_frame_on(False)
    chk = CheckButtons(ax_chk, ["Muescas de la red (60, 80, 20 y 40 Hz)"], [False])

    def al_marcar(_):
        C.ECG_MUESCAS = C.MUESCAS_RED_200HZ if chk.get_status()[0] else ()
        met.t_ult = 0
    chk.on_clicked(al_marcar)

    def cambio(_):
        if s_el.val < s_eh.val:
            C.ECG_BANDA = (float(s_el.val), float(s_eh.val))
        if s_pl.val < s_ph.val:
            C.PPG_BANDA = (float(s_pl.val), float(s_ph.val))
        met.t_ult = 0                       # recalcular FC/FR/SpO2 con las bandas nuevas
    for s in (s_el, s_eh, s_pl, s_ph):
        s.on_changed(cambio)

    # Las lineas se crean una sola vez y solo se les cambian los datos (mucho mas rapido que redibujar todo)
    L = {}
    fps = {"v": 0.0, "n": 0, "t": time.time()}      # cuadros por segundo que logra el visor
    L["e_raw"], = ax_e.plot([], [], color="0.7", lw=0.8, label="cruda (sin promedio)")
    L["e_f"], = ax_e.plot([], [], color="C0", lw=1, label="filtrada")
    leg_e = ax_e.legend(loc="upper right", fontsize=8)
    ax_e.set_title("ECG (cuentas del ADC)"); ax_e.set_xlabel("s"); ax_e.set_xlim(-a.ventana, 0)
    L["p_ir"], = ax_p.plot([], [], color="C3", lw=1, label="IR filtrada")
    L["p_red"], = ax_p.plot([], [], color="C1", lw=1, alpha=0.7, label="rojo filtrada")
    leg_p = ax_p.legend(loc="upper right", fontsize=8)
    ax_p.set_xlabel("s"); ax_p.set_xlim(-a.ventana, 0)
    L["sin_ppg"] = ax_p.text(0.5, 0.5, "PPG no conectado o sin dedo", ha="center", va="center", transform=ax_p.transAxes)
    L["fe_raw"], = ax_fe.plot([], [], color="0.7", lw=0.8, label="cruda")
    L["fe_f"], = ax_fe.plot([], [], color="C0", lw=1, label="filtrada")
    ax_fe.axvline(60, color="r", ls=":", lw=0.8); ax_fe.text(60, 0.97, " 60 Hz", color="r", va="top", fontsize=8, transform=ax_fe.get_xaxis_transform())
    ax_fe.set_xlim(0, FS / 2); ax_fe.set_title("FFT del ECG"); ax_fe.set_xlabel("Hz"); ax_fe.set_ylabel("dB"); ax_fe.legend(fontsize=8)
    L["fp_raw"], = ax_fp.plot([], [], color="0.7", lw=0.8, label="cruda")
    L["fp_f"], = ax_fp.plot([], [], color="C3", lw=1, label="filtrada")
    ax_fp.set_xlim(0, 15); ax_fp.set_title("FFT del PPG (IR): el pico fuerte es el pulso, ~1 a 2 Hz")
    ax_fp.set_xlabel("Hz"); ax_fp.set_ylabel("dB"); ax_fp.legend(fontsize=8)
    L["sin_ppg2"] = ax_fp.text(0.5, 0.5, "PPG no conectado o sin dedo", ha="center", va="center", transform=ax_fp.transAxes)

    def limites(ax, y, margen=0.1, minimo=1.0):
        lo, hi = float(np.min(y)), float(np.max(y))
        d = max(hi - lo, minimo) * margen
        ax.set_ylim(lo - d, hi + d)

    def dibujar(_=None):
        d = acu.ultimos(a.ventana + 10)
        if d is None:
            txt.set_text("Esperando datos...")
            return
        t, c = d
        n = int(a.ventana * FS)
        tt = t[-n:] - t[-1]
        ecg_f = filtrar_ecg(c["ecg"])
        hay_ppg = hay_dedo(c["ir"])

        raw = (c["ecg"] - c["ecg"].mean())[-n:]
        L["e_raw"].set_data(tt, raw); L["e_f"].set_data(tt, ecg_f[-n:])
        limites(ax_e, np.r_[raw, ecg_f[-n:]], margen=0.3)
        leg_e.get_texts()[1].set_text(f"filtrada {C.ECG_BANDA[0]:.2f} a {C.ECG_BANDA[1]:.0f} Hz")
        f1, m1 = espectro(c["ecg"][-n:], FS); f2, m2 = espectro(ecg_f[-n:], FS)
        L["fe_raw"].set_data(f1, m1); L["fe_f"].set_data(f2, m2)
        ax_fe.set_ylim(m1.max() - 150, m1.max() + 15)

        for k in ("p_ir", "p_red", "fp_raw", "fp_f"):
            L[k].set_visible(hay_ppg)
        L["sin_ppg"].set_visible(not hay_ppg); L["sin_ppg2"].set_visible(not hay_ppg)
        if hay_ppg:
            ir_f = pasabanda(c["ir"], FS, *C.PPG_BANDA, C.ORDEN_FILTRO)
            red_f = pasabanda(c["red"], FS, *C.PPG_BANDA, C.ORDEN_FILTRO)
            z = lambda v: (v - v.mean()) / (v.std() + 1e-9)
            L["p_ir"].set_data(tt, z(ir_f[-n:])); L["p_red"].set_data(tt, z(red_f[-n:]))
            ax_p.set_ylim(-3.5, 3.5)
            ax_p.set_title(f"PPG, filtrada {C.PPG_BANDA[0]:.2f} a {C.PPG_BANDA[1]:.1f} Hz (normalizada)")
            f3, m3 = espectro(c["ir"][-n:], FS); f4, m4 = espectro(ir_f[-n:], FS)
            L["fp_raw"].set_data(f3, m3); L["fp_f"].set_data(f4, m4)
            ax_fp.set_ylim(m3.max() - 150, m3.max() + 15)
        else:
            ax_p.set_title("PPG"); ax_p.set_ylim(0, 1)

        ir_m = float(np.mean(c["ir"][-n:]))
        met.lanzar_si_toca()
        pps, fs_real = acu.velocidad()
        estado = (f"paquetes {acu.paquetes} ({pps:.1f}/s)  muestras/s reales {fs_real:.1f} (debe ser ~200)  "
                  f"cuadros/s del visor {fps['v']:.0f}  perdidos {acu.perdidos}  CRC malos {acu.crc_malos}")
        if acu.flags & 1:
            lo = f"*** ELECTRODO SUELTO ***   LO+ = {1 if acu.flags & 4 else 0}   LO- = {1 if acu.flags & 8 else 0}   (1 = sin contacto)"
        else:
            lo = "Electrodos: sin aviso (LO+ = 0, LO- = 0). Si LO+/LO- NO estan cableados, este aviso no sirve"
        if acu.flags & 2:
            estado += "   (hueco de tiempo en el PPG)"
        if ir_m < 1:
            ppg_txt = "PPG: el sensor manda 0 (revisa USAR_PPG 1 en config.h y el cableado I2C)"
        elif ir_m < C.PPG_UMBRAL_DEDO:
            ppg_txt = f"PPG: IR medio {ir_m:.0f}, bajo el umbral {C.PPG_UMBRAL_DEDO:.0f}: pon el dedo cubriendo el sensor (o sube LED_AMPLITUD)"
        else:
            ppg_txt = f"PPG: IR medio {ir_m:.0f} (dedo detectado)"
        lo = lo + "\n" + ppg_txt
        txt.set_text(estado + "\n" + lo + "\n" + met.texto)

    def rapido():
        """Cuadro liviano: solo mueve las 4 lineas de tiempo (ECG y PPG). No redibuja ejes, FFT ni texto."""
        d = acu.ultimos(a.ventana + 6)
        if d is None:
            return
        t, c = d
        n = int(a.ventana * FS)
        tt = t[-n:] - t[-1]
        ecg_f = filtrar_ecg(c["ecg"])
        L["e_raw"].set_data(tt, (c["ecg"] - c["ecg"].mean())[-n:]); L["e_f"].set_data(tt, ecg_f[-n:])
        if hay_dedo(c["ir"]):
            z = lambda v: (v - v.mean()) / (v.std() + 1e-9)
            L["p_ir"].set_data(tt, z(pasabanda(c["ir"], FS, *C.PPG_BANDA, C.ORDEN_FILTRO)[-n:]))
            L["p_red"].set_data(tt, z(pasabanda(c["red"], FS, *C.PPG_BANDA, C.ORDEN_FILTRO)[-n:]))

    if a.png:
        met.calcular()
        dibujar()
        fig.savefig(a.png, dpi=110)
        print("imagen:", a.png, "|", met.texto)
        return
    # Dibujo rapido: los ejes, la FFT y el texto se redibujan por completo cada 1,5 s (lento, ~0,2 s);
    # entre medias solo se repintan las 4 lineas de tiempo sobre un fondo guardado (blitting).
    grupos = [(ax_e, [L["e_raw"], L["e_f"]]), (ax_p, [L["p_ir"], L["p_red"]])]
    for _, ls in grupos:
        for l in ls:
            l.set_animated(True)
    fondo = {"bg": None}

    def al_dibujar(_evento):
        # fondo guardado SOLO de los 2 ejes de tiempo (copiar toda la figura en cada cuadro era lo que frenaba)
        fondo["bg"] = [fig.canvas.copy_from_bbox(ax.bbox) for ax, _ in grupos]
        for ax, ls in grupos:
            for l in ls:
                if l.get_visible():
                    ax.draw_artist(l)

    fig.canvas.mpl_connect("draw_event", al_dibujar)

    def cuadro_rapido():
        if fondo["bg"] is None:
            return
        fps["n"] += 1
        if time.time() - fps["t"] >= 1.0:
            fps["v"], fps["n"], fps["t"] = fps["n"] / (time.time() - fps["t"]), 0, time.time()
        rapido()
        for (ax, ls), bg in zip(grupos, fondo["bg"]):
            fig.canvas.restore_region(bg)
            for l in ls:
                if l.get_visible():
                    ax.draw_artist(l)
            fig.canvas.blit(ax.bbox)

    def cuadro_completo():
        dibujar()
        fig.canvas.draw_idle()

    t_rapido = fig.canvas.new_timer(interval=25)
    t_rapido.add_callback(cuadro_rapido)
    t_completo = fig.canvas.new_timer(interval=2000)
    t_completo.add_callback(cuadro_completo)
    cuadro_completo()
    t_rapido.start(); t_completo.start()
    try:
        plt.show()
    finally:
        parar.set()


if __name__ == "__main__":
    main()