"""Visor en el navegador: ECG y PPG en vivo, rapidos y suaves (60 cuadros/s), con FFT, FC/FR/SpO2 y calidad.
No usa matplotlib: Python filtra y manda las muestras, y el navegador (Chrome o Edge) las dibuja.
Por eso no se traba ni pone el cursor en espera.

    python -m herramientas.visor_web --puerto COM12      # ESP32 por USB, en vivo
    python -m herramientas.visor_web --simular           # senal falsa, para ver como se ve
    python -m herramientas.visor_web --archivo prueba_ecg/demo_ecg_ppg.pkt
Se abre solo en http://localhost:8765 . Ctrl+C en la terminal para cerrar.
No uses este visor y puente_firebase a la vez con el mismo puerto.
"""
import argparse
import json
import os
import re
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np
from scipy import signal as SG

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from procesamiento import config as C
from procesamiento.cargador import leer_paquetes
from herramientas.ver_senal import Acumulador, abrir_puerto, calidad
from herramientas.puente_firebase import calcular_valores, muestras_desde_archivo, muestras_simuladas

FS = int(C.FS_DISPOSITIVO)
CAP = FS * 60                       # muestras que guarda el servidor por canal
HISTORIA_S = 12                     # lo que se manda al abrir la pagina


# ------------------------------------------------------------------ filtros en tiempo real (con estado)
class Filtro:
    """Filtro causal: procesa muestra a muestra sin ver el futuro (como un monitor de verdad)."""

    def __init__(self, sos):
        self.sos, self.zi = sos, None

    def __call__(self, x):
        if self.zi is None:
            self.zi = SG.sosfilt_zi(self.sos) * x[0]
        y, self.zi = SG.sosfilt(self.sos, x, zi=self.zi)
        return y


def sos_ecg(lo, hi, notch, q):
    sos = SG.butter(2, [lo, hi], "bandpass", fs=FS, output="sos")
    if notch:
        for f0 in C.MUESCAS_RED_200HZ:
            if f0 < FS / 2:
                b, a = SG.iirnotch(f0, q, fs=FS)           # q bajo = muesca ancha (quita mas ruido, pero tambien un poco de senal)
                sos = np.vstack([sos, SG.tf2sos(b, a)])
    return sos


class Media:
    """Suavizado causal (media movil de n muestras)."""

    def __init__(self, n):
        self.n, self.zi = n, None

    def __call__(self, x):
        if self.n <= 1:
            return x
        b = np.ones(self.n) / self.n
        if self.zi is None:
            self.zi = SG.lfilter_zi(b, [1.0]) * x[0]
        y, self.zi = SG.lfilter(b, [1.0], x, zi=self.zi)
        return y


class Flujo:
    """Ultimas muestras (crudas y filtradas) en anillos, para repartirlas a los navegadores."""
    CANALES = ("e", "ef", "ir", "rd")

    def __init__(self):
        self.lock = threading.Lock()
        self.N = 0
        self.buf = {k: np.zeros(CAP, np.float32) for k in self.CANALES}
        self.cfg = dict(notch=True, q=10.0, lo=0.5, hi=40.0, suave=0.0, plo=C.PPG_BANDA[0], phi=C.PPG_BANDA[1],
                        inv=False, umbral=float(C.PPG_UMBRAL_DEDO))
        self._armar()

    def _armar(self):
        c = self.cfg
        self.f_e = Filtro(sos_ecg(c["lo"], c["hi"], c["notch"], c["q"]))
        self.f_s = Media(max(1, int(round(c["suave"] * FS / 1000.0))))
        sp = SG.butter(2, [c["plo"], c["phi"]], "bandpass", fs=FS, output="sos")
        self.f_ir, self.f_rd = Filtro(sp.copy()), Filtro(sp.copy())

    def configurar(self, nuevo):
        with self.lock:
            c = self.cfg
            for k in c:
                if k in nuevo:
                    c[k] = nuevo[k]
            c["lo"] = float(min(max(c["lo"], 0.05), 5.0))
            c["hi"] = float(min(max(c["hi"], 10.0), 90.0))
            c["q"] = float(min(max(c["q"], 2.0), 60.0))
            c["suave"] = float(min(max(c["suave"], 0.0), 80.0))
            c["plo"] = float(min(max(c["plo"], 0.05), 2.0))
            c["phi"] = float(min(max(c["phi"], 2.0), 40.0))
            if c["lo"] >= c["hi"]:
                c["lo"] = c["hi"] / 10
            C.PPG_UMBRAL_DEDO = float(c["umbral"])
            self._armar()

    def agregar(self, m):
        e, ir, rd = (m["ecg"].astype(np.float64), m["ir"].astype(np.float64), m["red"].astype(np.float64))
        with self.lock:
            ef = self.f_s(self.f_e(e - 2048.0))
            if self.cfg["inv"]:
                ef = -ef
            irf, rdf = self.f_ir(ir), self.f_rd(rd)
            idx = (self.N + np.arange(len(e))) % CAP
            self.buf["e"][idx], self.buf["ef"][idx] = e - 2048.0, ef
            self.buf["ir"][idx], self.buf["rd"][idx] = irf, rdf
            self.N += len(e)

    def desde(self, i):
        """(N, dict de listas) con lo nuevo desde la muestra i."""
        with self.lock:
            N = self.N
            i = max(i, N - CAP + 1, 0)
            if N <= i:
                return N, None
            idx = np.arange(i, N) % CAP
            return N, {k: np.round(self.buf[k][idx], 1).tolist() for k in self.CANALES}


F = Flujo()
ACU = Acumulador()
ESTADO = {"v": 0, "d": {}}
ESTADO_LOCK = threading.Lock()


def alimentar(cab, m):
    ACU.agregar(cab, m)
    F.agregar(m)


# ------------------------------------------------------------------ fuentes
def hilo_serie(ser, parar):
    buf = b""
    while not parar.is_set():
        buf += ser.read(ser.in_waiting or 1)
        paq, usados, malos = leer_paquetes(buf)
        for m in re.finditer(rb"#[ -~]{3,200}\n", buf[:usados]):
            print(m.group().decode().strip())
        buf = buf[usados:]
        ACU.crc_malos += malos
        for cab, m in paq:
            alimentar(dict(seq=int(cab["seq"]), flags=int(cab["flags"])), m)
    ser.close()


def hilo_reproducir(a, parar, repetir):
    """Entrega las muestras como si llegaran en vivo, en bloques de 0,05 s."""
    paso = FS // 20
    t0, k, seq, vuelta = time.time(), 0, 0, 0
    while not parar.is_set():
        if k + paso > len(a):
            if not repetir:
                print("# fin del archivo")
                return
            k, t0, vuelta = 0, time.time(), vuelta + 1
        bloque = a[k:k + paso].copy()
        bloque["t_us"] += np.uint32((vuelta * len(a) * 1_000_000 // FS) % 2**32)     # el tiempo sigue creciendo al repetir
        alimentar(dict(seq=seq, flags=0), bloque)
        k, seq = k + paso, seq + 1
        espera = t0 + k / FS - time.time()
        if espera > 0:
            time.sleep(espera)


# ------------------------------------------------------------------ metricas (hilo aparte)
def hilo_metricas(parar):
    t_vals, t_fft, vals, fft = 0.0, 0.0, {"FC": None, "FR": None, "SpO2": None, "motivo": "juntando senal"}, []
    while not parar.is_set():
        time.sleep(1.0)
        try:
            txt, q = calidad(ACU)
            partes = txt.split("   ||   ")
            if time.time() - t_vals >= 5:
                t_vals, vals = time.time(), calcular_valores(ACU)
            d = ACU.ultimos(8)
            if d is not None and time.time() - t_fft >= 2 and len(d[1]["ecg"]) >= 8 * FS:
                t_fft = time.time()
                x = d[1]["ecg"][-8 * FS:]
                x = x - x.mean()
                sp = np.abs(np.fft.rfft(x * np.hanning(len(x)))) ** 2
                f = np.fft.rfftfreq(len(x), 1.0 / FS)
                sp = sp[(f >= 0) & (f <= 100)]
                n = len(sp) // 4 * 4
                db = 10 * np.log10(sp[:n].reshape(-1, 4).max(axis=1) + 1e-9)
                fft = np.round(db, 1).tolist()
            pps, fs_real = ACU.velocidad()
            dato = dict(ecg_v=partes[0], ppg_v=partes[1] if len(partes) > 1 else "", lo=[1 if ACU.flags & 4 else 0, 1 if ACU.flags & 8 else 0],
                        suelto=bool(ACU.flags & 1), ir=q.get("ir"), red=q.get("pct_red"), pi=None if not q or q.get("pi") != q.get("pi") else q.get("pi"),
                        FC=vals["FC"], FR=vals["FR"], SpO2=vals["SpO2"], motivo=vals["motivo"],
                        pps=None if pps != pps else round(pps, 1), fs=None if fs_real != fs_real else round(fs_real, 1),
                        perdidos=ACU.perdidos, crc=ACU.crc_malos, fft=fft, cfg=F.cfg,
                        dedo=bool(q and q.get("ir", 0) >= C.PPG_UMBRAL_DEDO))
            with ESTADO_LOCK:
                ESTADO["v"] += 1
                ESTADO["d"] = dato
        except Exception as e:                         # un calculo fallido no debe tumbar el visor
            print(f"# metricas: {e}")


# ------------------------------------------------------------------ servidor web
class Manejador(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path.startswith("/eventos"):
            return self.eventos()
        cuerpo = PAGINA.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        try:
            F.configurar(json.loads(self.rfile.read(n) or b"{}"))
        except Exception:
            pass
        self.send_response(204)
        self.end_headers()

    def eventos(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        i, v_vista = max(F.N - HISTORIA_S * FS, 0), -1
        try:
            while True:
                N, d = F.desde(i)
                msg = {"n": N}
                if d is not None:
                    msg.update(d)
                    msg["i"] = i
                    i = N
                with ESTADO_LOCK:
                    if ESTADO["v"] != v_vista:
                        v_vista, msg["s"] = ESTADO["v"], ESTADO["d"]
                if d is not None or "s" in msg:
                    self.wfile.write(("data: " + json.dumps(msg) + "\n\n").encode("utf-8"))
                    self.wfile.flush()
                time.sleep(0.03)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            return


PAGINA = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8"><title>BIODISEÑO · señal en vivo</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#0a1020;--panel:#111a30;--borde:#1f2b4a;--txt:#e7ecf7;--tenue:#8b98b8;--verde:#3ddc97;--rojo:#ff5d6c;--nar:#ffb454;--azul:#5aa9ff}
*{box-sizing:border-box}html,body{margin:0;height:100%;background:var(--bg);color:var(--txt);font:14px/1.35 system-ui,Segoe UI,Roboto,sans-serif}
.app{display:grid;grid-template-columns:1fr 330px;gap:12px;padding:12px;height:100%}
.izq{display:grid;grid-template-rows:auto 1.25fr 1fr;gap:12px;min-height:0}
.der{display:flex;flex-direction:column;gap:10px;min-height:0;overflow:auto}
.panel{background:var(--panel);border:1px solid var(--borde);border-radius:14px;padding:10px 12px;position:relative;min-height:0}
.panel h3{margin:0 0 4px;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--tenue);font-weight:600}
canvas{width:100%;height:calc(100% - 22px);display:block}
.barra{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.pill{padding:5px 11px;border-radius:999px;border:1px solid var(--borde);background:#0d1630;font-size:12.5px}
.ok{border-color:#1f6b4d;color:var(--verde)}.mal{border-color:#7a2a35;color:var(--rojo)}.aviso{border-color:#7a5a1f;color:var(--nar)}
.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.card{background:#0d1630;border:1px solid var(--borde);border-radius:12px;padding:8px 10px;text-align:center}
.card b{display:block;font-size:30px;line-height:1.1}.card span{font-size:11px;color:var(--tenue)}
.ctrl{display:flex;flex-direction:column;gap:7px;font-size:13px}.ctrl label{display:flex;gap:8px;align-items:center;cursor:pointer;flex-wrap:wrap}
.ctrl h4{margin:6px 0 0;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--tenue)}
select,button,input[type=number]{background:#0d1630;color:var(--txt);border:1px solid var(--borde);border-radius:8px;padding:4px 8px}
button{cursor:pointer}button:hover{border-color:var(--azul)}
input[type=range]{flex:1;min-width:90px}
.fila{display:flex;gap:6px;flex-wrap:wrap}
.nota{color:var(--tenue);font-size:12px}
.msg{position:absolute;inset:30px 0 0 0;display:none;align-items:center;justify-content:center;color:var(--tenue);font-size:16px;text-align:center;padding:20px;pointer-events:none}
</style></head><body><div class="app">
<div class="izq">
 <div class="barra" id="pills"><span class="pill">conectando…</span></div>
 <div class="panel"><h3>ECG</h3><canvas id="cE"></canvas></div>
 <div class="panel"><h3>PPG (IR rojo · rojo naranja)</h3><canvas id="cP"></canvas><div class="msg" id="msgP"></div></div>
</div>
<div class="der">
 <div class="cards">
  <div class="card"><span>FC</span><b id="fc">--</b><span>lpm</span></div>
  <div class="card"><span>FR</span><b id="fr">--</b><span>rpm</span></div>
  <div class="card"><span>SpO₂</span><b id="sp">--</b><span>% (sin calibrar)</span></div>
 </div>
 <div class="panel" style="height:190px;flex:none"><h3>FFT del ECG crudo (dB, 0 a 100 Hz)</h3><canvas id="cF"></canvas></div>
 <div class="panel ctrl">
  <h4>Filtros rápidos</h4>
  <div class="fila"><button data-p="normal">Normal</button><button data-p="fuerte">Fuerte (ruidoso)</button><button data-p="diag">Diagnóstico</button></div>
  <h4>ECG</h4>
  <label><input type="checkbox" id="notch" checked> Muescas de red (20, 40, 60, 80 Hz)</label>
  <label>Muesca <span class="nota">ancha</span><input type="range" id="q" min="2" max="40" step="1" value="10"><span class="nota">fina</span></label>
  <label>Banda <input id="lo" type="number" step="0.1" min="0.05" max="5" value="0.5" style="width:62px"> a <input id="hi" type="number" step="1" min="10" max="90" value="40" style="width:62px"> Hz</label>
  <label>Suavizado <input type="range" id="suave" min="0" max="60" step="5" value="0"><span id="suaveV" class="nota">0 ms</span></label>
  <label><input type="checkbox" id="inv"> Invertir ECG</label>
  <label><input type="checkbox" id="cruda"> Mostrar ECG crudo</label>
  <h4>PPG</h4>
  <label>Banda <input id="plo" type="number" step="0.1" min="0.05" max="2" value="0.3" style="width:62px"> a <input id="phi" type="number" step="1" min="2" max="40" value="10" style="width:62px"> Hz</label>
  <label>Umbral de dedo (IR) <input id="umbral" type="number" step="5000" min="0" value="50000" style="width:90px"></label>
  <label><input type="checkbox" id="forzar"> Ver PPG aunque no detecte dedo</label>
  <h4>Vista</h4>
  <label>Ventana <select id="ven"><option>4</option><option selected>6</option><option>10</option></select> s <button id="pausa">Pausa</button></label>
  <div class="nota" id="nota"></div>
 </div>
</div></div>
<script>
const FS=200, CAP=FS*60;
const R={e:new Float32Array(CAP),ef:new Float32Array(CAP),ir:new Float32Array(CAP),rd:new Float32Array(CAP)};
let N=0, N0=null, pos=0, pausa=false, S=null;
const $=id=>document.getElementById(id);
const cE=$('cE'),cP=$('cP'),cF=$('cF');
function ajusta(c){const r=devicePixelRatio||1,b=c.getBoundingClientRect();c.width=Math.round(b.width*r);c.height=Math.round(b.height*r);c.getContext('2d').setTransform(r,0,0,r,0,0)}
function reajusta(){[cE,cP,cF].forEach(ajusta)} addEventListener('resize',reajusta); setTimeout(reajusta,50); reajusta();

const es=new EventSource('/eventos');
es.onmessage=ev=>{
  const d=JSON.parse(ev.data);
  if(d.e){const m=d.e.length;
    for(let k=0;k<m;k++){const j=(d.i+k)%CAP;R.e[j]=d.e[k];R.ef[j]=d.ef[k];R.ir[j]=d.ir[k];R.rd[j]=d.rd[k]}
    if(N0===null){N0=d.i;pos=d.i}
  }
  N=d.n; if(d.s){S=d.s;estado(S)}
};
es.onerror=()=>{$('pills').innerHTML='<span class="pill mal">sin conexión con Python (¿se cerró?)</span>'};

function pill(t,c){return `<span class="pill ${c}">${t}</span>`}
function estado(s){
  const e=s.ecg_v||'';
  let h='';
  h+=pill('Electrodos: '+(s.suelto?`sin contacto (LO+=${s.lo[0]} LO-=${s.lo[1]})`:'ok'),s.suelto?'mal':'ok');
  h+=pill('ECG: '+e.replace(/^ECG: /,'').split(' | ')[0].toLowerCase(),/buena/.test(e)?'ok':(/RUIDO|DEBIL/.test(e)?'aviso':'mal'));
  h+=pill('Ruido de red: '+(s.red==null?'--':Math.round(s.red)+' %'),s.red==null?'':(s.red<20?'ok':(s.red<40?'aviso':'mal')));
  h+=pill('PPG: '+(s.dedo?'dedo detectado':'sin dedo')+(s.ir!=null?` (IR ${Math.round(s.ir)})`:''),s.dedo?'ok':'aviso');
  h+=pill(`${s.pps??'--'} paq/s · ${s.fs??'--'} muestras/s · perdidos ${s.perdidos}`,(s.fs&&Math.abs(s.fs-200)<3)?'':'aviso');
  $('pills').innerHTML=h;
  $('fc').textContent=s.FC==null?'--':s.FC.toFixed(0);
  $('fr').textContent=s.FR==null?'--':s.FR.toFixed(0);
  $('sp').textContent=s.SpO2==null?'--':s.SpO2.toFixed(0);
  $('nota').textContent=(s.motivo||'')+(s.pi!=null?` · PI ${s.pi.toFixed(2)} %`:'');
  const m=$('msgP'),ver=s.dedo||$('forzar').checked;m.style.display=ver?'none':'flex';
  m.textContent=ver?'':(s.ir!=null&&s.ir<1?'El sensor manda 0: revisa USAR_PPG y el cableado I2C':`Sin dedo (IR ${Math.round(s.ir||0)}; hace falta más de ${$('umbral').value}). Cubre el LED con la yema, sin apretar. O baja el umbral / marca "Ver PPG aunque no detecte dedo".`);
  dibujaFFT(s.fft||[]);
}
function envia(){
  $('suaveV').textContent=$('suave').value+' ms';
  fetch('/cfg',{method:'POST',body:JSON.stringify({notch:$('notch').checked,q:+$('q').value,lo:+$('lo').value,hi:+$('hi').value,suave:+$('suave').value,
    plo:+$('plo').value,phi:+$('phi').value,inv:$('inv').checked,umbral:+$('umbral').value})});
}
['notch','q','lo','hi','suave','plo','phi','inv','umbral'].forEach(i=>$(i).addEventListener('change',envia));
$('suave').addEventListener('input',()=>$('suaveV').textContent=$('suave').value+' ms');
const PRE={normal:{notch:1,q:10,lo:.5,hi:40,suave:0},fuerte:{notch:1,q:4,lo:1,hi:20,suave:15},diag:{notch:1,q:20,lo:.05,hi:40,suave:0}};
document.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{const p=PRE[b.dataset.p];$('notch').checked=!!p.notch;$('q').value=p.q;$('lo').value=p.lo;$('hi').value=p.hi;$('suave').value=p.suave;envia()});
$('pausa').onclick=()=>{pausa=!pausa;$('pausa').textContent=pausa?'Seguir':'Pausa'};

function rango(arr,i0,i1,suave,minimo){
  let v=[];for(let i=i0;i<i1;i+=2)v.push(arr[((i%CAP)+CAP)%CAP]);
  if(v.length<10)return suave;v.sort((a,b)=>a-b);
  let lo=v[Math.floor(v.length*.01)],hi=v[Math.floor(v.length*.99)];
  let m=Math.max(hi-lo,minimo)*.25;lo-=m;hi+=m;
  return [suave[0]+(lo-suave[0])*.08,suave[1]+(hi-suave[1])*.08];
}
function paso(rg,n){const r=(rg||1)/n,p=Math.pow(10,Math.floor(Math.log10(r))),f=r/p;return (f<1.5?1:f<3?2:f<7?5:10)*p}
const ML=58,MR=10,MT=8,MB=22;
function dibuja(c,ini,win,series,y,unidad){
  const ctx=c.getContext('2d'),r=devicePixelRatio||1,W=c.width/r,H=c.height/r;
  const px=ML,py=MT,pw=W-ML-MR,ph=H-MT-MB;
  ctx.clearRect(0,0,W,H);
  ctx.font='11px system-ui';ctx.fillStyle='#8b98b8';
  // rejilla y ejes
  ctx.lineWidth=1;
  for(let s=0;s<=win+1e-9;s+=.2){const x=Math.round(px+pw-s/win*pw)+.5,mayor=Math.abs(s-Math.round(s))<1e-6;
    ctx.strokeStyle=mayor?'#1c2b4d':'#131f3a';ctx.beginPath();ctx.moveTo(x,py);ctx.lineTo(x,py+ph);ctx.stroke();
    if(mayor&&(win<=6||Math.round(s)%2===0)){ctx.textAlign='center';ctx.fillText(s===0?'0 s':'-'+Math.round(s),x,py+ph+14)}}
  const st=paso(y[1]-y[0],5);
  for(let v=Math.ceil(y[0]/st)*st;v<=y[1];v+=st){const yy=Math.round(py+ph-(v-y[0])/(y[1]-y[0])*ph)+.5;
    ctx.strokeStyle='#1c2b4d';ctx.beginPath();ctx.moveTo(px,yy);ctx.lineTo(px+pw,yy);ctx.stroke();
    ctx.textAlign='right';ctx.fillText(Math.abs(v)>=1000?(v/1000).toFixed(1)+'k':(+v.toFixed(2)).toString(),px-6,yy+4)}
  ctx.strokeStyle='#2b3b63';ctx.strokeRect(px+.5,py+.5,pw,ph);
  ctx.textAlign='left';ctx.fillStyle='#6f7da0';ctx.fillText(unidad,px+6,py+12);
  ctx.textAlign='right';ctx.fillText('tiempo (s)',px+pw-4,py+ph-5);
  // trazos recortados al area
  ctx.save();ctx.beginPath();ctx.rect(px,py,pw,ph);ctx.clip();
  const n=win*FS,dx=pw/n,k=ph/(y[1]-y[0]),i0=Math.floor(ini)-1,i1=Math.ceil(ini+n)+1;
  series.forEach(s=>{const a=R[s.k];ctx.globalAlpha=s.a||1;ctx.strokeStyle=s.c;ctx.lineWidth=s.w;ctx.lineJoin='round';ctx.beginPath();let ok=false;
    for(let i=i0;i<=i1;i++){if(i<(N0??0)||i>=N)continue;const x=px+(i-ini)*dx,yy=py+ph-(a[((i%CAP)+CAP)%CAP]-y[0])*k;
      if(!ok){ctx.moveTo(x,yy);ok=true}else ctx.lineTo(x,yy)}ctx.stroke()});
  ctx.restore();ctx.globalAlpha=1;
}
let t_ant=performance.now(),yE=[-300,300],yP=[-3,3];
function cuadro(t){
  const dt=(t-t_ant)/1000;t_ant=t;const win=+$('ven').value;
  if(N0!==null&&!pausa){pos+=dt*FS;pos+=(N-8-pos)*0.06;if(pos>N-1)pos=N-1}
  if(N0!==null){
    const ini=pos-win*FS,a=Math.floor(ini),b=Math.floor(pos);
    yE=rango(R.ef,a,b,yE,60);
    const series=[];if($('cruda').checked)series.push({k:'e',c:'#6b7a99',w:1,a:.55});series.push({k:'ef',c:'#3ddc97',w:1.8});
    dibuja(cE,ini,win,series,yE,'cuentas ADC · filtrado'+($('notch').checked?' + muescas':''));
    if((S&&S.dedo)||$('forzar').checked){yP=rango(R.ir,a,b,yP,1);dibuja(cP,ini,win,[{k:'rd',c:'#ffb454',w:1.4,a:.9},{k:'ir',c:'#ff5d6c',w:1.8}],yP,'cuentas · filtrado')}
    else{const ctx=cP.getContext('2d'),r=devicePixelRatio||1;ctx.clearRect(0,0,cP.width/r,cP.height/r)}
  }
  requestAnimationFrame(cuadro);
}
requestAnimationFrame(cuadro);

function dibujaFFT(db){
  const c=cF,ctx=c.getContext('2d'),r=devicePixelRatio||1,W=c.width/r,H=c.height/r;ctx.clearRect(0,0,W,H);
  if(!db.length)return;
  const L=34,mx=Math.max(...db),lo=mx-80,hi=mx+8,pw=W-L-6,ph=H-18;
  ctx.fillStyle='#8b98b8';ctx.font='11px system-ui';ctx.lineWidth=1;
  for(const f of [0,20,40,60,80,100]){const x=L+f/100*pw;ctx.strokeStyle='#16233f';ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,ph);ctx.stroke();
    ctx.textAlign=f===100?'right':(f===0?'left':'center');ctx.fillText(f+(f===100?' Hz':''),x,H-3)}
  for(let d=0;d<=80;d+=20){const y=ph-(d/(hi-lo))*ph;ctx.strokeStyle='#16233f';ctx.beginPath();ctx.moveTo(L,y);ctx.lineTo(L+pw,y);ctx.stroke();ctx.textAlign='right';ctx.fillText(Math.round(lo+d),L-3,y+4)}
  for(const f of [20,40,60,80]){ctx.strokeStyle='rgba(255,93,108,.55)';ctx.setLineDash([4,4]);const x=L+f/100*pw;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,ph);ctx.stroke();ctx.setLineDash([])}
  ctx.strokeStyle='#5aa9ff';ctx.lineWidth=1.5;ctx.beginPath();
  db.forEach((v,i)=>{const x=L+i/(db.length-1)*pw,y=ph-(v-lo)/(hi-lo)*ph;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();
}
</script></body></html>"""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--puerto")
    ap.add_argument("--baud", type=int, default=921600)
    ap.add_argument("--archivo")
    ap.add_argument("--fs", type=float, help="fs del CSV si tiene 1 columna")
    ap.add_argument("--simular", action="store_true")
    ap.add_argument("--web", type=int, default=8765, help="puerto del navegador (por defecto 8765)")
    ap.add_argument("--sin-navegador", action="store_true", help="no abrir el navegador solo")
    a = ap.parse_args()
    if not (a.puerto or a.archivo or a.simular):
        ap.error("elige una fuente: --puerto COMx, --archivo ruta o --simular")

    parar = threading.Event()
    if a.puerto:
        ser = abrir_puerto(a.puerto, a.baud)
        threading.Thread(target=hilo_serie, args=(ser, parar), daemon=True).start()
    else:
        datos = muestras_simuladas() if a.simular else muestras_desde_archivo(a.archivo, a.fs)
        threading.Thread(target=hilo_reproducir, args=(datos, parar, True), daemon=True).start()
    threading.Thread(target=hilo_metricas, args=(parar,), daemon=True).start()

    try:
        srv = ThreadingHTTPServer(("127.0.0.1", a.web), Manejador)
    except OSError:
        raise SystemExit(f"El puerto web {a.web} esta ocupado (otra copia del visor abierta). Cierrala o usa --web 8766")
    srv.daemon_threads = True
    url = f"http://localhost:{a.web}"
    print(f"Visor en {url}  (Ctrl+C para cerrar)")
    if not a.sin_navegador:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    parar.set()


if __name__ == "__main__":
    main()